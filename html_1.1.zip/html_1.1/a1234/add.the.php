<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2'])	)
{
 	header('Location:../index.php');
	die();
}
  
session_start();

include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);

	if (isset($_SESSION['current_food_class']) )
	{
		unset($_SESSION['current_food_class']);
	}
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	 
	if ($mysqli->connect_error)
	{
		header('Location:../index.php');
		die("Can't connect to database");
	}
		 
	if (!mysqli_select_db($mysqli, $database))
	{
		header('Location:../index.php');
		die("Can't select database");
	}
			 
	$mysqli->set_charset("utf8");
	$new_dir = "images/";
	
	$result = mysqli_query($mysqli, " SELECT tfood.id, tfood.descr, tfood.itype, " . 
			                        "        Q1.min_prc, Q1.max_prc, Q1.cnt_prc, Q1.foodvariationid, " . 
			                        "        Q1.variationid, Q2.cnt_foodline, Q3.cnt_topping, " . 
			                        "        tfood.CanChangeMaterials, tfood.sFoodPictureid, tfoodgroup.Descr foodgroup_descr   " .  
			                        " FROM tfood  " .
									" left join tfoodgroup on tfoodgroup.id = tfood.foodgroupid " .
			                        " left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, " . 
			                        "                    min(tfoodvariation.id) foodvariationid, " . 
			                        "                    min(tfoodvariation.variationid) variationid, count(*) as cnt_prc    " . 
			                        "             FROM  tfoodvariation  GROUP BY foodid ) Q1 on Q1.foodid = tfood.id  " . 
			                        " left join ( SELECT foodid, count(*) as cnt_foodline    " . 
			                        "             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " . 
			                        " left join ( SELECT foodid, count(*) as cnt_topping    " . 
			                        "             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " . 
			                        " where tfood.id = $foodid  ");
	if ($result)
	{
		if (mysqli_num_rows($result) > 0)
		{
			$url_current_step = -1;
			$counter = 0;
			if (list($r_foodid, $r_descr, $r_itype, $r_min_prc, $r_max_prc, $r_cnt_prc, $r_foodvariationid,  
 					 $r_variationid, $r_cnt_foodline, $r_cnt_topping, $r_CanChangeMaterials, $r_sFoodPictureid,
					 $r_foodgroup_descr) = mysqli_fetch_row($result))
			{
				$prm1 = $_REQUEST['prm'];
				$prm2 = $_REQUEST['prm2'];
				
				$obj = new cls_current_food;
				$obj->foodid = $foodid;
				$obj->sdescr = $fooddescr;
				$obj->sdescr_parent = $r_foodgroup_descr;
				$obj->url_array = array();
				$obj->current_step = -1;
				$obj->current_step_inner = -1;
				$obj->foodvariationid = 0;
				$obj->bundleid = 0;
				$obj->bundle_freetoppings = 0;
				$obj->foodpictureid = $r_sFoodPictureid;
				$obj->itype = $r_itype;
				
				// bundle
				if ( $r_itype == 1 )
				{
					$obj->hasvariations = 0;
					$obj->foodvariationid = $r_foodvariationid;
					$obj->variationid = $r_variationid;
					$obj->dprice = $r_min_prc;
					
					$result2 = mysqli_query($mysqli," SELECT tfoodbundle.id, tfoodbundle.bfreetoppings, Q1.cnt, Q1.foodid, Q1.foodvariationid  " .
													" FROM tfoodbundle  " .
													" left join ( select count(*) cnt, tfoodbundledetail.foodbundleid, max(tfoodvariation.foodid) foodid, " .
 													"                    max(tfoodvariation.id) foodvariationid " . 
							                        "             from tfoodbundledetail " . 
							                        "              left join  tfoodvariation on tfoodvariation.id = tfoodbundledetail.foodvariationid " . 
													"             group by foodbundleid ) Q1  on " .
													"             Q1.foodbundleid = tfoodbundle.id " .
													" where tfoodbundle.foodid = $foodid  ");
					if ($result2)
					{
						if (mysqli_num_rows($result2) > 0)
						{
							$obj->food_list = array();
							
							while(list($r2_foodbundleid, $r2_bfreetoppings, $r2_cnt, $r2_foodid, $r2_foodvariationid) = mysqli_fetch_row($result2))
							{
								if ( $r2_cnt > 1 )
								{

									$obj_child = new cls_current_food;
									$obj_child->foodid = $r2_foodid;
									$obj_child->sdescr = "";
									$obj_child->sdescr_parent = "";
									$obj_child->url_array = array();
									$obj_child->current_step = 0;
									$obj_child->foodvariationid = 0;
									$obj_child->foodpictureid = 0;
									$obj_child->hasvariations = 0;
									$obj_child->variationid = 0;
									$obj_child->dprice = 0;
									$obj_child->bundle_freetoppings = $r2_bfreetoppings;
										
									$obj->food_list[] = serialize($obj_child);
									
									$en_bundleid = encode_str_gr(strval($r2_foodbundleid));
									$food_list_index = count($obj->food_list) - 1;
									$sfood_list_index = encode_str_gr(strval($food_list_index));
									$url_current_step ++;
									$obj->url_array[] = array();
									$obj->url_array[$url_current_step][] = "bundle.the.php?prm={$prm1}&prm2={$prm2}&prm3={$en_bundleid}&prm4={$sfood_list_index}";
									
								}
								else 
								{
									
									$result3 = mysqli_query($mysqli," SELECT tfood.id, tfood.descr, tfood.itype, " .
																	"        Q1.min_prc, Q1.max_prc, Q1.cnt_variation, Q1.foodvariationid, " .
																	"        Q1.variationid, Q2.cnt_foodline, Q3.cnt_topping, " .
																	"        tfood.CanChangeMaterials, tfood.sFoodPictureid, tfoodgroup.Descr foodgroup_descr   " .
																	" FROM tfood  " .
																	" left join tfoodgroup on tfoodgroup.id = tfood.foodgroupid " .
																	" left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, " .
																	"                    min(tfoodvariation.id) foodvariationid, " .
																	"                    min(tfoodvariation.variationid) variationid, count(*) as cnt_variation    " .
																	"             FROM  tfoodbundledetail " . 
																	"             left join tfoodvariation on tfoodbundledetail.foodvariationid = tfoodvariation.id " . 
																	"             where  tfoodbundledetail.foodbundleid = $r2_foodbundleid GROUP BY foodid ) " . 
																	"         Q1 on Q1.foodid = tfood.id  " .
																	" left join ( SELECT foodid, count(*) as cnt_foodline    " .
																	"             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " .
																	" left join ( SELECT foodid, count(*) as cnt_topping    " .
																	"             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " .
																	" where tfood.id = $r2_foodid  ");
				

									
									if ($result3)
									{
										if (mysqli_num_rows($result3) > 0)
										{
											$counter = 0;
											if (list($r3_foodid, $r3_descr, $r3_itype, $r3_min_prc, $r3_max_prc, $r3_cnt_variation, $r3_foodvariationid,  
								 					 $r3_variationid, $r3_cnt_foodline, $r3_cnt_topping, $r3_CanChangeMaterials, $r3_sFoodPictureid,
													 $r3_foodgroup_descr) = mysqli_fetch_row($result3))
											{
												$url_current_step ++;
												$obj->url_array[] = array();
												
												$prm1 = $_REQUEST['prm'];
												$prm2 = $_REQUEST['prm2'];
												
												$obj_child = new cls_current_food;
												$obj_child->foodid = $r2_foodid;
												$obj_child->sdescr = $r3_descr;
												$obj_child->sdescr_parent = $r3_foodgroup_descr;
												$obj_child->url_array = array();
												$obj_child->current_step = 0;
												$obj_child->foodvariationid = 0;
												$obj_child->foodpictureid = $r3_sFoodPictureid;
												$obj_child->hasvariations = 0;
												$obj_child->foodvariationid = $r2_foodvariationid;
												$obj_child->variationid = $r3_variationid;
												$obj_child->dprice = $r3_min_prc;
												$obj_child->bundle_freetoppings = $r2_bfreetoppings;
												// multiquantity
												if ( $r3_itype == 2 )
												{
													$obj_child->url_array[] = "multiquantity.the.php?prm={$prm1}&prm2={$prm2}";
												}
												
												// has variations
												if ($r3_cnt_variation>1)
												{
													$obj_child->hasvariations = 1;
													$obj->url_array[$url_current_step][] = "variation.the.php?prm={$prm1}&prm2={$prm2}";
												}
												else //NO variations
												{
													$obj_child->hasvariations = 0;
													$obj_child->foodvariationid = $r3_foodvariationid;
													$obj_child->variationid = $r3_variationid;
													$obj_child->dprice = $r3_min_prc;
												}
												
													
												if ($r3_cnt_foodline > 0 && $r3_CanChangeMaterials == 1 )
												{
													$obj->url_array[$url_current_step][] = "foodline.the.php?prm={$prm1}&prm2={$prm2}";
												}
												else
												{
													$obj_child->foodline = 0;
												}
												
												if ($r3_cnt_topping>0)
												{
													$obj->url_array[$url_current_step][] = "topping.the.php?prm={$prm1}&prm2={$prm2}";
												}
													
												$obj->food_list[] = serialize($obj_child);
											}
										}
									}
									
									
								}
								
							}
							
							$url_current_step ++;
							$obj->url_array[$url_current_step][] = "submit.the.php?prm={$prm1}&prm2={$prm2}";
								
							
						}
					}
				}
				else  // itype == 0 (normal item) OR itype == 2 (multiple quantity item) 
				{
					$url_current_step ++;
					$obj->url_array[] = array();
						
					// multiquantity
					if ( $r_itype == 2 )
					{
						$obj->url_array[$url_current_step][] = "multiquantity.the.php?prm={$prm1}&prm2={$prm2}";
					}
					
					
					// has variations
					if ($r_cnt_prc>1)
					{
						$obj->hasvariations = 1;
						$obj->url_array[$url_current_step][] = "variation.the.php?prm={$prm1}&prm2={$prm2}";
					}
					else//NO variations
					{
						$obj->hasvariations = 0;
						$obj->foodvariationid = $r_foodvariationid;
						$obj->variationid = $r_variationid;
						$obj->dprice = $r_min_prc;
					}
						
					if ($r_cnt_foodline > 0 && $r_CanChangeMaterials == 1 )
					{
						$obj->url_array[$url_current_step][] = "foodline.the.php?prm={$prm1}&prm2={$prm2}";
					}
					else
					{
						$obj->foodline = 0;
					}
						
					if ($r_cnt_topping>0)
					{
						$obj->url_array[$url_current_step][] = "topping.the.php?prm={$prm1}&prm2={$prm2}";
					}
					
					$obj->url_array[$url_current_step][] = "submit.the.php?prm={$prm1}&prm2={$prm2}";
						
				}

				$ret_array = get_next_url(serialize($obj));
				$next_url = $ret_array[0];
				if (strlen($next_url) > 0 )
				{
					$_SESSION['current_food_class'] = serialize($ret_array[1]);
				}
				echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
				exit();
				
				
			}
		}
	}


header('Location:../index.php');
die();


?>