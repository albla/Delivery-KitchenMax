<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


session_start();

include_once('language.the.php');

if(!isset ($_SESSION['customer_wid']) || $_SESSION['customer_wid'] == 0 )
{
	header('Location:../index.php');
	die();
}
  

include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
	if (isset($_POST["submit"])	&&
		isset($_POST["radio1"]))
	{
		if ($_POST["radio1"] == 0)
		{
			$next_url = "../new_address.the.php";
		}
		else 
		{
			$_SESSION['customer_wcontactid'] = $_POST["radio1"];
			$next_url = "payment.the.php";
		}

		
		echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
		exit();
		
	}

}

?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_address.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>
<div class="slide" >		

 <div class='banner_msg' >
	<h7><?php echo $language_array["Delivery Address"]; ?></h7>
 </div>
   <div  class='inner-box'>
 <form name="redirectpost" method="post" action="address.the.php"   class='inner-box' >
     
   <div>
     <?php
     
       	include_once('dbheader.the.php');
 	    
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
			exit();
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
			exit();
		}
        
      	$mysqli->set_charset("utf8");
        		
       	
   		$result = mysqli_query($mysqli, 
   				" SELECT tcustomercontact.id, tcustomercontact.wid, tcustomercontact.sHouseNumber,   " .
				"        tstreet.descr as streetdescr, tcustomercontact.sAddress2, tcustomercontact.sStreet, " .
				"        tarea.descr as areadescr, tcustomercontact.sFloor, tpostcode.descr postcodedescr, " .
				"        tcustomercontact.IsDefault " .
   				"   " .
   				" FROM  tcustomercontact  " .
   				"  left join tarea on tarea.id = tcustomercontact.areaID  " .
   				"  left join tpostcode on tpostcode.id = tcustomercontact.postcodeID  " .
				"  left join tstreet on tstreet.id = tcustomercontact.StreetID  " .
   				" where tcustomercontact.wCustomerID = {$_SESSION['customer_wid']}  ".
   				" ORDER BY IsDefault DESC, streetdescr ");
       		

       	
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		echo "<div class='container_radiobtn'>";
	       		echo "<ul>";
	       		
	       		while(list($id, $wid, $sHouseNumber, $streetdescr, $sAddress2, 
	       				   $sStreet, $areadescr, $sFloor, $postcodedescr, $IsDefault) = mysqli_fetch_row($result))
	       		{
		       		
		       		echo "<li>";
		       		if($IsDefault == 1)
		       		{
		       			echo " <input type='radio' name='radio1' id='the{$wid}' checked value='{$wid}'>";
		       		}
		       		else 
		       		{
		       			echo " <input type='radio' name='radio1' id='the{$wid}' value='{$wid}'>";
		       		}
				    echo " <label for='the{$wid}'>";
				    $tmp_descr = "";
				    if (strlen($streetdescr) > 0 )
				    {
				    	 $tmp_descr = $tmp_descr . $streetdescr;
				    }
				    elseif (strlen($sStreet) > 0 )
				    {
				    	$tmp_descr = $tmp_descr . $sStreet;
				    }
				    if (strlen($sHouseNumber) > 0 )
				    {
				    	$tmp_descr = $tmp_descr . " " . $sHouseNumber;
				    }				    
	       			if (strlen($areadescr) > 0 )
				    {
	       				if (strlen($tmp_descr) > 0 )
				    		$tmp_descr = $tmp_descr . ", ";
	       				$tmp_descr = $tmp_descr . " " . $areadescr;
				    }				    
	       			if (strlen($postcodedescr) > 0 )
				    {
	       				if (strlen($tmp_descr) > 0 )
				    		$tmp_descr = $tmp_descr . ", ";
	       				$tmp_descr = $tmp_descr . " " . $postcodedescr;
				    }				    
				    echo $tmp_descr."</label>";
		       		echo "<div class='check'><div class='inside'></div></div>";
		       		echo "</li>";
	       		}
	       		echo "<li>";
			    echo " <input type='radio' name='radio1' id='the0' value='0'>";
			    echo " <label for='the0'>" . $language_array["New Contact"] . "</label>";
	       		echo "<div class='check'><div class='inside'></div></div>";
	       		echo "</li>";

	       		echo "</ul>";
	       		echo "</div>";
	       		
	       	}
        }
     ?>

     </div>
     
    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Next"]; ?>"/>
    </div>
  </form>
     </div>
 </div>

</body>
</html>
