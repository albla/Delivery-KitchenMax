<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2']) || 
	!isset($_REQUEST['prm3']) || 
	!isset($_REQUEST['prm4'])	)
{
	header('Location:../index.php');
	die();
}
  
session_start();

include_once('language.the.php');

include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);
$foodbundleid = decode_str_gr($_REQUEST['prm3']);

if (!isset($_SESSION['current_food_class']) )
{
	header('Location:../index.php');
	die();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if (isset($_POST["foodvariationid"]) &&
		isset($_POST["foodbundledetailid"]) &&
		isset($_POST["foodid"]) &&
		isset($_POST["variationcnt"]) &&
		isset($_POST["submit"])	)
	{
		$obj = unserialize($_SESSION['current_food_class']);
		
		$foodvariationid = $_POST["foodvariationid"];
		$foodbundledetailid = $_POST["foodbundledetailid"];
		$foodid = $_POST["foodid"];
		$variationcnt = $_POST["variationcnt"];

		$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
		 
		if ($mysqli->connect_error)
		{
			header('Location:../index.php');
			die("Can't connect to database");
		}
		
		if (!mysqli_select_db($mysqli, $database))
		{
			header('Location:../index.php');
			die("Can't select database");
		}
		
		$mysqli->set_charset("utf8");
		
		$result3 = mysqli_query($mysqli," SELECT tfood.id, tfood.descr, tfood.itype, " .
				"        Q1.min_prc, Q1.max_prc, Q1.cnt_prc, Q1.foodvariationid, " .
				"        Q1.variationid, Q2.cnt_foodline, Q3.cnt_topping, " .
				"        tfood.CanChangeMaterials, tfood.sFoodPictureid, tfoodgroup.Descr foodgroup_descr   " .
				" FROM tfood  " .
				" left join tfoodgroup on tfoodgroup.id = tfood.foodgroupid " .
				" left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, " .
				"                    min(tfoodvariation.id) foodvariationid, " .
				"                    min(tfoodvariation.variationid) variationid, count(*) as cnt_prc    " .
				"             FROM  tfoodbundledetail " . 
				"             left join tfoodvariation on tfoodbundledetail.foodvariationid = tfoodvariation.id " . 
				"             where  tfoodbundledetail.foodbundleid = $foodbundleid GROUP BY foodid ) " . 
				"         Q1 on Q1.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_foodline    " .
				"             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_topping    " .
				"             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " .
				" where tfood.id = $foodid  ");

		if ($result3)
		{
			if (mysqli_num_rows($result3) > 0)
			{
				$counter = 0;
				if (list($r3_foodid, $r3_descr, $r3_itype, $r3_min_prc, $r3_max_prc, $r3_cnt_variation, $r3_foodvariationid,
						$r3_variationid, $r3_cnt_foodline, $r3_cnt_topping, $r3_CanChangeMaterials, $r3_sFoodPictureid,
						$r3_foodgroup_descr) = mysqli_fetch_row($result3))
				{
					$prm1 = $_REQUEST['prm'];
					$prm2 = $_REQUEST['prm2'];
					$prm3 = $_REQUEST['prm3'];
					$food_index = decode_str_gr($_REQUEST['prm4']);
		
					$obj_child = unserialize($obj->food_list[$food_index] );
					$obj_child->foodid = $foodid;
					$obj_child->sdescr = $r3_descr;
					$obj_child->sdescr_parent = $r3_foodgroup_descr;
					$obj_child->url_array = array();
					$obj_child->current_step = 0;
					$obj_child->foodvariationid = 0;
					$obj_child->foodpictureid = $r3_sFoodPictureid;
					$obj_child->hasvariations = 0;
					$obj_child->foodvariationid = $foodvariationid;
					$obj_child->variationid = $r3_variationid;
					$obj_child->dprice = $r3_min_prc;

					$prm1 = encode_str_gr(strval($foodid));
					$prm2 = encode_str_gr($r3_descr);
						
					if ( $r3_itype == 2 )
					{
						$obj->url_array[$obj->current_step][] = "multiquantity.the.php?prm={$prm1}&prm2={$prm2}";
					}
						
					// has variations
					if ($r3_cnt_variation>1)
					{
						$obj_child->hasvariations = 1;
						$obj->url_array[$obj->current_step][] = "variation.the.php?prm={$prm1}&prm2={$prm2}&prm3={$prm3}";
						
					}
					else // NO variations
					{
						$obj_child->hasvariations = 0;
						$obj_child->foodvariationid = $r3_foodvariationid;
						$obj_child->variationid = $r3_variationid;
						$obj_child->dprice = $r3_min_prc;
					}
						
					if ($r3_cnt_foodline > 0 && $r3_CanChangeMaterials == 1 )
					{
						$obj->url_array[$obj->current_step][] = "foodline.the.php?prm={$prm1}&prm2={$prm2}";
					}
					else
					{
						$obj_child->foodline = 0;
					}
		
					if ($r3_cnt_topping>0)
					{
						$obj->url_array[$obj->current_step][] = "topping.the.php?prm={$prm1}&prm2={$prm2}";
					}
						
					$obj->food_list[$food_index] = serialize($obj_child);
					
					$ret_array = get_next_url(serialize($obj));
					$next_url = $ret_array[0];
					if (strlen($next_url) > 0 )
					{
						$_SESSION['current_food_class'] = serialize($ret_array[1]);
					}
					echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
					exit();
						
				}
			}
		}
	}
	else
	{
		header('Location:../index.php');
		die();
	}
	
}



?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_controls.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>

<div class="slide" >		

      <div class='banner_msg' >
			<h7>ΠΑΡΑΚΑΛΩ ΔΙΑΛΕΞΤΕ ΜΙΑ ΑΠΟ ΤΙΣ ΕΠΙΛΟΓΕΣ</h7>
      </div>
      <div style="width: 80%;padding:10px 18px;margin-left:auto;margin-right:auto;">
     
     <?php
     
       	include_once('dbheader.the.php');
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			header('Location:../index.php');
			die("Can't connect to database");
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			header('Location:../index.php');
			die("Can't select database");
		}
        
      	$mysqli->set_charset("utf8");
       	$new_dir = "images/";
       		 
	    $result = mysqli_query($mysqli, " SELECT MAX(tfoodbundledetail.ID) ID,  MAX(tfoodbundledetail.foodvariationid) foodvariationid, " . 
	    		                        "        tfoodgroup.Descr foodgroup_descr, tfood.Descr food_descr, tfoodvariation.foodid, count(tvariation.ID) variationcnt  " .
							       		" FROM  tfoodbundledetail  " .
							       		"  left join tfoodbundle on tfoodbundle.ID = tfoodbundledetail.foodbundleid     " .
							       		"  left join tfoodvariation on tfoodvariation.ID  = tfoodbundledetail.foodvariationid     " .
	    		                        "  left join tvariation on tvariation.ID = tfoodvariation.VariationID  "  . 
	    		                        "  left join tfood on tfoodvariation.foodid  = tfood.ID  "  . 
	    								"  left join tfoodgroup on tfood.foodgroupid   = tfoodgroup.ID       " .
	    								" where tfoodbundledetail.foodbundleid = $foodbundleid  " . 
	    		                        " GROUP BY tfoodvariation.foodid, tfood.Descr, tfoodgroup.Descr  "  . 
	    		                        "  "  . 
	    		                        "  "  );
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		$counter = 0;
	       		while(list($r_foodbundledetailid, $r_FoodVariationID, $r_foodgroup_descr, $r_food_descr, $r_foodid, 
	       				   $r_variationcnt ) = mysqli_fetch_row($result))
	       		{

	       			$prm1 = $_REQUEST['prm'];
	       			$prm2 = $_REQUEST['prm2'];
	       			$prm3 = $_REQUEST['prm3'];
	       			$prm4 = $_REQUEST['prm4'];
	       			 
	       			echo "<form name='redirectpost' method='post' action='bundle.the.php?prm={$prm1}&prm2={$prm2}&prm3={$prm3}&prm4={$prm4}'>";
	       			echo "<input type='hidden' name='foodbundledetailid' value='{$r_foodbundledetailid}'>";
	       			echo "<input type='hidden' name='foodvariationid' value='{$r_FoodVariationID}'>";
	       			echo "<input type='hidden' name='foodid' value='{$r_foodid}'>";
	       			echo "<input type='hidden' name='variationcnt' value='{$r_variationcnt}'>";
	       			echo "<input class='button_wide_variation' type='submit' name='submit' Value='{$r_foodgroup_descr} / {$r_food_descr}'/>";
	       			echo "</form>";
	       			 
					$counter = $counter + 1; 
	       		}
	       		
	       	}
        }
     ?>
     </div>     
<div>
<br> 
 <form  method='post' action='../index.php'>
    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Home"]; ?>"/>
    </div>
 </form>
  <br> <br> <br> <br> <br> <br>
</div>

</div>
</body>
</html>
