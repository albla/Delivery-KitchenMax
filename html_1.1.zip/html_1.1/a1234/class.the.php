<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


	class cls_topping
	{
		public $toppingid;
		public $dprice;
		public $material_descr;
		public $ipart = 1;
	}


	class cls_foodline
	{
		public $materialid;
		public $orig_materialid;
		public $material_descr;
		public $orig_materialid_descr;
		public $binclude;
		public $dprice;
	}
	
	class cls_tmp_material
	{
		public $materialid;
		public $dprice;
		public $sdescr;
	}
	
	
	class cls_current_food
	{
		public $foodid;
		public $itype;
		public $quantity;
		public $descr_metric;
		public $foodpictureid;
		public $sdescr_parent;
		public $sdescr;
		public $orderlineid;
		public $topping;
		public $foodline;
		public $hasvariations;
		public $foodvariationid;
		public $variationid;
		public $varationdescr;
		public $dprice;
		public $dprice_total;
		public $url_array;
		public $current_step;
		public $current_step_inner;
		public $food_list;
		public $bundleid;
		public $bundle_freetoppings;
		
		
	}
	
	class cls_cart_item
	{
		public $id;
		public $current_food;
		public $bundle_no;
		public $isdeleted;
		public $comment;
	}
	
	
	
	
	class cls_footer_item
	{
		public $sbody;
		public $itype;
		public $iheight;
	}

?>