<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


 $db_host = 'localhost';
 $db_user = 'root';
 $db_pwd = '';
 $database = 'kitchenmax';


?>
