<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

session_start();

	if (isset($_REQUEST['prm']) )
	{
		include_once('class.the.php');
		
		$the_cart_array = unserialize($_SESSION['the_cart']);
		$final_total = 0.0;
		$searching_id = $_REQUEST['prm'];
		
		if ( is_array($the_cart_array) )
		{
			$counter = 0;
			for ($counter = 0; $counter <= count($the_cart_array) ; $counter++)
			{
				$ser_cart_item = $the_cart_array[$counter];
				$cart_item = unserialize($ser_cart_item);
				
				if ( $cart_item->id == $searching_id )
				{
					$cart_item->isdeleted = 1;
					$the_cart_array[$counter] = serialize($cart_item);
					$_SESSION['the_cart'] = serialize($the_cart_array);
					$_SESSION['the_cart_count'] --;
						
				}
			}
		}
	}
			
	
	if (isset($_REQUEST['prm3']) )
	{
		echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		die();
	}
	else
	{
		header('Location:../shopping_cart.php');
	}
	
?>