<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


	session_start();
	
	include_once('dbheader.the.php');
	include_once('tools.the.php');
	
	if (!isset($_REQUEST['prm']))
	{
		session_destroy();
		header('Location:login.php');
		die();
	}
	else
	{
		$the_id = floatval( decode_str_gr($_REQUEST['prm']) );
	}
	
	function redirect_post_delete($url)
	{
		include_once('language.the.php');
		?>
	    <html xmlns="http://www.w3.org/1999/xhtml">
	    <head>
	        <script type="text/javascript">
	            function closethisasap() 
				{
					var answer = confirm("<?php echo $language_array["Contact will be deleted permanently. Would you like to continue?"]; ?>")
					if (answer)
	                {
					    document.forms["redirectpost"].submit();
					}
					else
	                {
					    window.location="../customer.php";
					}
	                
	            }
	        </script>
	    </head>
	    <body onload="closethisasap();">
	     <form name="redirectpost" method="post" action="<?php echo $url; ?>">
	     <input type='hidden' name='delete_yes' value='1'>
	    </form>
	    </body>
	    </html>
	    <?php
	    exit;
	}
	function redirect_post_exit($url)
	{
		?>
	    <html xmlns="http://www.w3.org/1999/xhtml">
	    <head>
	        <script type="text/javascript">
	            function closethisasap() 
				{
				    document.forms["redirectpost"].submit();
	            }
	        </script>
	    </head>
	    <body onload="closethisasap();">
	    <form name="redirectpost" method="post" action="<?php echo $url; ?>">
	    </form>
	    </body>
	    </html>
	    <?php
	    exit;
	}
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["delete_yes"]))
 	{
 		$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
  
		if (!$mysqli->connect_error)
		{
			if (mysqli_select_db($mysqli, $database))
	  		{
	  			
				$result1 = mysqli_query($mysqli, "DELETE from tcustomercontact WHERE id = $the_id ", MYSQLI_USE_RESULT);
	  		}
		}
		redirect_post_exit("../customer.php");
		die();
	}
	else
	{
		redirect_post_delete("delete_customer_contact.the.php?prm={$_REQUEST['prm']}");
		die();
	}
 ?>  
   