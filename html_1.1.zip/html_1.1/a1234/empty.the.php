<?php 
// 	session_destroy();
	session_start();
	unset($_SESSION['the_cart']);
	unset($_SESSION['the_cart_count']);
	unset($_SESSION['the_cart_order_uniq_id']);
	
	header('Location:../index.php');
?>