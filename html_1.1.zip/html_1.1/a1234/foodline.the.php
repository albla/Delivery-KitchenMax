<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2'])	)
{
	header('Location:../index.php');
	die();
}
  
session_start();

include_once('language.the.php');
include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
	if (isset($_POST["submit"])	)
	{
		$obj = unserialize($_SESSION['current_food_class']);

	
	    if ($obj->itype == 1)
       	{
       		$obj_child = unserialize( $obj->food_list[$obj->current_step] );
			$obj_child->foodline = array();
       	}
       	else
       	{
			$obj->foodline = array();
       	}
		
		
		
		
		$curr_item_id = 0;
		$new_foodline_class = "";
		foreach ($_POST as $key => $value)
		{
			
			if ( strlen($key) > 5 && substr($key,0,5) == "radio")
			{
				$bSwap = 0;
				$s_type = substr($value, 0, 1);
				$curr_item_id = floatval( substr($value,1) );
				
				$new_foodline_class = new cls_foodline;
				
				$new_foodline_class->materialid = $curr_item_id;
				$new_foodline_class->orig_materialid = $curr_item_id;
				$new_foodline_class->binclude = 1;
				
				$new_foodline_class->dprice = floatval("0.0");
				if ($s_type == "o")
					$new_foodline_class->binclude = 0;
				elseif ($s_type == "s")
					$bSwap = 1;
			}
			if ( strlen($key) > 5 && substr($key,0,5) == "descr")
			{
				$new_foodline_class->material_descr = $value;
				$new_foodline_class->orig_materialid_descr = $value;
			}
			if ( $bSwap == 1 && $curr_item_id > 0 && strlen($key) > 8 && substr($key,0,8) == "swaplist")
			{
				$new_material_id = floatval( $value );
				$new_foodline_class->materialid = $new_material_id;
			}
			if ( $bSwap == 1 && $curr_item_id > 0 && strlen($key) > 5 && substr($key,0,5) == "price")
			{
			    $x_material_array = unserialize($_SESSION['tmp_extra_material_array']);
       			foreach ($x_material_array as $un_curr_material)
       			{
       				$curr_material = unserialize($un_curr_material);
       				if($curr_material->materialid == $new_foodline_class->materialid)
       				{
       					$original_material_price = floatval( $value );
       					if ($original_material_price < $curr_material->dprice )
       					{
       						$new_foodline_class->dprice = $curr_material->dprice - $original_material_price;
       					}
       					$new_foodline_class->material_descr = $curr_material->sdescr;
       				}
       			}
			}
			if ( $curr_item_id > 0 && strlen($key) > 7 && substr($key,0,7) == "replace")
			{
			    if ($obj->itype == 1)
		       	{
					$obj_child->foodline[] = serialize($new_foodline_class);
		       	}
		       	else
		       	{
					$obj->foodline[] = serialize($new_foodline_class);
		       	}
			}
		}

		if ($obj->itype == 1)
		{
			$obj->food_list[$obj->current_step] = serialize($obj_child);
		}
		
		unset($_SESSION['tmp_extra_material_array']);
		
		$ret_array = get_next_url(serialize($obj));
		$next_url = $ret_array[0];
		if (strlen($next_url) > 0 )
		{
			$_SESSION['current_food_class'] = serialize($ret_array[1]);
		}
		echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
		exit();
		
	}

}
else
{
	if(isset($_SESSION['tmp_extra_material_array']))
	{
		unset($_SESSION['tmp_extra_material_array']);
	}
}



?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_controls.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>
<div class="slide" >		
 <div class='banner_msg' >
	<h7><?php echo $language_array["Materials"]; ?>: <?php echo"{$fooddescr}"; ?></h7>
 </div>
 <form name="redirectpost" method="post" action="<?php $prm1 = $_REQUEST['prm']; $prm2 = $_REQUEST['prm2']; echo "foodline.the.php?prm={$prm1}&prm2={$prm2}"; ?>">
  <div  class='inner-box'>
     
     <?php
     
       	include_once('dbheader.the.php');
 	    
       	if (!isset($_SESSION['current_food_class'])	)
		{
			header('Location:../index.php');
			die("No food selected.");
		}
		
       	$obj = unserialize($_SESSION['current_food_class']);
       	
       	
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			header('Location:../index.php');
			die("Can't connect to database");
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			header('Location:../index.php');
			die("Can't select database");
		}
        
      	$mysqli->set_charset("utf8");
       	$new_dir = "images/";
       		
       	
       	$obj = unserialize($_SESSION['current_food_class']);
       	
       	$hasvariations = false;
       	
       	if ($obj->itype == 1)
       	{
       		$obj_child = unserialize( $obj->food_list[$obj->current_step] );
       		$hasvariations = $obj_child->hasvariations;
       		$variationid = $obj_child->variationid;
       	}
       	else
       	{
       		$hasvariations = $obj->hasvariations;
       		$variationid = $obj->variationid;
       	}
       	 
       	
       	
       	if ( $obj->hasvariations == 1 )
       	{
       		$result = mysqli_query($mysqli, " SELECT tfoodline.id, tfoodline.materialid, tmaterial.Descr, Q1.dprice  " .
						       				" FROM  tfoodline  " .
						       				"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
						       				"  left join ( select ttopping.materialid, ttoppingvariation.dprice from ttoppingvariation   " .
       										"              left join ttopping on ttopping.id = ttoppingvariation.toppingid " . 
       				                        "                                and ttoppingvariation.variationid = {$obj->variationid} " .
       										"              where ttopping.foodid = {$foodid} ) Q1 on tmaterial.id = Q1.materialid " .
       				                        " where tfoodline.foodid = {$foodid}  ORDER BY tmaterial.Descr ");
       		
       		$result2= mysqli_query($mysqli, " SELECT ttopping.materialid, tmaterial.Descr, ttoppingvariation.dprice from ttoppingvariation   " .
						       				"  left join ttopping on ttopping.id = ttoppingvariation.toppingid " .
       				                        "        and ttoppingvariation.variationid = {$obj->variationid} " .
       				                        "  left join tmaterial on tmaterial.id = ttopping.materialid  " .
       				                        " where ttopping.foodid = {$foodid}  ORDER BY tmaterial.Descr ");
       		
       	}
       	else 
       	{
       		if ($obj->itype == 1)
       		{
       			$obj_child = unserialize( $obj->food_list[$obj->current_step] );
       			$child_foodid = $obj_child->foodid;
	       		$result = mysqli_query($mysqli, " SELECT tfoodline.id, tfoodline.materialid, tmaterial.Descr, Q1.dprice  " .
							       				" FROM  tfoodline  " .
							       				"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
							       				"  left join ( select ttopping.materialid, ttopping.dprice from ttopping   " .
	       										"              where ttopping.foodid = {$child_foodid} ) Q1 on tmaterial.id = Q1.materialid " .
	       				                        " where tfoodline.foodid = {$child_foodid}  ORDER BY tmaterial.Descr ");
	       		
	       		$result2 = mysqli_query($mysqli," SELECT ttopping.materialid, tmaterial.Descr, ttopping.dprice from ttopping   " .
							       				"  left join tmaterial on tmaterial.id = ttopping.materialid  " .
	       						       			" where ttopping.foodid = {$child_foodid}  ORDER BY tmaterial.Descr ");
       		}
       		else
       		{
	       		$result = mysqli_query($mysqli, " SELECT tfoodline.id, tfoodline.materialid, tmaterial.Descr, Q1.dprice  " .
							       				" FROM  tfoodline  " .
							       				"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
							       				"  left join ( select ttopping.materialid, ttopping.dprice from ttopping   " .
	       										"              where ttopping.foodid = {$foodid} ) Q1 on tmaterial.id = Q1.materialid " .
	       				                        " where tfoodline.foodid = {$foodid}  ORDER BY tmaterial.Descr ");
	       		
	       		$result2 = mysqli_query($mysqli," SELECT ttopping.materialid, tmaterial.Descr, ttopping.dprice from ttopping   " .
							       				"  left join tmaterial on tmaterial.id = ttopping.materialid  " .
	       						       			" where ttopping.foodid = {$foodid}  ORDER BY tmaterial.Descr ");
       		}
       		 
       	}

       	
       	$extra_material_array = array();
       	if ($result2)
       	{
       		if (mysqli_num_rows($result2) > 0)
       		{
       			while(list($r2_materialid, $r2_descr, $r2_dprice) = mysqli_fetch_row($result2))
       			{
       				$new_material = new cls_tmp_material;
       				$new_material->materialid = $r2_materialid;
       				$new_material->dprice = $r2_dprice;
       				$new_material->sdescr = $r2_descr;
       				$extra_material_array[] = serialize($new_material); 
       			}
       			$_SESSION['tmp_extra_material_array'] = serialize($extra_material_array);
       		}
       		 
       	}
       	
       	
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		$counter = 0;
	       		while(list($id, $materialid, $descr, $dprice) = mysqli_fetch_row($result))
	       		{
	       			$prm1 = $_REQUEST['prm'];
	       			$prm2 = $_REQUEST['prm2'];
	       			$tmp_descr = $descr;
	       			if (substr($tmp_descr,1,1) == "." && intval(substr($tmp_descr,0,1))>0 )
	       			{
	       				$tmp_descr = substr($tmp_descr,2);       				
	       			}
	       			echo "<div class='container_radiobtn'>";
				
		       		echo "<ul>";
		       		
		       		echo "<li>";
				    echo " <input type='radio' name='radio{$id}' id='wth{$id}' checked value='w{$materialid}'>";
				    echo " <label for='wth{$id}'>" . $language_array["WITH"] . " {$descr}</label>";
		       		echo "<div class='check'><div class='inside'></div></div>";
		       		echo "</li>";
		       		echo "<li>";
		       		echo "<input type='radio' name='radio{$id}' id='wthout{$id}' value='o{$materialid}'>";
				    echo " <label for='wthout{$id}'>" . $language_array["WITHOUT"] . " {$descr}</label>";
		       		echo "<div class='check'><div class='inside'></div></div>";
		       		echo "</li>";
		       		if (count($extra_material_array)> 0)
					{
						$material_price_as_topping = 0;
						foreach ($extra_material_array as &$curr_obj_serialized)
						{
							$curr_obj = unserialize($curr_obj_serialized);
							if ( $curr_obj->materialid == $materialid )
							{
								$material_price_as_topping = $curr_obj->dprice;
							}
						}
		       		    echo "<li>";
						echo "<input type='radio' name='radio{$id}' id='rswp{$id}'  value='s{$materialid}'> ";
				        echo " <label for='rswp{$id}'>" . $language_array["REPLACE"] . "  {$descr}  " . $language_array["WITH"] . "</label>";
						echo "<select name='swaplist{$id}' style='margin: 28px 0;font-size: 1.35em;' >";
						foreach ($extra_material_array as &$curr_obj_serialized)
						{
							$curr_obj = unserialize($curr_obj_serialized);
							
							echo "	<option value='{$curr_obj->materialid}' "; 
							if ( $curr_obj->materialid == $materialid )
							{
								echo "selected";
							}
							if ($curr_obj->dprice > $dprice)
							{
								$extra = my_format_currency($curr_obj->dprice - $dprice);
								echo ">{$curr_obj->sdescr} (+{$extra})</option>";
							}
							else 
							{
								echo ">{$curr_obj->sdescr}</option>";
							}
								
								
							
						}
						echo "</select>";
						
			       		echo "<div class='check'><div class='inside'></div></div>";
			       		echo "</li>";
						echo "</ul>";
					}
					else 
					{
						echo "</ul>";
						
					}
					echo "<input type='hidden' name='descr{$id}' value='{$descr}'>";
					echo "<input type='hidden' name='price{$id}' value='{$dprice}'>";
					echo "<input type='hidden' name='replace{$id}' value='{$materialid}'>";
						
					echo "</div>";
	       			
					$counter = $counter + 1; 
	       		}
	       		
	       	}
        }
     ?>

    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Next"]; ?>"/>
    </div>
   </div>
  </form>

</div>

</body>
</html>
