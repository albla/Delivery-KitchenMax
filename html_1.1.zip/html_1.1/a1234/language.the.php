<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_SESSION["SelectedLanguage"]))
{
	if (isset($_SESSION["WebLanguage1"]))
	{
		$_SESSION["SelectedLanguage"] = $_SESSION["WebLanguage1"];
	}
	else 
	{
		include_once('tools.the.php');
		LoadSessionVars();		
		if (isset($_SESSION["WebLanguage1"]))
		{
			$_SESSION["SelectedLanguage"] = $_SESSION["WebLanguage1"];
		}
		else 
		{
			$_SESSION["SelectedLanguage"] = "en";
		}
	}
}
if (file_exists("lang/language_{$_SESSION["SelectedLanguage"]}.php"))
{
	include("lang/language_{$_SESSION["SelectedLanguage"]}.php");
}
elseif (file_exists("../lang/language_{$_SESSION["SelectedLanguage"]}.php"))
{
	include("../lang/language_{$_SESSION["SelectedLanguage"]}.php");
}




?>