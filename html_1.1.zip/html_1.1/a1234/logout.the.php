<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

	session_start();
	unset($_SESSION['customer_wid']);
	$_SESSION['customer_name'] = "";
	$_SESSION['customer_email'] = "";
	
	header('Location:../index.php');
?>