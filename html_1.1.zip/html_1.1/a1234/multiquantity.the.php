<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2'])	)
{
	header('Location:../index.php');
	die();
}
  
session_start();

include_once('language.the.php');
include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
	if (isset($_POST["submit"]) &&
		isset($_POST["txtquantity"]) &&
		isset($_POST["txtprice"]) &&
		isset($_POST["min_prc"])&&
		isset($_POST["metricdescr"]))
	{
		$obj = unserialize($_SESSION['current_food_class']);

		$obj->quantity = $_POST["txtquantity"];
		$obj->itype = 2; // multiquantity
		$obj->dprice = $_POST["min_prc"];
		$obj->descr_metric = $_POST["metricdescr"];
		
		$ret_array = get_next_url(serialize($obj));
		$next_url = $ret_array[0];
		if (strlen($next_url) > 0 )
		{
			$_SESSION['current_food_class'] = serialize($ret_array[1]);
		}
		echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
		exit();
		
	}

}
else
{
}



?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_controls.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<script type="text/javascript">
function validateForm() 
{
    var x = document.forms["redirectpost"]["txtquantity"].value;
    if (x === null ||  !(x > 0) ) 
    {
        alert("Η ποσότητα είναι λάθος.");
        return false;
    }
}

function txt_key_press(event) 
{
    var key = window.event ? event.keyCode : event.which;

    if (event.keyCode === 8 || event.keyCode === 46 ||
        event.keyCode === 37 || event.keyCode === 39) 
    {
        return true;
    }
    else if ( key < 48 || key > 57 ) 
    {
        return false;
    }
    else 
    {
        return true;
    }
};

function txt_key_up(e) 
{
    document.getElementById("txtprice").value = document.getElementById("min_prc").value * document.getElementById("txtquantity").value;
    document.getElementById("txtprice").value = Math.round(document.getElementById("txtprice").value * 100) / 100;
};

</script>
<body>

<div class="slide" >		


 <div class='banner_msg' >
	<h7><?php echo $language_array["Quantity"]; ?>: <?php echo"{$fooddescr}"; ?></h7>
 </div>
 <div style="width: 100%;margin-left:auto;margin-right:auto;">
 <form name="redirectpost"  onsubmit="return validateForm()"  method="post"  action="<?php $prm1 = $_REQUEST['prm']; $prm2 = $_REQUEST['prm2']; echo "multiquantity.the.php?prm={$prm1}&prm2={$prm2}"; ?>">
  <div  class='inner-box'>
  <br>   
     <?php
     
       	include_once('dbheader.the.php');
 	    
       	if (!isset($_SESSION['current_food_class'])	)
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		   	exit;
		}
		
       	$obj = unserialize($_SESSION['current_food_class']);
       	
       	
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		   	exit;
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		   	exit;
		}
        
      	$mysqli->set_charset("utf8");
       	$new_dir = "images/";
       		
 		$result = mysqli_query($mysqli, " SELECT tfood.id, tfood.descr, tfood.sFoodPictureid, tfood.itype, " . 
 				                        "        Q1.min_prc, Q1.max_prc, Q1.cnt_prc, Q2.cnt_foodline, Q3.cnt_topping, " . 
 				                        "        tfood.CanChangeMaterials, tmetric.Descr as metricdescr   " . 
 				                        " FROM tfood  " . 
 										" left join tmetric on tfood.metricid = tmetric.id " .
 				                        " left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, count(*) as cnt_prc    " . 
 				                        "             FROM  tfoodvariation  GROUP BY foodid ) Q1 on Q1.foodid = tfood.id  " . 
 				                        " left join ( SELECT foodid, count(*) as cnt_foodline    " . 
 				                        "             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " . 
 				                        " left join ( SELECT foodid, count(*) as cnt_topping    " . 
 				                        "             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " . 
 				                        " where tfood.id = $foodid  ");
 
       	
       	
       	
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		$counter = 0;
 				if(list($r_foodid, $r_descr, $r_sFoodPictureid, $r_itype, $r_min_prc, $r_max_prc, 
 						   $r_cnt_prc, $r_cnt_foodline, $r_cnt_topping, $r_CanChangeMaterials,
 						   $r_metricdescr ) = mysqli_fetch_row($result))
	       		{
	       			$prm1 = $_REQUEST['prm'];
	       			$prm2 = $_REQUEST['prm2'];
	       			$tmp_descr = $descr;
	       			if (substr($tmp_descr,1,1) == "." && intval(substr($tmp_descr,0,1))>0 )
	       			{
	       				$tmp_descr = substr($tmp_descr,2);       				
	       			}

	       			$qty = 1;
		       		$new_price = $r_min_prc;
		       		if ($r_min_prc < 0.03)
		       		{
		       			$qty = 1000;
		       			$new_price = $r_min_prc * 1000;
		       			
		       		}
	
		       		echo " <table style='width:50%;min-width:700px;max-width:800px;background-color:#ddd;height:60px; margin:auto;'> ";
					echo "<tr>";
					echo "<td>";
					echo " <label style='font: bold 25px/30px arial, sans-serif;background-color: #ddd; padding: 10px 0px 5px 20px; margin:10px;'> " . $language_array["Quantity2"] . ":</label>";
                    echo " <input type='text' style='width:100px;text-align:right;font: bold 25px/30px arial, sans-serif;' name='txtquantity' id='txtquantity' value='$qty' onkeypress='return txt_key_press(event)' onkeyup='return txt_key_up(this)'>";
		       		echo " <label style='font: bold 20px/30px arial, sans-serif;background-color: #ddd; padding: 5px 10px 5px 0px'>" . $language_array["in"] . " {$r_metricdescr} </label>";
		       		echo " <label style='font: bold 20px/30px arial, sans-serif;background-color: #ddd; padding: 5px 10px 5px 0px'>" . $language_array["is equal with"] . "</label>";
		       		echo " <input type='text' style='width:100px;text-align:right;font: bold 25px/30px arial, sans-serif;' name='txtprice' id='txtprice' readonly value='" . number_format( $new_price, 2) . "'>";
		       		echo " <label style='font: bold 25px/30px arial, sans-serif;background-color: #ddd; padding: 0px 10px 5px 0px'> " . $language_array["currency_symbol"] . "</label>";
					echo "<td>";
		       		echo "</tr>";
		       		echo " </table> ";
		       		 
		       		echo "<input type='hidden' name='min_prc' id='min_prc' value='{$r_min_prc}'>";
		       		echo "<input type='hidden' name='metricdescr' id='metricdescr' value='{$r_metricdescr}'>";
		       		 
	       		}
	       		
	       	}
        }
     ?>
  
    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Next"]; ?>"/>
    </div>
    </div>
  </form>
</div>

</body>
</html>
