<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


	session_start();
	
	if (!isset ($_SESSION['customer_wid']) || $_SESSION['customer_wid'] == 0 ||
	    !isset($_SESSION['customer_wcontactid']) || $_SESSION['customer_wcontactid'] == 0 )
	{
		header('Location:../index.php');
		die();
	}

	include_once('language.the.php');
	include_once('dbheader.the.php');
	include_once('class.the.php');
	include_once('tools.the.php');
	
	
	
	$_SESSION['Email_Success_Subject'] = "";
	$_SESSION['Email_Success_Body_HTML'] = "";
	$_SESSION['Email_Success_Body_Simple'] = "";
	$urlparts = parse_url($_SESSION['Website_link']);
	if (isset($urlparts['host']))
	{
		$_SESSION['Email_Success_Subject'] = $urlparts['host'] . " " . $language_array["Order"];
	}
	else
	{
		$_SESSION['Email_Success_Subject'] = $language_array["Order"] . " " . $_SESSION['the_cart_order_uniq_id'];
	}
	
	$_SESSION['Email_Success_Body_HTML'] .= "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
	$_SESSION['Email_Success_Body_HTML'] .= "<head>";
	$_SESSION['Email_Success_Body_HTML'] .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";
	$_SESSION['Email_Success_Body_HTML'] .= "<title>Untitled Document</title>";
	$_SESSION['Email_Success_Body_HTML'] .= "</head>	<body>";
	
	$_SESSION['Email_Success_Body_HTML'] .= "<p><b>{$_SESSION['Email_Success_Subject']}</b></p> ";
	$_SESSION['Email_Success_Body_Simple'] .= "{$_SESSION['Email_Success_Subject']}\r\n \r\n ";
	$_SESSION['Email_Success_Body_HTML'] .= "<table border=\"0\"> ";
	
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	
	if ($mysqli->connect_error)
	{
		header('Location:../index.php');
		die("Can't connect to database");
	}
	if (!mysqli_select_db($mysqli, $database))
	{
		header('Location:../index.php');
		die("Can't select database");
	}
	$mysqli->set_charset("utf8");
	

 	error_reporting(E_ALL);
	
	$berror = false;
	
	$order_log_str = "";
	
	
	$result = mysqli_query($mysqli, 
			" SELECT IFNULL(tcustomer.id, 0) id, tcustomer.wid,   " .       
	        "        tcustomer.sEmail, tcustomer.sPassword    " .
	        " FROM tcustomer " .
			" left join tcustomercontact on tcustomercontact.wcustomerid = tcustomer.wid and tcustomercontact.IsDefault = 1 " .
	        " WHERE tcustomer.wid = {$_SESSION['customer_wid']} " );
	
	// Update the orderlog with all the customer info 
	if ($result)
	{
		if (mysqli_num_rows($result) == 1)
		{
			if (list($the_id, $the_wid, $the_Email, $the_sPassword) = mysqli_fetch_row($result))
			{
				$order_log_str = $order_log_str . number_to_str_with_length(9, 5);
				$order_log_str = $order_log_str . "tcustomer";
				
				$str_tmp = "";
				$str_tmp = $str_tmp . number_to_str_with_length($the_wid, 20);
				$str_tmp = $str_tmp . number_to_str_with_length($the_id, 20);
				$str_tmp = $str_tmp . str_to_str_with_length($the_Email, 100);
				$str_tmp = $str_tmp . str_to_str_with_length($the_sPassword, 50);
				$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
				$order_log_str = $order_log_str . $str_tmp;

				$result = mysqli_query($mysqli,
						" SELECT tcustomercontact.wid, IFNULL(tcustomercontact.id,0) id, IFNULL(tcustomercontact.sName, '') as sName, IFNULL(tcustomercontact.sLastName, '') as sLastName,  " .
						"        IFNULL(tcustomercontact.sPhone, '') as sPhone, IFNULL(tcustomercontact.sBell, '') as sBell,    " .
						"        IFNULL(tcustomercontact.sHouseNumber, '') as sHouseNumber, IFNULL(tcustomercontact.StreetID, 0) as StreetID,    " .
						"        IFNULL(tcustomercontact.sStreet, '') as sStreet, IFNULL(tcustomercontact.sAddress2, '') as sAddress2,    " .
						"        IFNULL(tcustomercontact.sFloor, '') as sFloor, IFNULL(tcustomercontact.sComments, '') as sComments,    " .
						"        IFNULL(tcustomercontact.AreaID, 0) as AreaID, IFNULL(tcustomercontact.sArea, '') as sArea,    " .
						"        IFNULL(tcustomercontact.PostCodeID, 0) as PostCodeID, IFNULL(tcustomercontact.sPostCode, '') as sPostCode,    " .
						"        IFNULL(tcustomercontact.IsDefault, 0) as IsDefault, tstreet.Descr as tStreetDescr,  tarea.Descr as tAreaDescr  " .
						" FROM tcustomercontact " .
						"  LEFT JOIN tstreet ON tstreet.id = tcustomercontact.StreetID " .
						"  LEFT JOIN tarea ON tarea.id = tcustomercontact.AreaID " .
						"  " .
						" WHERE tcustomercontact.wCustomerID = {$_SESSION['customer_wid']} " );
				if ($result)
				{
					if (mysqli_num_rows($result) > 0)
					{
						$order_log_str = $order_log_str . number_to_str_with_length(16, 5);
						$order_log_str = $order_log_str . "tcustomercontact";
						
						$str_tmp = "";
						$icontact_counter = 0;
						while (list($cont_wid, $cont_id, $cont_fname, $cont_lname, $cont_sPhone, $cont_sBell, 
								    $cont_sHouseNumber, $cont_StreetID, $cont_sStreet, $cont_sAddress2, 
								    $cont_sFloor, $cont_sComments, $cont_AreaID, $cont_sArea, 
								    $cont_PostCodeID, $cont_sPostCode, $cont_IsDefault, 
								    $cont_tStreetDescr, $cont_tAreaDescr) = mysqli_fetch_row($result))
						{
							$str_tmp = $str_tmp . number_to_str_with_length($cont_wid, 20);
							$str_tmp = $str_tmp . number_to_str_with_length($cont_id, 10);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_fname, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_lname, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sPhone, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sBell, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sHouseNumber, 20);
							$str_tmp = $str_tmp . number_to_str_with_length($cont_StreetID, 10);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sStreet, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sAddress2, 100);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sFloor, 10);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sComments, 200);
							$str_tmp = $str_tmp . number_to_str_with_length($cont_AreaID, 10);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sArea, 100);
							$str_tmp = $str_tmp . number_to_str_with_length($cont_PostCodeID, 10);
							$str_tmp = $str_tmp . str_to_str_with_length($cont_sPostCode, 10);
							$str_tmp = $str_tmp . number_to_str_with_length($cont_IsDefault, 10);
							
							if ($cont_wid == $_SESSION['customer_wcontactid'])
							{
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td><b> {$language_array["Delivery Address"]}</b></td><td>&nbsp;</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Delivery Address"]}\r\n ";
								$full_name = $cont_fname . ' ' .$cont_lname;
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["First Name"]} {$language_array["Last Name"]}:</td><td>{$full_name}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["First Name"]} {$language_array["Last Name"]}:{$full_name}\r\n ";
								$address1 = $cont_sHouseNumber . " " . $cont_sStreet . " " . $cont_tStreetDescr;
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["House No"]} {$language_array["Street"]}:</td><td>{$address1}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["House No"]} {$language_array["Street"]}:{$address1}\r\n ";
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["Address 2"]}:</td><td>{$cont_sAddress2}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Address 2"]}:{$cont_sAddress2}\r\n ";
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["Floor"]}:</td><td>{$cont_sFloor}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Floor"]}:{$cont_sFloor}\r\n ";
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["Door Bell"]}:</td><td>{$cont_sBell}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Door Bell"]}:{$cont_sBell}\r\n ";
								$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$language_array["Area"]}:</td><td>{$cont_sArea} {$cont_tAreaDescr}</td></tr>";
								$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Area"]}:{$cont_sArea}\r\n ";
								$_SESSION['Email_Success_Body_HTML'] .= "<p></p>";
								$_SESSION['Email_Success_Body_Simple'] .= "\r\n ";
							}
							
							$icontact_counter ++;
						}
						
						$order_log_str = $order_log_str . number_to_str_with_length($icontact_counter, 5);
						$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
						$order_log_str = $order_log_str . $str_tmp;
					}
				}
					
						
			}
		}
	}
	// Update the orderlog with all the customer info  END 
	
	
	


	$_SESSION['Email_Success_Body_HTML'] .= "<tr><td><b> {$language_array["Order"]}</b></td><td>{$_SESSION['the_cart_order_uniq_id']}</td></tr>";
	$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Order"]}:{$_SESSION['the_cart_order_uniq_id']}\r\n ";
	
	
	$the_cart_array = unserialize($_SESSION['the_cart']);
	$final_total = 0.0;
	$original_final_total = 0.0;
	$last_item_count = 1;
	if ( is_array($the_cart_array) )
	{
		// Loop to get the total
		$icart_counter = 0;
		foreach ($the_cart_array as $ser_cart_item)
		{
			$cart_item = unserialize($ser_cart_item);
				
			if ( $cart_item->isdeleted == 0 )
			{
				$obj = unserialize($cart_item->current_food);
						
				$current_total = $obj->dprice;
				if ($obj->itype == 1)
				{
					$icounter = 0;
					$curr_inner_total = $obj->dprice;
					foreach( $obj->food_list as $ser_curr_food )
					{
						$curr_food = unserialize( $ser_curr_food );
						if ( is_array($curr_food->foodline ) )
						{
							foreach ($curr_food->foodline as $ser_foodline_item)
							{
								$foodline_item = unserialize($ser_foodline_item);
								if ($foodline_item->materialid != $foodline_item->orig_materialid)
								{
									$current_total += $foodline_item->dprice;
									$curr_inner_total += $foodline_item->dprice;
								}
							}
						}
						if ( is_array($curr_food->topping ) )
						{
							foreach ($curr_food->topping as $ser_tmp_topp)
							{
								$curr_tmp_topp = unserialize($ser_tmp_topp);
								$current_total += $curr_tmp_topp->dprice;
								$curr_inner_total += $curr_tmp_topp->dprice;
							}
						}
						$curr_food->dprice_total = $curr_inner_total;
						$curr_inner_total = 0;
						$obj->food_list[$icounter] = serialize($curr_food);
						$icounter += 1;
					}
 						
					$cart_item->current_food = serialize($obj);
					$the_cart_array[$icart_counter] = serialize($cart_item);
				}
				else
				{
					$curr_inner_total = $obj->dprice;
					if ( is_array($obj->foodline ) )
					{
						foreach ($obj->foodline as $ser_foodline_item)
						{
							$foodline_item = unserialize($ser_foodline_item);
							if ($foodline_item->materialid != $foodline_item->orig_materialid)
							{
								$current_total += $foodline_item->dprice;
								$curr_inner_total += $foodline_item->dprice;
							}
						}
					}
					if ( is_array($obj->topping ) )
					{
						foreach ($obj->topping as $ser_tmp_topp)
						{
							$curr_tmp_topp = unserialize($ser_tmp_topp);
							$current_total += $curr_tmp_topp->dprice;
							$curr_inner_total += $curr_tmp_topp->dprice;
						}
					}
					$obj->dprice_total = $curr_inner_total;
					$cart_item->current_food = serialize($obj);
					$the_cart_array[$icart_counter] = serialize($cart_item);
				}
				$current_total = $current_total * $obj->quantity;
		        $scurrent_total = my_format_currency($current_total);
				$_SESSION['Email_Success_Body_HTML'] .= "<tr><td>{$obj->sdescr_parent}/{$obj->sdescr} X{$obj->quantity}</td><td>{$scurrent_total}</td></tr>";
				$_SESSION['Email_Success_Body_Simple'] .= "{$obj->sdescr_parent}/{$obj->sdescr} X{$obj->quantity}:{$scurrent_total}\r\n ";
				
				$final_total += round($current_total, 2);
				$last_item_count = $icart_counter + 1;
			}
			$icart_counter++;          
		}		// Loop to get the total  END
		
		
		// Set the Discount
		$website_discount_factore = 1.0;
		$display_discount = 0;
		if (isset($_SESSION['WebSiteDiscount_float']))
		{
			if ($_SESSION['WebSiteDiscount_float'] > 0 )
			{
				$website_discount_factore = 1 - $_SESSION['WebSiteDiscount_float'];
				$display_discount = $_SESSION['WebSiteDiscount_float'] * 100;
			}
		}
		$original_final_total = $final_total;
		$final_total = $final_total * $website_discount_factore;
		$remaining_final_total = $final_total;
		
		$soriginal_final_total = my_format_currency($original_final_total);
		$_SESSION['Email_Success_Body_HTML'] .= "<tr><td><b>{$language_array["Total"]}</b></td><td>{$soriginal_final_total}</td></tr>";
		$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Total"]}={$soriginal_final_total}\r\n ";
		if ($final_total != $original_final_total)
		{
			$printable_discount = $_SESSION['WebSiteDiscount_float'] * 100;
			$sfinal_total = my_format_currency($final_total);
			$_SESSION['Email_Success_Body_HTML'] .= "<tr><td><b>{$language_array["Total"]} {$language_array["With"]} {$printable_discount}% {$language_array["discount"]}</b></td><td>{$sfinal_total}</td></tr>";
			$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Total"]} {$language_array["With"]} {$printable_discount}% {$language_array["discount"]}={$sfinal_total}\r\n ";
		}
		$_SESSION['Email_Success_Body_HTML'] .= "</table></body></html>";
		$_SESSION['Email_Success_Body_HTML'] .= "<p>{$language_array["Thank you for your order"]}</p>";
		$_SESSION['Email_Success_Body_Simple'] .= "{$language_array["Thank you for your order"]}\r\n ";


		
		
		if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
		{
			$result = mysqli_query($mysqli, "INSERT INTO torder ( wCustomerContactID, dTotalExVAT, dVAT, dTotalIncVAT, dFinalTotal, dDiscount, sOrderNo ) " .
					"VALUES ({$_SESSION['customer_wcontactid']},{$final_total}, 0, {$final_total}, {$final_total}, $display_discount, '{$_SESSION['the_cart_order_uniq_id']}' ) " );
		}
		else 
		{
			$result = true;
		}

		if (!$result)
		{
			$berror = true;
		}
		else
		{
			if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
			{
				$new_id = mysqli_insert_id($mysqli);
			}
			else 
			{
				$new_id = 1;
			}
			if ( $new_id > 0 )
			{
				$order_log_str = $order_log_str . number_to_str_with_length(6, 5);
				$order_log_str = $order_log_str . "torder";
				$str_tmp = "";
				$str_tmp = $str_tmp . number_to_str_with_length($new_id, 20);
				$str_tmp = $str_tmp . number_to_str_with_length($_SESSION['customer_wcontactid'], 20);
				$str_tmp = $str_tmp . number_to_str_with_length($final_total, 25);
				$str_tmp = $str_tmp . number_to_str_with_length(0, 25);
				$str_tmp = $str_tmp . number_to_str_with_length($final_total, 25);
				$str_tmp = $str_tmp . number_to_str_with_length($final_total, 25);
				$str_tmp = $str_tmp . number_to_str_with_length($display_discount, 25);
				if (isset($_REQUEST['paypal']) && decode_str_gr($_REQUEST['paypal']) == "paypal" )
				{
					$str_tmp = $str_tmp . number_to_str_with_length(1, 1);
				}
				else 
				{
					$str_tmp = $str_tmp . number_to_str_with_length(0, 1);
				}
				$str_tmp = $str_tmp . str_to_str_with_length($_SESSION['the_cart_order_uniq_id'], 50);
				$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
				$order_log_str = $order_log_str . $str_tmp;
				
				$cart_item_bundle_no = 1;
				$icounter = 0;
				$first_new_clientid = 0;
				//$cart_item_count = sizeof($the_cart_array);
				$icounter_cart = 1;
				
				// Loop to build the order details in the orderlog
				// Loop the cart items
				foreach ($the_cart_array as $ser_cart_item)
				{
					$cart_item = unserialize($ser_cart_item);
				
					if ( $cart_item->isdeleted == 0 )
					{
						$obj = unserialize($cart_item->current_food);
						$quantity_counter = 0;
						$total_quantity = $obj->quantity;
						// multiquantity
						if ( $obj->itype == 2 )
						{
							$isfixedprice = 1;
							$Ismultiqty = 1;
							$total_quantity = 1;
						}
							
						// Loop to separate the items with multiple quantity that  ($obj->itype != 2)
						for ($quantity_counter = 0; $quantity_counter < $total_quantity; $quantity_counter++)
						{
							$isfixedprice = 0; 
							$Ismultiqty = 0;
							$icounter +=1;
	
							
							// Bundle
							if ($obj->itype == 1)
							{
								$bundle_item_count = sizeof($the_cart_array);
								$icounter_bundle = 1;
								
								// Loop each Item in the bundle
								foreach( $obj->food_list as $ser_curr_food )
								{
									$curr_food = unserialize( $ser_curr_food );
									
									if ($last_item_count == $icounter_cart && $quantity_counter == $total_quantity && $bundle_item_count == $icounter_bundle)
									{
										$dprice_total = $remaining_final_total;
									}
									else 
									{
										$dprice_total = $curr_food->dprice_total * $website_discount_factore;
										$remaining_final_total = $remaining_final_total - $dprice_total; 
									}
									
									
									if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
									{
										$result = mysqli_query($mysqli,
												" INSERT INTO torderline ( worderid, foodid, dPiece, dprice, dvat, dtotal, iorder, bundleno, bundleid, isfreetoppings, ipartno, isfixedprice, Ismultiqty ) " .
												" VALUES ({$new_id}, {$curr_food->foodid}, 1, {$dprice_total}, 0, " .
												"         {$dprice_total}, {$icounter}, {$cart_item_bundle_no}, {$obj->foodid}, {$obj->bundle_freetoppings}, " .
												"         1, {$isfixedprice}, {$Ismultiqty} ) " );
									}
									else
									{
										$result = true;
									}
										
									if (!$result)
									{
										$berror = true;
									}
									else
									{
										$new_clientid = mysqli_insert_id($mysqli);
										if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
										{
											$new_clientid = mysqli_insert_id($mysqli);
										}
										else 
										{
											$new_clientid = 1;
										}
										if ( $new_clientid > 0 )
										{
											$order_log_str = $order_log_str . number_to_str_with_length(10, 5);
											$order_log_str = $order_log_str . "torderline";
											$str_tmp = "";
											$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
											$str_tmp = $str_tmp . number_to_str_with_length($new_id, 20);
											$str_tmp = $str_tmp . number_to_str_with_length($curr_food->foodid, 10);
											$str_tmp = $str_tmp . number_to_str_with_length(1, 25);
											$str_tmp = $str_tmp . number_to_str_with_length($dprice_total, 25);
											$str_tmp = $str_tmp . number_to_str_with_length(0, 25);
											$str_tmp = $str_tmp . number_to_str_with_length($dprice_total, 25);
											$str_tmp = $str_tmp . number_to_str_with_length($icounter, 11);
											$str_tmp = $str_tmp . number_to_str_with_length($cart_item_bundle_no, 11);
											$str_tmp = $str_tmp . number_to_str_with_length($obj->foodid, 10);
											$str_tmp = $str_tmp . number_to_str_with_length($obj->bundle_freetoppings, 1);
											$str_tmp = $str_tmp . number_to_str_with_length(1, 11);
											$str_tmp = $str_tmp . number_to_str_with_length($isfixedprice, 1);
											$str_tmp = $str_tmp . number_to_str_with_length($Ismultiqty, 1);
											$str_tmp = $str_tmp . str_to_str_with_length($cart_item->comment, 200);
											$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
											$order_log_str = $order_log_str . $str_tmp;
												
											
											if ($first_new_clientid == 0)
												$first_new_clientid = $new_clientid; 
											
											if ( $curr_food->foodvariationid > 0 )
											{
												
												$order_log_str = $order_log_str . number_to_str_with_length(12, 5);
												$order_log_str = $order_log_str . "tolvariation";
												$str_tmp = "";
												$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
												$str_tmp = $str_tmp . number_to_str_with_length($curr_food->foodvariationid, 10);
												$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
												$order_log_str = $order_log_str . $str_tmp;
										
											}
											if ( is_array($curr_food->foodline ) )
											{
												foreach ($curr_food->foodline as $ser_foodline_item)
												{
													$foodline_item = unserialize($ser_foodline_item);

													$order_log_str = $order_log_str . number_to_str_with_length(11, 5);
													$order_log_str = $order_log_str . "tolfoodline";
													$str_tmp = "";
													$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
													$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->materialid, 10);
													$str_tmp = $str_tmp . number_to_str_with_length(1, 25);
													$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->binclude, 1);
													$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->dprice, 25);
													$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->orig_materialid, 10);
													$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
													$order_log_str = $order_log_str . $str_tmp;
													
												}
											}
											if ( is_array($curr_food->topping ) )
											{
												foreach ($curr_food->topping as $ser_tmp_topp)
												{
													$curr_tmp_topp = unserialize($ser_tmp_topp);

													$order_log_str = $order_log_str . number_to_str_with_length(10, 5);
													$order_log_str = $order_log_str . "toltopping";
													$str_tmp = "";
													$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
													$str_tmp = $str_tmp . number_to_str_with_length($curr_tmp_topp->toppingid, 10);
													$str_tmp = $str_tmp . number_to_str_with_length($curr_tmp_topp->dprice, 25);
													$str_tmp = $str_tmp . number_to_str_with_length(1, 11);
													$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
													$order_log_str = $order_log_str . $str_tmp;
													
												}
											}
											
										}
									}
									
									$icounter_bundle ++;
								}
								
								$order_log_str = $order_log_str . number_to_str_with_length(9, 5);
								$order_log_str = $order_log_str . "tolbundle";
								$str_tmp = "";
								$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
								$str_tmp = $str_tmp . number_to_str_with_length($obj->foodvariationid, 10);
								$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
								$order_log_str = $order_log_str . $str_tmp;
								
								$cart_item_bundle_no ++;
								
								
							}// Bundle END
							
							elseif ( $obj->itype == 2 ) // multiquantity
							{
								$obj_dprice = $obj->dprice * $website_discount_factore;
								$Ismultiqty = 1;
								
								$multi_total_price = $obj_dprice * $obj->quantity;

								if ($last_item_count == $icounter_cart && $quantity_counter == $total_quantity )
								{
									$multi_total_price = $remaining_final_total;
								}
								else
								{
									$remaining_final_total = $remaining_final_total - $multi_total_price;
								}
								
								if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
								{
									$result = mysqli_query($mysqli,
											" INSERT INTO torderline ( worderid, foodid, dPiece, dprice, dvat, dtotal, iorder, bundleno, bundleid, isfreetoppings, ipartno, isfixedprice, Ismultiqty ) " .
											" VALUES ({$new_id}, {$obj->foodid}, {$obj->quantity}, {$obj_dprice}, 0, " .
											"         {$multi_total_price}, {$icounter}, {$cart_item->bundle_no}, {$obj->bundleid}, {$obj->bundle_freetoppings}, " .
											"         1, {$isfixedprice}, {$Ismultiqty} ) " );
								}
								else
								{
									$result = true;
								}
								
								if (!$result)
								{
									$berror = true;
								}
								else
								{
									if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
									{
										$new_clientid = mysqli_insert_id($mysqli);
									}
									else 
									{
										$new_clientid = 1;
									}
									if ( $new_clientid > 0 )
									{
										$order_log_str = $order_log_str . number_to_str_with_length(10, 5);
										$order_log_str = $order_log_str . "torderline";
										$str_tmp = "";
										$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
										$str_tmp = $str_tmp . number_to_str_with_length($new_id, 20);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->foodid, 10);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->quantity, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($obj_dprice, 25);
										$str_tmp = $str_tmp . number_to_str_with_length(0, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($multi_total_price, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($icounter, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($cart_item->bundle_no, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->bundleid, 10);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->bundle_freetoppings, 1);
										$str_tmp = $str_tmp . number_to_str_with_length(1, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($isfixedprice, 1);
										$str_tmp = $str_tmp . number_to_str_with_length($Ismultiqty, 1);
										$str_tmp = $str_tmp . str_to_str_with_length($cart_item->comment, 200);
										$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
										$order_log_str = $order_log_str . $str_tmp;
										
										
										if ( $obj->foodvariationid > 0 )
										{
											$order_log_str = $order_log_str . number_to_str_with_length(12, 5);
											$order_log_str = $order_log_str . "tolvariation";
											$str_tmp = "";
											$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
											$str_tmp = $str_tmp . number_to_str_with_length($obj->foodvariationid, 10);
											$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
											$order_log_str = $order_log_str . $str_tmp;
										}
									}
								}
									
							} // multiquantity END
							
							else // not a Bundle && not a multiquantity
							{
								$obj_dprice_total = $obj->dprice_total * $website_discount_factore;
								
								if ($last_item_count == $icounter_cart && $quantity_counter == $total_quantity)
								{
									$obj_dprice_total = $remaining_final_total;
								}
								else
								{
									$remaining_final_total = $remaining_final_total - $obj_dprice_total;
								}
								
								if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
								{
									$result = mysqli_query($mysqli,
											" INSERT INTO torderline ( worderid, foodid, dPiece, dprice, dvat, dtotal, iorder, bundleno, bundleid, isfreetoppings, ipartno, isfixedprice, Ismultiqty ) " .
											" VALUES ({$new_id}, {$obj->foodid}, 1, {$obj_dprice_total}, 0, " .
											"         {$obj_dprice_total}, {$icounter}, {$cart_item->bundle_no}, {$obj->bundleid}, {$obj->bundle_freetoppings}, " .
											"         1, {$isfixedprice}, {$Ismultiqty} ) " );
								}
								else
								{
									$result = true;
								}
								
								if (!$result)
								{
									$berror = true;
								}
								else
								{
									if (isset($_SESSION['test_user']) && $_SESSION['test_user'] == 0)
									{
										$new_clientid = mysqli_insert_id($mysqli);
									}
									else 
									{
										$new_clientid = 1;
									}
									if ( $new_clientid > 0 )
									{
										$order_log_str = $order_log_str . number_to_str_with_length(10, 5);
										$order_log_str = $order_log_str . "torderline";
										$str_tmp = "";
										$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
										$str_tmp = $str_tmp . number_to_str_with_length($new_id, 20);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->foodid, 10);
										$str_tmp = $str_tmp . number_to_str_with_length(1, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($obj_dprice_total, 25);
										$str_tmp = $str_tmp . number_to_str_with_length(0, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($obj_dprice_total, 25);
										$str_tmp = $str_tmp . number_to_str_with_length($icounter, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($cart_item->bundle_no, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->bundleid, 10);
										$str_tmp = $str_tmp . number_to_str_with_length($obj->bundle_freetoppings, 1);
										$str_tmp = $str_tmp . number_to_str_with_length(1, 11);
										$str_tmp = $str_tmp . number_to_str_with_length($isfixedprice, 1);
										$str_tmp = $str_tmp . number_to_str_with_length($Ismultiqty, 1);
										$str_tmp = $str_tmp . str_to_str_with_length($cart_item->comment, 200);
										$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
										$order_log_str = $order_log_str . $str_tmp;
										
										
										
										
										if ( $obj->foodvariationid > 0 )
										{
											$order_log_str = $order_log_str . number_to_str_with_length(12, 5);
											$order_log_str = $order_log_str . "tolvariation";
											$str_tmp = "";
											$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
											$str_tmp = $str_tmp . number_to_str_with_length($obj->foodvariationid, 10);
											$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
											$order_log_str = $order_log_str . $str_tmp;
											
										}
										if ( is_array($obj->foodline ) )
										{
											foreach ($obj->foodline as $ser_foodline_item)
											{
												$foodline_item = unserialize($ser_foodline_item);

												$order_log_str = $order_log_str . number_to_str_with_length(11, 5);
												$order_log_str = $order_log_str . "tolfoodline";
												$str_tmp = "";
												$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
												$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->materialid, 10);
												$str_tmp = $str_tmp . number_to_str_with_length(1, 25);
												$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->binclude, 1);
												$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->dprice, 25);
												$str_tmp = $str_tmp . number_to_str_with_length($foodline_item->orig_materialid, 10);
												$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
												$order_log_str = $order_log_str . $str_tmp;
											}
										}
										if ( is_array($obj->topping ) )
										{
											foreach ($obj->topping as $ser_tmp_topp)
											{
												$curr_tmp_topp = unserialize($ser_tmp_topp);

												$order_log_str = $order_log_str . number_to_str_with_length(10, 5);
												$order_log_str = $order_log_str . "toltopping";
												$str_tmp = "";
												$str_tmp = $str_tmp . number_to_str_with_length($new_clientid, 20);
												$str_tmp = $str_tmp . number_to_str_with_length($curr_tmp_topp->toppingid, 10);
												$str_tmp = $str_tmp . number_to_str_with_length($curr_tmp_topp->dprice, 25);
												$str_tmp = $str_tmp . number_to_str_with_length(1, 11);
												$order_log_str = $order_log_str . number_to_str_with_length(mb_strlen($str_tmp), 5);
												$order_log_str = $order_log_str . $str_tmp;
												
											}
										}
											
								
									}
								}
									
							} // not a Bundle
							
						}	// for ($quantity_counter)		
							
					} //if ( $cart_item->isdeleted == 0 )
						
					
					$icounter_cart ++;
				
				}//foreach ($the_cart_array as $ser_cart_item)
				
			} //if ( $new_id > 0 )
			else 
			{
				$berror = true;
			}
		}

	}

	if (mb_strlen($order_log_str)>0 && (!isset($_SESSION['test_user']) || $_SESSION['test_user'] == 0))
	{
		$result = mysqli_query($mysqli,
				"INSERT INTO torderlog ( sbody, dtstamp ) " .
				"VALUES ('{$order_log_str}', NOW() ) " );
				
	}
	
	if (!$berror)
	{
		unset($_SESSION['the_cart']);
		unset($_SESSION['the_cart_count']);
		unset($_SESSION['the_cart_order_uniq_id']);
		header('Location:success.the.php?prm=1');
	}
	else 
	{
		header('Location:success.the.php?prm=0');
	}

		
	
?>


