<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

	session_start();

	include_once('language.the.php');
	include_once('dbheader.the.php');
	
	if(!isset ($_SESSION['customer_wid']) || $_SESSION['customer_wid'] == 0 ||
	   !isset($_SESSION['customer_wcontactid']) || $_SESSION['customer_wcontactid'] == 0 )
	{
		header('Location:../index.php');
		die();
	}
	  
	  
	
	include_once('class.the.php');
	include_once('tools.the.php');
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST' && 
		(isset($_POST['submit_on_delivery']) || isset($_POST['submit_creditcard']) ) )
	{
		
		if (isset($_POST["submit_on_delivery"]))
		{
			echo "<script type='text/javascript'>window.location.href='new_order.the.php'</script>";
			exit();
		}
	
	}

	
	
    /* *****************************************************************
     * COMPUTE TOTALS
     * *****************************************************************
     */
	$the_cart_array = unserialize($_SESSION['the_cart']);
	$final_total = 0.0;
	$original_final_total = 0.0;
	if ( is_array($the_cart_array) )
	{
	
		// Loop to get the total
		$icart_counter = 0;
		$last_item_count = 1;
		foreach ($the_cart_array as $ser_cart_item)
		{
			$cart_item = unserialize($ser_cart_item);
	
			if ( $cart_item->isdeleted == 0 )
			{
				$obj = unserialize($cart_item->current_food);
	
				$current_total = $obj->dprice;
				if ($obj->itype == 1)
				{
					$icounter = 0;
					$curr_inner_total = $obj->dprice;
					foreach( $obj->food_list as $ser_curr_food )
					{
						$curr_food = unserialize( $ser_curr_food );
						if ( is_array($curr_food->foodline ) )
						{
							foreach ($curr_food->foodline as $ser_foodline_item)
							{
								$foodline_item = unserialize($ser_foodline_item);
								if ($foodline_item->materialid != $foodline_item->orig_materialid)
								{
									$current_total += $foodline_item->dprice;
									$curr_inner_total += $foodline_item->dprice;
								}
							}
						}
						if ( is_array($curr_food->topping ) )
						{
							foreach ($curr_food->topping as $ser_tmp_topp)
							{
								$curr_tmp_topp = unserialize($ser_tmp_topp);
								$current_total += $curr_tmp_topp->dprice;
								$curr_inner_total += $curr_tmp_topp->dprice;
							}
						}
						$curr_food->dprice_total = $curr_inner_total;
						$curr_inner_total = 0;
						$obj->food_list[$icounter] = serialize($curr_food);
						$icounter += 1;
					}
					$cart_item->current_food = serialize($obj);
					$the_cart_array[$icart_counter] = serialize($cart_item);
				}
				else
				{
					// echo "itype != 1  <br>";
					$curr_inner_total = $obj->dprice;
					if ( is_array($obj->foodline ) )
					{
						foreach ($obj->foodline as $ser_foodline_item)
						{
							$foodline_item = unserialize($ser_foodline_item);
							if ($foodline_item->materialid != $foodline_item->orig_materialid)
							{
								$current_total += $foodline_item->dprice;
								$curr_inner_total += $foodline_item->dprice;
							}
						}
					}
					if ( is_array($obj->topping ) )
					{
						foreach ($obj->topping as $ser_tmp_topp)
						{
							$curr_tmp_topp = unserialize($ser_tmp_topp);
							$current_total += $curr_tmp_topp->dprice;
							$curr_inner_total += $curr_tmp_topp->dprice;
						}
					}
					$obj->dprice_total = $curr_inner_total;
					$cart_item->current_food = serialize($obj);
					$the_cart_array[$icart_counter] = serialize($cart_item);
				}
				$current_total = $current_total * $obj->quantity;
				$final_total += round($current_total, 2);
				$last_item_count = $icart_counter + 1;
			}
			$icart_counter++;
		}		// Loop to get the total  END
	
	
		// Set the Discount
		$website_discount_factore = 1.0;
		if (isset($_SESSION['WebSiteDiscount_float']))
		{
			if ($_SESSION['WebSiteDiscount_float'] > 0 )
			{
				$website_discount_factore = 1 - $_SESSION['WebSiteDiscount_float'];
			}
		}
		$original_final_total = $final_total;
		$final_total = $final_total * $website_discount_factore;
//		$remaining_final_total = $final_total;
		$s_final_total = my_format_currency($final_total);
		
	}
	
	
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	
	if ($mysqli->connect_error)
	{
		echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		exit();
	}
	
	if (!mysqli_select_db($mysqli, $database))
	{
		echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
		exit();
	}
	
	$mysqli->set_charset("utf8");
	
	
	$result = mysqli_query($mysqli,
			" SELECT IFNULL(tcustomercontact.id, 0 ) id, tcustomercontact.wid, tcustomercontact.sHouseNumber,   " .
			"        tstreet.descr as streetdescr, tcustomercontact.sAddress2, tcustomercontact.sStreet, " .
			"        tarea.descr as areadescr, tcustomercontact.sFloor, tpostcode.descr postcodedescr, " .
			"        tcustomercontact.IsDefault, tcustomer.sEmail " .
			"   " .
			" FROM  tcustomercontact  " .
			"  left join tcustomer on tcustomer.id = tcustomercontact.customerID  " .
			"  left join tarea on tarea.id = tcustomercontact.areaID  " .
			"  left join tpostcode on tpostcode.id = tcustomercontact.postcodeID  " .
			"  left join tstreet on tstreet.id = tcustomercontact.StreetID  " .
			" where tcustomercontact.wID = {$_SESSION['customer_wcontactid']}  ".
			" ORDER BY IsDefault DESC, streetdescr ");
	
	
	$customercontact_id = 0;
	$customercontact_wid = 0;
	$customercontact_sHouseNumber = "";
	$customercontact_streetdescr = "";
	$customercontact_sAddress2 = "";
	$customercontact_sStreet = "";
	$customercontact_areadescr = "";
	$customercontact_sFloor = "";
	$customercontact_postcodedescr = "";
	$customercontact_IsDefault = 0;	
	$customercontact_sEmail = "";
	if ($result)
	{
		if (mysqli_num_rows($result) > 0)
		{
			if (list($customercontact_id, $customercontact_wid, $customercontact_sHouseNumber, 
					$customercontact_streetdescr, $customercontact_sAddress2, $customercontact_sStreet, 
					$customercontact_areadescr, $customercontact_sFloor, $customercontact_postcodedescr, 
					$customercontact_IsDefault, $customercontact_sEmail) = mysqli_fetch_row($result))
			{
			}
		}
	}
	
	
	
	
?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" media="screen" href="../css/style_payment.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
        
    <script src="../js/jquery-1.11.3.js"></script>
    <script type="text/javascript">
        
        $(document).ready(function()
        {
		  	var animTime = 300, clickPolice = false;
		  	$(document).on('touchstart click', '.acc-btn', function()
			{
		        if(!clickPolice)
			    {
		       		clickPolice = true;

				    var currIndex = $(this).index('.acc-btn'), targetHeight = $('.acc-content-inner').eq(currIndex).outerHeight();
		   
			      	$('.acc-btn h1').removeClass('selected');
			      	$(this).find('h1').addClass('selected');
			      
			      	$('.acc-content').stop().animate({ height: 0 }, animTime);
			      	$('.acc-content').eq(currIndex).stop().animate({ height: targetHeight }, animTime);
			
			    	setTimeout(function(){ clickPolice = false; }, animTime);
			    }
		    
		  	});
		  
		});
        </script>     

</head>
<body>
<div class="slide" >		
 <div class='banner_msg' >
	<h7><?php echo $language_array["Payment Options"]; ?></h7>
 </div>
 
 <div class="main_box" >
     
     <div class="acc-container">
<div class="acc-btn"><h1 class="selected"><?php echo $language_array["Cash On Delivery"]; ?></h1></div>
<div class="acc-content open">
  <div class="acc-content-inner">
 <form name="redirectpost" method="post" action="payment.the.php">
 <?php 
	if ($customercontact_id == 0)
	{
		echo " <label class='error_message'>" . $language_array["We may contact you to verify the order"] . "</label>";
 	}
	echo " <br> ";
	echo " <br> ";
	echo " <label class='text_message'>" . $language_array["TOTAL PAYMENT"] . ": {$s_final_total}</label>";
 			
 ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
        <input class="buttonsubmit" type="submit" name="submit_on_delivery" Value="<?php echo $language_array["Finalize Order"]; ?>"/>
    
  </form>

  </div>
</div>


 
<?php 


if (isset($_SESSION['WebUsePaypal']) && $_SESSION['WebUsePaypal'] == "1")
{
	$merchant_id = $_SESSION['WebPaypalMerchantID'];
	$paypal_currency = $_SESSION['WebPaypalCurrency'];
	$paypal_live_account = $_SESSION['WebPaypalLiveAccount'];
	$website = $_SESSION['Website_link'];
	
	echo "<div class='acc-btn'><h1>{$language_array['Payment with PayPal']}</h1></div>";
	echo "<div class='acc-content'>";
	echo "  <div class='acc-content-inner'>";
	echo " <br> ";
	echo " <br> ";
	echo " <label class='text_message'>" . $language_array["Total"] . ": {$s_final_total}</label>";
	echo " <br> ";
	echo " <br> ";
	echo " <br> ";
	if ($paypal_live_account == "1")
	{
		echo "<form action='https://www.paypal.com/cgi-bin/webscr' method='post' target='_top'>";
	}
	else 
	{
		echo "<form action='https://www.sandbox.paypal.com/cgi-bin/webscr' method='post' target='_top'>";
	}
	
	if (isset($_SESSION['WebUsePaypal']) && $_SESSION['WebUsePaypal'] == "1")
	{
	}
	
	echo "<input type='hidden' name='cmd' value='_xclick'>";
	echo "<input type='hidden' name='business' value='{$merchant_id}'>";
	
	
	echo "<input type='hidden' name='item_name' value='Total'>";
	echo "<input type='hidden' name='amount' value='{$final_total}'>";
		
	$paypal_str_coded = encode_str_gr('paypal');
	echo "<input type='hidden' name='no_note' value='1'>";
	echo "<input type='hidden' name='no_shipping' value='1'>";
	echo "<input type='hidden' name='currency_code' value='{$paypal_currency}'>";
	echo "<INPUT TYPE='hidden' NAME='return' value='{$website}a1234/new_order.the.php?paypal={$paypal_str_coded}'>";
	echo "<INPUT TYPE='hidden' NAME='cancel_return' value='{$website}shopping_cart.php'>";
	echo "<input type='image' src='https://www.sandbox.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif' height='80px' border='0' name='submit' alt='PayPal – The safer, easier way to pay online!'>";
	echo "</form>";
	echo "</div>";
	echo "</div>";
}

?>

<?php 

$payment_counter = 1;

for ($payment_counter = 1; $payment_counter < 10; $payment_counter++) 
{
	if ( file_exists("../plugin/payment{$payment_counter}.php") )
	{
		include_once("../plugin/payment{$payment_counter}.php");
	}
}

?>

 <div style="padding: 10px 10px; float:left; position: relative;">
 
 <form  method='post' action='../index.php'>
 <input class='buttonkeepshopping' type='submit' name='submit_shop' Value='<?php echo $language_array["Keep on shopping"]; ?>'/>
 </form>
 </div>
 
<div style="padding: 10px 10px; float:left; position: relative;">
 
 <form  method='post' action='../shopping_cart.php'>
 <input class='buttoncart' type='submit' name='submit_cart' Value='<?php echo $language_array["Go to cart"]; ?>'/>
 </form>
 </div>
 </div>
 
</body>
</html>
