<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


session_start();

	if (isset($_REQUEST['prm']) &&
		isset($_REQUEST['prm2']))
	{
		include_once('class.the.php');
		
		$the_cart_array = unserialize($_SESSION['the_cart']);
		$final_total = 0.0;
		$searching_id = $_REQUEST['prm'];
		$add_no = floatval($_REQUEST['prm2']);
		
		if ( is_array($the_cart_array) )
		{
			$counter = 0;
			for ($counter = 0; $counter <= count($the_cart_array) ; $counter++)
			{
				$ser_cart_item = $the_cart_array[$counter];
				$cart_item = unserialize($ser_cart_item);
				$obj = unserialize($cart_item->current_food);
				
				if ( $cart_item->id == $searching_id )
				{
					if ($add_no > 0 || $obj->quantity > 1  )
					{
						$obj->quantity += $add_no;
						$cart_item->current_food = serialize($obj);
						$the_cart_array[$counter] = serialize($cart_item);
						$_SESSION['the_cart'] = serialize($the_cart_array);
					}
						
				}
			}
		}
	}
			
	
	
	
	if (isset($_REQUEST['prm3']) )
	{
		echo "<script type='text/javascript'>window.location.href='../adding_item.php?prm=" . $_REQUEST['prm3'] . "'</script>";
		die();
	}
	else 
	{
		header('Location:../shopping_cart.php');
	}
?>