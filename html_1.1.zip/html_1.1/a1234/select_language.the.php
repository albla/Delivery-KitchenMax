<?php 


/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

session_start();

$actual_link = $_SERVER[HTTP_REFERER];

if (!isset($_REQUEST['prm']))
{
	header('Location:' . $actual_link);
	die();
}
else
{
	$_SESSION["SelectedLanguage"] = $_SESSION["WebLanguage{$_REQUEST['prm']}"];
}
header('Location:' . $actual_link);
die();










?>