<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

	if (!isset($_REQUEST['prm']) || 
		!isset($_REQUEST['prm2'])	)
	{
	 	header('Location:../index.php');
		die();
	}
	  
	session_start();
	
	include_once('dbheader.the.php');
	include_once('class.the.php');
	include_once('tools.the.php');
	
	$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
	$fooddescr = decode_str_gr($_REQUEST['prm2']);

	if (!isset($_SESSION['the_cart']) )
	{
		$_SESSION['the_cart'] = serialize(array());
		$_SESSION['the_cart_count'] = 0;
		$_SESSION['the_cart_id'] = 1;
		
		$prefix = date('yMdHis');
		$urlparts = parse_url($_SESSION['Website_link']);
		if (isset($urlparts['host'])) 
		{
			$prefix = preg_replace("/[^a-zA-Z0-9]+/", "", $urlparts['host']);
		}
		$_SESSION['the_cart_order_uniq_id'] = $prefix . uniqid();
		if (strlen($_SESSION['the_cart_order_uniq_id'])> 50)
		{
			$_SESSION['the_cart_order_uniq_id'] = substr($_SESSION['the_cart_order_uniq_id'], 0,50);
		}
	}

	$itemid = encode_str_gr(strval($_SESSION['the_cart_id']));
	

	if (isset($_SESSION['current_food_class']) )
	{
		$cart_item = new cls_cart_item;
		$current_food_class = unserialize($_SESSION['current_food_class']);
		if (!isset($current_food_class->quantity) || 
			$current_food_class->quantity == null ||
			$current_food_class->quantity == 0	)
		{
			$current_food_class->quantity = 1;
		}
		$cart_item->current_food = serialize($current_food_class);
		$cart_item->bundle_no = 0;
		$cart_item->id = $_SESSION['the_cart_id'];
		$cart_item->isdeleted = 0;
		$cart_item->comment = "";
		
		
		$the_cart = unserialize($_SESSION['the_cart']);
		
		$the_cart[] = serialize($cart_item);
		$_SESSION['the_cart'] = serialize($the_cart);
		$_SESSION['the_cart_count'] ++;
		$_SESSION['the_cart_id'] ++;
		
		unset($_SESSION['current_food_class']);
	}
	
	echo "<script type='text/javascript'>window.location.href='../adding_item.php?prm=" . $itemid . "'</script>";
	die();
	

?>