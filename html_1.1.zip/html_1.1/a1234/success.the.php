<?php 


/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


session_start();


if (!isset($_REQUEST['prm']))
{
	header('Location:../index.php');
	die();
}


?>

    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <script type="text/javascript">
            function closethisasap() 
			{
				<?php 
				include_once('language.the.php');
				if ($_REQUEST['prm'] == "0")
					echo 'alert("' . $language_array["The system seems to experience a technical issue, please, contact the company."] . '");';
				else 
					echo 'alert("' . $language_array["The order placed successfully."] . '");';
				
				?>
				
			    window.location="../index.php";
//			    document.forms["redirectpost"].submit();
			    
            }
        </script>
    </head>
    <body onload="closethisasap();">
				<?php 
				include_once('language.the.php');

				require 'PHPMailerAutoload.php';
				$mail = new PHPMailer;
				//$mail->SMTPDebug = 3;                               // Enable verbose debug output
				$mail->isSMTP();                                      // Set mailer to use SMTP
				$mail->Host = $_SESSION["WebSMTPOutgoingServer"];     // Specify main and backup SMTP servers
				$mail->SMTPAuth = true;                               // Enable SMTP authentication
				$mail->Username = $_SESSION["WebSMTPEmail"];          // SMTP username
				$mail->Password = $_SESSION["WebSMTPPassword"];       // SMTP password
				$mail->SMTPSecure = $_SESSION["WebSMTPSecurityTlsSsl"];     // Enable TLS encryption, `ssl` also accepted
				$mail->Port = $_SESSION["WebSMTPServerPort"];           // TCP port to connect to
				$mail->setFrom($_SESSION["WebSMTPEmail"], 'Mailer');
				$mail->addAddress($_SESSION['customer_email'], $_SESSION['customer_fullname']);     // Add a recipient
				//$mail->addAddress('ellen@example.com');               // Name is optional
				$mail->addReplyTo($_SESSION["WebSMTPEmail"], 'Information');
				//$mail->addCC('cc@example.com');
				//$mail->addBCC('bcc@example.com');
				//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
				//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
				$mail->isHTML(true);                                  // Set email format to HTML
				$mail->Subject = $_SESSION['Email_Success_Subject'];
				$mail->Body    = $_SESSION['Email_Success_Body_HTML'];
				$mail->AltBody = $_SESSION['Email_Success_Body_Simple'];
				
 				$mail->send();
					
 				
 				
				?>

     <form name="redirectpost" method="post" action="../index.html">
    </form>
    
    
    
    </body>
    </html>
