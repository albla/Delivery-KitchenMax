<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */



function my_format_currency($number) 
{
	include('language.the.php');
	return $language_array["currency_symbol"] . number_format($number,2);
}


function number_to_str_with_length($number, $length)
{
	$snumber = "{$number}";
	if(mb_strlen($snumber)< $length)
	{
		$snumber = $snumber . str_repeat(" ", $length - mb_strlen($snumber));
	}
	return $snumber;
}

function str_to_str_with_length($str1, $length)
{
	$str_return = $str1;
	
	if(mb_strlen($str_return)< $length)
	{
		$str_return = $str_return . str_repeat(" ", $length - mb_strlen($str_return));
	}
	return $str_return;
}



// ENGLISH ONLY
// $pass_table = array("0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm",
// 		"1T92xcvnm3dfghj8QW7P0DlzASF6CbRYUVBNMqwerGHJKskLZXEIO45tyuiopa",
// 		"5tyuzRP0DlGHY2xcdfghj8F6QW7JKskopEIO4LZXiUVBNMqwer1ASvnm3CbT9a",
// 		"UVMqwer1ASvG5tyuzRnm3CbT9aBNP0DlHfghj8F6QY2xcdW7JKskopEIO4LZXi",
// 		"vGMRLZyu5tmBNzXiP1AS6fghj0DlH3CbT9aFUVer8QEIYnqwO42xcdW7JKskop",
// 		"GXiP15bMRLUmVevZyuBNQEIH3CYnxcdtzqwO42JKskoT9aFr8ApS6fghj0DlW7",
// 		"JKsNQcdP1FW3CYnZv8A7yuBIHtzqrxT9EaoGXipS6fghj0wO42Dlk5bMRLUmVe",
// 		"Zv8A7yuBI0SXO42D6fgwbMG1Htzlk5iphjVeRLFQcdPqrUmJW3CYnsNKxT9Eao",
// 		"NKxTv8A7yuB9EaoZSXO42D1Hiph6fgMI0GbeRLFQcdPqrUtzlk5jVwmJW3CYns",
// 		"P4zlk5jVwmJI0NvA7yW9EaoZSXOGbe3KxTCYns2D1Hiph6fgM8uBRLFQcdqrUt");


function encode_str_gr($str)
{
	$i_key_index = 0;
	$s_current_char = "";
	$main_str_len = strlen($str);
	$pass_table = array(utf8_encode ( "0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnmΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίόύώ"),
			utf8_encode ( "1T92xcvnm3dfghj8QW7P0DlzASF6CbRYUVBNMqwerGHJKskLZXEIO45tyuiopaώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίόύ"),
			utf8_encode ( "5tyuzRP0DlGHY2xcdfghj8F6QW7JKskopEIO4LZXiUVBNMqwer1ASvnm3CbT9aώύΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίό"),
			utf8_encode ( "UVMqwer1ASvG5tyuzRnm3CbT9aBNP0DlHfghj8F6QY2xcdW7JKskopEIO4LZXiόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήί"),
			utf8_encode ( "vGMRLZyu5tmBNzXiP1AS6fghj0DlH3CbT9aFUVer8QEIYnqwO42xcdW7JKskopίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέή"),
			utf8_encode ( "GXiP15bMRLUmVevZyuBNQEIH3CYnxcdtzqwO42JKskoT9aFr8ApS6fghj0DlW7ήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέ"),
			utf8_encode ( "JKsNQcdP1FW3CYnZv8A7yuBIHtzqrxT9EaoGXipS6fghj0wO42Dlk5bMRLUmVeέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωά"),
			utf8_encode ( "Zv8A7yuBI0SXO42D6fgwbMG1Htzlk5iphjVeRLFQcdPqrUmJW3CYnsNKxT9EaoάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψω"),
			utf8_encode ( "NKxTv8A7yuB9EaoZSXO42D1Hiph6fgMI0GbeRLFQcdPqrUtzlk5jVwmJW3CYnsωάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψ"),
			utf8_encode ( "P4zlk5jVwmJI0NvA7yW9EaoZSXOGbe3KxTCYns2D1Hiph6fgM8uBRLFQcdqrUtχψωάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφ"));
	
	$zero_string = $pass_table[0];
	$str_encoded = str_repeat(" ", $main_str_len);
	try 
	{
		for ($i = 0; $i < $main_str_len; $i++)
		{
			$s_current_char = $str[$i];
			$i_key_index = ($i + 3) % count($pass_table);
			$pos = strpos( $zero_string, $s_current_char );
			if ($pos === false )
			{
				$str_encoded[$i] = $s_current_char;
			}
			else
			{
				$str_encoded[$i] = $pass_table[$i_key_index][$pos];
			}
		}
	}
	catch (Exception $e)
	{
	}

	return $str_encoded;
}


function decode_str_gr($str_coded)
{
	$i_key_index = 0;
	$s_current_char = "";
	$main_str_len = strlen($str_coded);
	$pass_table = array(utf8_encode ( "0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnmΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίόύώ"),
			utf8_encode ( "1T92xcvnm3dfghj8QW7P0DlzASF6CbRYUVBNMqwerGHJKskLZXEIO45tyuiopaώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίόύ"),
			utf8_encode ( "5tyuzRP0DlGHY2xcdfghj8F6QW7JKskopEIO4LZXiUVBNMqwer1ASvnm3CbT9aώύΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίό"),
			utf8_encode ( "UVMqwer1ASvG5tyuzRnm3CbT9aBNP0DlHfghj8F6QY2xcdW7JKskopEIO4LZXiόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήί"),
			utf8_encode ( "vGMRLZyu5tmBNzXiP1AS6fghj0DlH3CbT9aFUVer8QEIYnqwO42xcdW7JKskopίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέή"),
			utf8_encode ( "GXiP15bMRLUmVevZyuBNQEIH3CYnxcdtzqwO42JKskoT9aFr8ApS6fghj0DlW7ήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέ"),
			utf8_encode ( "JKsNQcdP1FW3CYnZv8A7yuBIHtzqrxT9EaoGXipS6fghj0wO42Dlk5bMRLUmVeέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωά"),
			utf8_encode ( "Zv8A7yuBI0SXO42D6fgwbMG1Htzlk5iphjVeRLFQcdPqrUmJW3CYnsNKxT9EaoάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψω"),
			utf8_encode ( "NKxTv8A7yuB9EaoZSXO42D1Hiph6fgMI0GbeRLFQcdPqrUtzlk5jVwmJW3CYnsωάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψ"),
			utf8_encode ( "P4zlk5jVwmJI0NvA7yW9EaoZSXOGbe3KxTCYns2D1Hiph6fgM8uBRLFQcdqrUtχψωάέήίόύώΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφ"));
	
	
	$zero_string = $pass_table[0];
	$str_decoded = str_repeat(" ", $main_str_len);

	try
	{
		for ($i = 0; $i < $main_str_len; $i++)
		{
			$s_current_char = $str_coded[$i];
			$i_key_index = ($i + 3) % count($pass_table);
			$pos = strpos( $pass_table[$i_key_index] , $s_current_char );
			if ($pos === false )
			{
				$str_decoded[$i] = $s_current_char;
			}
			else
			{
				$str_decoded[$i] = $zero_string[ $pos ];
			}
		}
	}
	catch (Exception $e)
	{
	}

	return $str_decoded;
}


function get_next_url($ser_obj)
{
	$obj = unserialize($ser_obj);
	$next_url = "";
	
	while (strlen($next_url) == 0 && $obj->current_step < count($obj->url_array) )
	{
		if ($obj->current_step_inner == -1)
		{
			$obj->current_step = 0;
			$obj->current_step_inner = 0;
		}
		else
		{
			if ( $obj->current_step_inner + 1 < count($obj->url_array[$obj->current_step]) )
			{
				$obj->current_step_inner ++;
			}
			else
			{
				$obj->current_step ++;
				$obj->current_step_inner = 0;
			}
		}
		if (count($obj->url_array[$obj->current_step]) > 0)
		{
			$next_url = $obj->url_array[$obj->current_step][$obj->current_step_inner];
		}
	}
	return(array($next_url, $obj));
}



function LoadSessionVars()
{
	session_start();
	
	if (!isset($_SESSION['WebPageOpenTime'] ))
	{
		include_once('dbheader.the.php');
		include_once('class.the.php');
		
		$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
		
		if ($mysqli->connect_error)
		{
			return "";
		}
		
		if (!mysqli_select_db($mysqli, $database))
		{
			return "";
		}
		
		
		$mysqli->set_charset("utf8");
		$new_dir = "images/";
		
		$result = mysqli_query($mysqli,
				" SELECT tparam.sparamname, tparam.sparamvalue   " .
				" FROM tparam  ");
		
		if ($result)
		{
			if (mysqli_num_rows($result) > 0)
			{
				$main_script_body = "";
				$window_script_body = "";
		
				$bfirsttime = true;
				
				while(list($sparamname, $sparamvalue ) = mysqli_fetch_row($result))
				{
					if ($sparamname == 'WebPageOpenTime' )
					{
						$WebPageOpenTime = $sparamvalue;
					}
					elseif ($sparamname == 'WebPageCloseTime')
					{
						$WebPageCloseTime = $sparamvalue;
					}
					elseif ($sparamname == 'WebSiteDiscountEndDate')
					{
						$_SESSION[$sparamname] = DateTime::createFromFormat('d/m/Y', $sparamvalue);
					}
					else
					{
						$_SESSION[$sparamname] = $sparamvalue;
						if ($sparamname == 'WebLanguage1')
						{
							$_SESSION["SelectedLanguage"] = $_SESSION["WebLanguage1"];
						}
						
					}
				} //while end
				
				if (isset($_SESSION['WebTimeZone']))
				{
					if (strlen($_SESSION['WebTimeZone'])>0)
					{
						date_default_timezone_set( $_SESSION['WebTimeZone'] );
					}
				}
				if (isset($WebPageOpenTime))
				{
					$_SESSION['WebPageOpenTime'] = DateTime::createFromFormat('Y-m-d H:i', date("Y-n-j") . ' ' . $WebPageOpenTime);
				}
				if (isset($WebPageOpenTime))
				{
					$_SESSION['WebPageCloseTime'] = DateTime::createFromFormat('Y-m-d H:i', date("Y-n-j") . ' ' . $WebPageCloseTime);
				}
				
				
				
				
			}
		}
		
		if (!isset($_SESSION["footer_item_array"]) )
		{
			$result = mysqli_query($mysqli,
					" SELECT tfooteritem.stitle, tfooteritem.itype, tfooteritem.icolumn, tfooteritem.irow, tfooteritem.iheight   " .
					" FROM tfooteritem  ");
			
			if ($result)
			{
				if (mysqli_num_rows($result) > 0)
				{
			       	$footer_item_array = array();
					while(list($stitle, $itype, $icolumn, $irow, $iheight ) = mysqli_fetch_row($result))
					{
						$new_item = new cls_footer_item;
						$new_item->sbody = $stitle;
						$new_item->itype = $itype;
						$new_item->iheight = $iheight;
						$footer_item_array["{$irow}{$icolumn}"] = serialize( $new_item ); 
					}
       				$_SESSION['footer_item_array'] = serialize($footer_item_array);
				}
			}
				
		}
		
		
	}
	return "";
}



?>