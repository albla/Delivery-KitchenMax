<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2'])	)
{
	header('Location:../index.php');
	die();
}
  
session_start();

include_once('language.the.php');
include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if (isset($_SESSION['tmp_topping_array']) && 
		isset($_SESSION['tmp_topping_array_counter'])	)
	{
		$obj = unserialize($_SESSION['current_food_class']);
		
		if ($obj->itype == 1)
		{
			$obj_child = unserialize( $obj->food_list[$obj->current_step] );
			$obj_child->topping = array();
		}
		else 
			$obj->topping = array();
		
		foreach ($_POST as $key => $value)
		{
			if (substr($key,0,3) == "chk")
			{
				$counter = intval(substr($key,3));
				$curr_tmp_topp = unserialize($_SESSION['tmp_topping_array'][$counter]);
				
				$topp = new cls_topping;
				$topp->toppingid = $curr_tmp_topp->toppingid;
				$topp->dprice = $curr_tmp_topp->dprice;
				$topp->material_descr = $curr_tmp_topp->material_descr;
				
				if ($obj->itype == 1)
					$obj_child->topping[] = serialize($topp);
				else 
					$obj->topping[] = serialize($topp);
			
			}
				
		}
		if ($obj->itype == 1)
			$obj->food_list[$obj->current_step] = serialize($obj_child);
		
		$_SESSION['current_food_class'] = serialize($obj);
		
		for ($counter = 0; $counter <= $_SESSION['tmp_topping_array_counter']; $counter++)
		{
			unset($_SESSION['tmp_topping_array'][$counter]);
		}
		
		unset($_SESSION['tmp_topping_array']);
		unset($_SESSION['tmp_topping_array_counter']);
		
		$ret_array = get_next_url(serialize($obj));
		$next_url = $ret_array[0];
		if (strlen($next_url) > 0 )
		{
			$_SESSION['current_food_class'] = serialize($ret_array[1]);
		}
		echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
		exit();
		
	}

}
else
{
	if (isset($_SESSION['tmp_topping_array']))
	{
		unset($_SESSION['tmp_topping_array']);
	}
	if (isset($_SESSION['tmp_topping_array_counter']))
	{
		unset($_SESSION['tmp_topping_array_counter']);
	}
	
	
}



?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_controls.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body >

<div class="slide" >		


 <div class='banner_msg' >
	<h7><?php echo $language_array["Toppings"]; ?>: <?php echo"{$fooddescr}"; ?></h7>
 </div>
 <form name="redirectpost" method="post" action="<?php echo $url; ?>">
  <div  class='inner-box'>
     <div >
     
     <?php
     
       	include_once('dbheader.the.php');
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			header('Location:../index.php');
			die("Can't connect to database");
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			header('Location:../index.php');
			die("Can't select database");
		}
        
      	$mysqli->set_charset("utf8");
       	$new_dir = "images/";
       	
       	$obj = unserialize($_SESSION['current_food_class']);
       	
       	$hasvariations = false;
       	
       	if ($obj->itype == 1)
       	{
       		$obj_child = unserialize( $obj->food_list[$obj->current_step] );
       		$hasvariations = $obj_child->hasvariations;
       		$variationid = $obj_child->variationid;
       	}
       	else
       	{
       		$hasvariations = $obj->hasvariations;
       		$variationid = $obj->variationid;
       	}
       	
       	
       	
       	if ($hasvariations)
       	{
       		$result = mysqli_query($mysqli, 
       				" SELECT ttopping.id, ttoppingvariation.dprice, tmaterial.Descr  " .
       				" FROM  ttopping  " .
       				"  left join tmaterial on tmaterial.id = ttopping.materialid  " .
       				"  left join ttoppingvariation on ttopping.id = ttoppingvariation.toppingid AND ttoppingvariation.variationid = $variationid " .
       				" where foodid = $foodid  ORDER BY tmaterial.Descr");
       	}
	    else 
	    {
           	if ($obj->itype == 1)
	       	{
	       		$child_foodid = $obj_child->foodid;
		    	$result = mysqli_query($mysqli,
		    			" SELECT ttopping.id, ttopping.dprice, tmaterial.Descr  " .
		    			" FROM  ttopping  " .
		    			"  left join tmaterial on tmaterial.id = ttopping.materialid  " .
		    			" where foodid = $child_foodid  ORDER BY tmaterial.Descr");
	       	}
	       	else
	       	{
		    	$result = mysqli_query($mysqli,
		    			" SELECT ttopping.id, ttopping.dprice, tmaterial.Descr  " .
		    			" FROM  ttopping  " .
		    			"  left join tmaterial on tmaterial.id = ttopping.materialid  " .
		    			" where foodid = $foodid  ORDER BY tmaterial.Descr");
	       	}
	    }
	    
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		$_SESSION['tmp_topping_array'] = array();
	       		$counter = 0;
	       		while(list($id, $dprice, $descr) = mysqli_fetch_row($result))
	       		{
	       			$curr_topping = new cls_topping;
	       			$curr_topping->toppingid = $id;
	       			$curr_topping->dprice = $dprice;
	       			$curr_topping->material_descr = $descr;
	       			 
	       			$_SESSION['tmp_topping_array'][] = serialize($curr_topping);
	       			echo "<div class='chk_class'>";
	       			 
					echo "<div class='squaredOne'>";      
					echo "<input type='checkbox' value='$id' id='chk$counter' name='chk$counter' />";
					echo "<label for='chk$counter'></label>";
					echo "</div>";
	       			echo "<div class='chk_label'>";
					if ($dprice > 0 )
					{
						echo "<label>$descr (+". my_format_currency($dprice) . ")</label>";
					}
					else 
					{
						echo "<label>$descr</label>";
					}
					echo "</div>";
					echo "</div>";
					$counter = $counter + 1; 
	       		}
	       		$_SESSION['tmp_topping_array_counter'] = $counter;
	       		
	       	}
        }
     ?>
     </div>
     <div  style="display: block;position: relative;padding:30px 50px;float:left;clear: left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Next"]; ?>"/>
    </div>
   </div>
  </form>
</div>
</body>
</html>
