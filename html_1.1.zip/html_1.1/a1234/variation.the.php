<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_REQUEST['prm']) || 
	!isset($_REQUEST['prm2'])	)
{
	header('Location:../index.php');
	die();
}
  
session_start();

include_once('language.the.php');
include_once('dbheader.the.php');
include_once('class.the.php');
include_once('tools.the.php');

$foodid = floatval( decode_str_gr($_REQUEST['prm']) );
$fooddescr = decode_str_gr($_REQUEST['prm2']);
if (isset($_REQUEST['prm3']))
{
	$foodbundleid = decode_str_gr($_REQUEST['prm3']);
}

if (!isset($_SESSION['current_food_class']) )
{
	header('Location:../index.php');
	die();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if (isset($_POST["foodvariationid"]) &&
		isset($_POST["dprice"]) &&
		isset($_POST["variationid"]) &&
		isset($_POST["submit"])	)
	{
		$obj = unserialize($_SESSION['current_food_class']);
		
		
		if ($obj->itype == 1)
		{
			$obj_child = unserialize( $obj->food_list[$obj->current_step] );
			$obj_child->foodvariationid = $_POST["foodvariationid"];
			$obj_child->variationid = $_POST["variationid"];
			$obj_child->dprice = 0;
			$obj_child->varationdescr = $_POST["submit"];
			$obj->food_list[$obj->current_step] = serialize($obj_child);
		}
		else
		{
			$obj->foodvariationid = $_POST["foodvariationid"];
			$obj->variationid = $_POST["variationid"];
			$obj->dprice = $_POST["dprice"];
			$obj->varationdescr = $_POST["submit"];
		}
		
		$ret_array = get_next_url(serialize($obj));
		$next_url = $ret_array[0];
		if (strlen($next_url) > 0 )
		{
			$_SESSION['current_food_class'] = serialize($ret_array[1]);
		}
		echo "<script type='text/javascript'>window.location.href='$next_url'</script>";
		exit();
		
	}
	else
	{
		header('Location:../index.php');
		die();
	}
	
}
else
{
	
}



?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <link rel="stylesheet" type="text/css" media="screen" href="../css/style_controls.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>

<div class="slide" >		

      <div class='banner_msg' >
			<h7><?php echo $language_array["Please, Select a Variation"]; ?></h7>
      </div>
      <div style="width: 30%;padding:10px 18px;margin:auto; min-width: 400px;">
     
     <?php
     
       	include_once('dbheader.the.php');
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			header('Location:../index.php');
			die("Can't connect to database");
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			header('Location:../index.php');
			die("Can't select database");
		}
        
      	$mysqli->set_charset("utf8");
       	$new_dir = "images/";
       		 
       	if (isset($foodbundleid))
       	{
       		$result = mysqli_query($mysqli,
       			" SELECT tfoodvariation.id, tfoodvariation.dprice, tvariation.Descr, tfoodvariation.variationid  " .
				" FROM  tfoodbundledetail " . 
				"             left join tfoodvariation on tfoodbundledetail.foodvariationid = tfoodvariation.id " . 
				"             left join tvariation on tvariation.id = tfoodvariation.variationid " . 
       			" where  tfoodbundledetail.foodbundleid = $foodbundleid  and tfoodvariation.foodid = $foodid " . 
       			" ORDER BY tvariation.Descr");
       		
       	}
       	else 
       	{
       		$result = mysqli_query($mysqli, 
       				" SELECT tfoodvariation.id, tfoodvariation.dprice, tvariation.Descr, tfoodvariation.variationid  " .
       				" FROM  tfoodvariation  " .
       				"  left join tvariation on tvariation.id = tfoodvariation.variationid  " .
       				" where tfoodvariation.foodid = $foodid  ORDER BY tvariation.Descr");
       	}
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		$counter = 0;
	       		while(list($id, $dprice, $descr, $variationid) = mysqli_fetch_row($result))
	       		{
	       			$prm1 = $_REQUEST['prm'];
	       			$prm2 = $_REQUEST['prm2'];
	       			$tmp_descr = $descr;
	       			if (substr($tmp_descr,1,1) == "." && intval(substr($tmp_descr,0,1))>0 )
	       			{
	       				$tmp_descr = substr($tmp_descr,2);       				
	       			}
	       			
	       			echo "<form name='redirectpost' method='post' action='variation.the.php?prm={$prm1}&prm2={$prm2}' style='width: 100%; min-width: 400px;'>";
	       			echo "<input type='hidden' name='foodvariationid' value='{$id}'>";
	       			echo "<input type='hidden' name='variationid' value='{$variationid}'>";
	       			echo "<input type='hidden' name='dprice' value='{$dprice}'>";
	       			echo "<input class='buttonvariation' type='submit' name='submit' Value='{$tmp_descr}' style='width: 100%;' />";
	       			echo "</form>";

	       			$counter = $counter + 1; 
	       		}
	       	}
        }
     ?>
     </div>
     <div>
<br> 
 <form  method='post' action='../index.php'>
    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Home"]; ?>"/>
    </div>
 </form>
  <br> <br> <br> <br> <br> <br>
</div>

     
</div>

</body>
</html>
