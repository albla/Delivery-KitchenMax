<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */
include_once('a1234/class.the.php');
include_once('a1234/tools.the.php');

session_start();
if (!isset($_SESSION['the_cart']) || !isset($_REQUEST['prm']) )
{
	header('Location:index.php');
	die();
}
$cartid = floatval( decode_str_gr($_REQUEST['prm']) );
if ($_SERVER['REQUEST_METHOD'] == 'POST' )
{
	if (isset($_POST["submit_shop"]) || isset($_POST["submit_cart"]))
	{
		if (isset($_POST["Comments"]))
		{
			if ( strlen( $_POST["Comments"] ) > 0  )
			{
				$the_cart_array = unserialize($_SESSION['the_cart']);
				if ( is_array($the_cart_array) )
				{
					$icounter = 0;
					foreach ($the_cart_array as $ser_cart_item)
					{
						$cart_item = unserialize($ser_cart_item);
				
						if ($cartid == $cart_item->id)
						{
							$cart_item->comment = $_POST["Comments"];
							$the_cart_array[$icounter] = serialize($cart_item);
							$_SESSION['the_cart'] = serialize($the_cart_array);
						}
						$icounter++;
					}
				}
			}
		}
		if (isset($_POST["submit_shop"]))
		{
			header('Location:index.php');
			die();
		}
		if (isset($_POST["submit_cart"]))
		{
			header('Location:shopping_cart.php');
			die();
		}
	}
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style_adding_item.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
	
</head>
<body>
  <!--==============================header=================================-->
 
 <div class="backround-box" style="background-color: rgb(119, 119, 119); opacity: 0.7; cursor: pointer; height: 4528px; display: block;" ></div>
      
<div style="display: block; position: fixed; opacity: 1; z-index: 11000; left: 50%; margin-left: -437px; top: 125px;" >
			<div style="width:874px;height:500px;background:#999;pandding: 40px 40px 40px important;overflow: scroll;">
				
      
 <div style="padding: 10px 10px; width: 98%; height: 96%; float:left; position: relative;">
 
 <form  method='post' action='adding_item.php?prm=<?php echo $_REQUEST['prm']; ?>'>
 
<div class="">
 
 <table>
 <?php 
 include_once('a1234/language.the.php');
 
 	function return_topping_array_html($topping_array) 
 	{
		include('a1234/language.the.php');
		
 		$total = 0.0;
		foreach ($topping_array as $ser_tmp_topp)
		{
			$curr_tmp_topp = unserialize($ser_tmp_topp);
			if ( $curr_tmp_topp->dprice > 0 )
			{
				echo "<br> - " . $language_array["Add"] . " ({$curr_tmp_topp->material_descr} +" . my_format_currency($curr_tmp_topp->dprice) . ") ";
			}
			else 
			{
				echo "<br> - " . $language_array["Add"] . " ({$curr_tmp_topp->material_descr}) ";
			}
			$total += $curr_tmp_topp->dprice;
		}
		return $total;
 	}
 	
 	function return_foodline_array_html($foodline_array)
 	{
		include('a1234/language.the.php');
 		
		$total = 0.0;
 		foreach ($foodline_array as $ser_foodline_item)
 		{
 			$foodline_item = unserialize($ser_foodline_item);
 				
 			if ( $foodline_item->binclude == 0 )
 			{
 				echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr})";
 			}
 			elseif ($foodline_item->materialid != $foodline_item->orig_materialid)
 			{
 				if ($foodline_item->dprice > 0)
 				{
 					echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr}) > " . $language_array["With"] . " ({$foodline_item->material_descr} +" . my_format_currency($foodline_item->dprice) . ") ";
 				}
 				else 
 				{
 					echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr}) > " . $language_array["With"] . " ({$foodline_item->material_descr})";
 				}
 				$total += $foodline_item->dprice;
 			}
 		}
		return $total;
 	}
 	
 	
 	$new_dir = "images/";
	$the_cart_array = unserialize($_SESSION['the_cart']);

	if ( is_array($the_cart_array) )
	{
		foreach ($the_cart_array as $ser_cart_item)
		{
			$cart_item = unserialize($ser_cart_item);
		
			if ($cartid == $cart_item->id)
			{
				if ( $cart_item->isdeleted == 0 )
				{
					$obj = unserialize($cart_item->current_food);
				
					$sFoodPictureid = $obj->foodpictureid;
					$fooddescr = $obj->sdescr;
					$svarationdescr = $obj->varationdescr;
					$current_total = $obj->dprice;
				
					echo "<tr>";
						
					echo "<td class='all_td' style='text-align:center;vertical-align: middle;'>";
					echo "    <img src='{$new_dir}{$sFoodPictureid}.jpg' alt='' title=''style=\"width:80px;height:70px;\">";
					echo "</td>";
						
					echo "<td class='all_td'>";
					echo "<label style='font: bold 20px arial, sans-serif;'>{$obj->sdescr_parent}<br></label>";
					if ($obj->itype == 1)
					{
						echo "<label style='font: bold 18px arial, sans-serif;'>{$fooddescr} (" . my_format_currency($obj->dprice) . ")<br></label>";
						echo "<label style='font: 18px arial, sans-serif;'>";
						foreach( $obj->food_list as $ser_curr_food )
						{
							$curr_food = unserialize( $ser_curr_food );
							$schild_varationdescr = $curr_food->varationdescr;
							$child_fooddescr = $curr_food->sdescr;
							echo "{$curr_food->sdescr_parent} / {$child_fooddescr}";
				
							if ( strlen($schild_varationdescr) > 0 )
							{
								echo " ({$schild_varationdescr})";
							}
							if ( is_array($curr_food->foodline ) )
							{
								$current_total += return_foodline_array_html($curr_food->foodline);
							}
							if ( is_array($curr_food->topping ) )
							{
								$current_total += return_topping_array_html($curr_food->topping);
							}
				
							echo "<br>";
						}
						echo "</label>";
				
					}
					else
					{
						echo "<label style='font: 18px arial, sans-serif;'>";
						echo "{$fooddescr}";
						if ( strlen($svarationdescr) > 0 )
						{
							echo " ({$svarationdescr})";
						}
						echo "</label>";
				
						echo "<label style='font: 16px arial, sans-serif;'>";
						if ( is_array($obj->foodline ) )
						{
							$current_total += return_foodline_array_html($obj->foodline);
						}
						if ( is_array($obj->topping ) )
						{
							$current_total += return_topping_array_html($obj->topping);
						}
						echo "</label>";
					}
					echo "</td>";
						
					echo "<td style='text-align:center;vertical-align: middle;'>";
				
					// multiquantity
					if ( $obj->itype == 2 )
					{
						echo " <label style='font: bold 18px arial, sans-serif;background-color: #eee; padding: 0px 20px 5px 20px'>{$obj->quantity}{$obj->descr_metric} </label>";
					}
					else
					{
						echo "  <a href='a1234/quantity_cart_item.the.php?prm={$cart_item->id}&prm2=-1&prm3=" . $_REQUEST['prm'] . "'><img src='{$new_dir}minus.png' alt='' title=''style=\"width:32px;height:32px;\"></a>";
						echo " <label style='font: bold 16px arial, sans-serif;background-color: #eee; padding: 0px 10px 5px 10px'>{$obj->quantity} </label>";
						echo "  <a href='a1234/quantity_cart_item.the.php?prm={$cart_item->id}&prm2=1&prm3=" . $_REQUEST['prm'] . "''><img src='{$new_dir}plus.png' alt='' title=''style=\"width:32px;height:32px;\"> </a>";
					}
					echo "</td>";
				
					$current_total = $current_total * $obj->quantity;
				
					echo "<td style='font: 18px arial, sans-serif;text-align:center;vertical-align: bottom;'>";
					echo my_format_currency($current_total);
					echo "</td>";
						
					echo "<td style='text-align:center;vertical-align: middle;'>";
					echo "  <a href='a1234/delete_cart_item.the.php?prm={$cart_item->id}&prm3=" . $_REQUEST['prm'] . "'>  <img src='{$new_dir}trash.png' alt='' title=''style=\"width:32px;height:32px;\"> </a>";
					echo "</td>";
						
					echo "</tr>";
						
				
				}				
			}

		}
	}
 
 ?>
 
</table>
 
</div> 
 <br>

   <label class='label-comments' for="Comments"><?php echo $language_array["Comments"]; ?></label>
   <input  class='input-comments' type="text" name="Comments" id="Comments" size="50"  ><br><br><br>
 <input class='buttonkeepshopping' type='submit' name='submit_shop' Value='<?php echo $language_array["Keep on shopping"]; ?>'/>
 <input class='buttoncart' type='submit' name='submit_cart' Value='<?php echo $language_array["Go to cart"]; ?>'/>
 </form>
 </div>
 
			
	</div>
</div>
		

         
</body>
</html>
 
 
 