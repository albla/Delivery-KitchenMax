<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

session_start();

if(!isset ($_SESSION['customer_wid']) || $_SESSION['customer_wid'] == 0 )
{
	header('Location:../index.php');
	die();
}
  
  

include_once('a1234/dbheader.the.php');
include_once('a1234/class.the.php');
include_once('a1234/tools.the.php');


?>



<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style_address.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style_customer.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>     
</head>
<body>

<?php
 include_once("header.php");
 ?>

<div id="slide-customer" style="min-height:700px">		

 <div class='banner_msg' >
<?php
 
	echo "<h7> " . $language_array["Profile"] . " {$_SESSION['customer_fullname']}</h7>";
?>
 </div>
 
  
 <div style="width: 100%;margin-left:auto;margin-right:auto;">
 <form name="redirectpost" method="post" action="index.php">
 
<div class='container_contact'>
<table style="align: center; width:100%;" class="main-data">
<tr>
<td style="width:20%; min-width:200px;"><label class='label-data' >Email</label></td>
<td style="width:0%" colspan="3"><?PHP echo $_SESSION['customer_email']; ?></td>
</tr>
</table>
<br>
</div>
 
     <?php

     
        include_once('a1234/dbheader.the.php');
 	    
        $mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
       
		if ($mysqli->connect_error)
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
			exit();
		}
			 
		if (!mysqli_select_db($mysqli, $database))
		{
			echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
			exit();
		}
        
      	$mysqli->set_charset("utf8");
        		
       	
   		$result = mysqli_query($mysqli, 
   				" SELECT tcustomercontact.id, tcustomercontact.wid, tcustomercontact.sHouseNumber,   " .
				"        tstreet.descr as streetdescr, tcustomercontact.sAddress2, tcustomercontact.sStreet, " .
				"        tarea.descr as areadescr, tcustomercontact.sFloor, tpostcode.descr postcodedescr, " .
				"        tcustomercontact.IsDefault, tcustomercontact.sName, tcustomercontact.sLastName  " .
   				"   " .
   				" FROM  tcustomercontact  " .
   				"  left join tarea on tarea.id = tcustomercontact.areaID  " .
   				"  left join tpostcode on tpostcode.id = tcustomercontact.postcodeID  " .
				"  left join tstreet on tstreet.id = tcustomercontact.StreetID  " .
   				" where tcustomercontact.wCustomerID = {$_SESSION['customer_wid']}  ".
   				" ORDER BY IsDefault DESC, streetdescr ");
       		

       	
        if ($result)
        {
       		if (mysqli_num_rows($result) > 0)
	       	{
	       		echo "<div class='container_contact'>";
	       		echo "<table style='align: center; width:80%;' class='texttable'>";
	
	       		echo "<tr>";
	       		echo "<td  colspan='3'><label  class='contact-header' >" . $language_array["Contacts"] . "</label></td> ";	       		
	       		echo "</tr> ";
	       		
	       		while(list($id, $wid, $sHouseNumber, $streetdescr, $sAddress2, 
	       				   $sStreet, $areadescr, $sFloor, $postcodedescr, 
	       				   $IsDefault, $sName, $sLastName) = mysqli_fetch_row($result))
	       		{
		       		echo "<tr>";
		       		echo "<td style='width:80%'><label  class='label-data' >";
    				if ($IsDefault)
    				{
		       			echo "<label  class='label-important'> * </label>";
    				}
		       		echo "{$sName} {$sLastName} ({$sHouseNumber} {$streetdescr}, {$areadescr})</label></td> ";

		       		echo "<td style='text-align:center;vertical-align: middle;width:10%;'><a href='customercontact.php?prm=" . encode_str_gr(strval($id)) . "' class='edit_button' width='10%'><img border='0' src='images/edit.png' height='28'></a></td>";
    				if ($IsDefault)
    				{
    					echo "<td style='text-align:center;vertical-align: middle;width:10%;'></td>";
    				}
    				else 
    				{
    					echo "<td style='text-align:center;vertical-align: middle;width:10%;'><a href='a1234/delete_customer_contact.the.php?prm=" . encode_str_gr(strval($id)) . "' class='edit_button' ><img border='0' src='images/trash.png' height='28'></a></td>";
    				}
    				echo "</tr> "; 
	       		}

	       		echo "</table>";
	       		echo "</div>";
	       		
	       	}
        }
     ?>
     </div>
    <div  style="display: block;position: relative;padding:30px 50px;float:left;">
        <input class="buttonsubmit" type="submit" name="submit" Value="<?php echo $language_array["Main Menu"]; ?>"/>
    </div>
  </form>
   </div>

<?php
 require("footer.php");
 ?>
 

</body>
</html>



