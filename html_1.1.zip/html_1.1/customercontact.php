<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

session_start();
include_once('a1234/language.the.php');

if(!isset ($_SESSION['customer_wid']) || $_SESSION['customer_wid'] == 0)
{
 	echo "<script type='text/javascript'>window.location.href='index.php'</script>";
 	exit;
}

if (!isset($_REQUEST['prm']) )
{
	header('Location:index.php');
	die();
}

include_once('a1234/dbheader.the.php');
include_once('a1234/tools.the.php');

$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);

if ($mysqli->connect_error)
	die("Can't connect to database");

if (!mysqli_select_db($mysqli, $database))
	die("Can't select database");

$mysqli->set_charset("utf8");
	

function sql_safe($s, $mysqli)
{
	if (get_magic_quotes_gpc())
		$s1 = stripslashes($s);
	else 
		$s1 = $s;
	return $mysqli->real_escape_string($s1);
}

$sName = '';
$sLastName = '';
$sPhone = '';
$sHouseNumber = '';
$StreetID = 0;
$sStreet = '';
$sAddress2 = '';
$sBell = '';
$PostCodeID = 0;
$AreaID = 0;
$sPostcode = '';
$sFloor = '';
$sComments = '';
$IsDefault = true;




if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["submit"]))
{
	
	if (isset($_POST['sName']))
		$sName = $_POST['sName'];
	
	if (isset($_POST['sLastName']))
		$sLastName = $_POST['sLastName'];
	
	if (isset($_POST['sPhone']))
		$sPhone = $_POST['sPhone'];
	if (isset($_POST['sHouseNumber']))
		$sHouseNumber = $_POST['sHouseNumber'];
	
		
// 	if (isset($_POST['cmb_street']))
// 		alert($_POST['cmb_street']);
		
	if (isset($_POST['sStreet']))
		$sStreet = $_POST['sStreet'];
	if (isset($_POST['StreetID']))
		$StreetID = $_POST['StreetID'];
		echo $sStreet;
		
	if (isset($_POST['AreaID']))
		$AreaID = $_POST['AreaID'];
		
	if (isset($_POST['sAddress2']))
		$sAddress2 = $_POST['sAddress2'];
	
	if (isset($_POST['sBell']))
		$sBell = $_POST['sBell'];

	if (isset($_POST['sPostcode']))
		$sPostcode = $_POST['sPostcode'];
	if (isset($_POST['PostCodeID']))
		$PostCodeID = $_POST['PostCodeID'];
	
	
	if (isset($_POST['sComments']))
		$sComments = $_POST['sComments'];
	
	if (isset($_POST['sFloor']))
		$sFloor = $_POST['sFloor'];
	
	if ( strlen($sPhone) == 0 )
		$msg = $msg . '<br>' . $language_array["Please, provide a phone"];
	
	if ( strlen($sName) == 0 )
		$msg =  $msg . '<br>' . $language_array["Please, provide first name"];
	
	if ( strlen($sLastName) == 0 )
		$msg = $msg . '<br>' . $language_array["Please, provide last name"];
	
	if ( strlen($sHouseNumber) == 0 )
		$msg = $msg . '<br>' . $language_array["Please, provide a house number"];
	
	if ( $StreetID<=0 && strlen($sStreet) == 0 )
	{
		$msg =  $msg . '<br>' . $language_array["Please, provide a Street"];
	}

	if ( $AreaID<=0 )
	{
		$msg =  $msg . '<br>' . $language_array["Please, provide an Area"];
	}
	
	
	$sName_safe = trim(sql_safe($sName, $mysqli));
	if (strlen($sName) != strlen($sName_safe))
		$msg =  $msg . '<br>' . $language_array["Invalid First Name"];

	$sLastName_safe = trim(sql_safe($sLastName, $mysqli));
	if (strlen($sLastName) != strlen($sLastName_safe))
		$msg =  $msg . '<br>' . $language_array["Invalid Last Name"];
	
	
	$sPhone_safe = trim(sql_safe($sPhone, $mysqli));
	if (strlen($sPhone) != strlen($sPhone_safe))
	{
		$msg =  $msg . '<br>' . $language_array["Invalid Phone"];
	}
	$sHouseNumber_safe = trim(sql_safe($sHouseNumber, $mysqli));
	if (strlen($sHouseNumber) != strlen($sHouseNumber_safe))
	{
		$msg = $msg . '<br>' . $language_array["Invalid House Number"];
	}

	$sAddress2_safe = trim(sql_safe($sAddress2, $mysqli));
	if (strlen($sAddress2) != strlen($sAddress2_safe))
	{
		$msg = $msg . '<br>' . $language_array["Invalid Address2"];
	}
	
	if (strlen($sStreet) > 0)
	{
		$sStreet_safe = trim(sql_safe($sStreet, $mysqli));
		if (strlen($sStreet) != strlen($sStreet_safe))
		{
			$msg = $msg . '<br>' . $language_array["Invalid Street"];
		}
	}
	
	
	$sBell_safe = trim(sql_safe($sBell, $mysqli));
	if (strlen($sBell) != strlen($sBell_safe))
	{
		$msg = $msg . '<br>' . $language_array["Invalid Door Bell"];
	}

	$sComments_safe = trim(sql_safe($sComments, $mysqli));
	if (strlen($sComments) != strlen($sComments_safe))
	{
		$msg = $msg . '<br>' . $language_array["Invalid Comments"];
	}
		
	if (isset($msg))	
	{
		$msg = $msg . '<br>';
	}
		
	if ( !isset($msg) )
	{
		$pattern = "/^([\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+\.)*[\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+@((((([a-z0-9]{1}[a-z0-9\-]{0,62}[a-z0-9]{1})|[a-z])\.)+[a-z]{2,6})|(\d{1,3}\.){3}\d{1,3}(\:\d{1,5})?)$/i";
		$customercontactid = floatval( decode_str_gr($_REQUEST['prm']) );
		
		$result1 = mysqli_query($mysqli, 
				"UPDATE tcustomercontact ".
				"   SET sName = '$sName', sLastName = '$sLastName', sPhone = '$sPhone', sBell = '$sBell', " . 
				"   sHouseNumber = '$sHouseNumber', StreetID = $StreetID, sStreet = '$sStreet', " . 
				"   sAddress2 = '$sAddress2', sFloor = '$sFloor', sComments = '$sComments', AreaID = $AreaID, " . 
				"   PostCodeID = $PostCodeID, sPostCode = '$sPostcode'  " .
				"WHERE id = $customercontactid", MYSQLI_USE_RESULT);
		if (!$result1)
		{
			$msg = 'Error updating account.' . mysqli_error($mysqli);
		}
		else 
		{
 			echo "<script type='text/javascript'>window.location.href='customer.php'</script>";
 			exit;
		}
	}
}
else 
{
	$customercontactid = floatval( decode_str_gr($_REQUEST['prm']) );
	
	$sQuery = 
			"SELECT sName, sLastName, sPhone, sHouseNumber, IFNULL(StreetID, 0) as StreetID, sStreet, sAddress2, " .
			"       sBell, PostCodeID, AreaID, sPostcode, sFloor, sComments, IsDefault  " .
			" FROM tcustomercontact " .
	        " WHERE tcustomercontact.id = {$customercontactid} ";
	$result = mysqli_query($mysqli, $sQuery);
	if (!$result)
	{
		ini_set('display_errors', 'On');
		$msg  = 'Invalid query: ' . mysqli_error() . "\n";
		$msg .= 'Whole query: ' . $sQuery;
		//die($msg);
		//$jh = $_SESSION['person_id7'];
	}
	else if (mysqli_num_rows($result) > 0)
	{
		list( $sName, $sLastName, $sPhone, $sHouseNumber, $StreetID, $sStreet, $sAddress2, 
			  $sBell, $PostCodeID, $AreaID, $sPostcode, $sFloor, $sComments, $IsDefault) = mysqli_fetch_row($result);
		if ($StreetID > 0)
		{
			$sStreet = "";
		}
	}
	
}
?>
<!--==============================html=========================================================================================-->
<html>
<head>
<title>Register</title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style_login.css">
	<script type="text/javascript" src="sh/shCore.js"></script>
	<script type="text/javascript" src="sh/shBrushJScript.js"></script>
	<link type="text/css" rel="stylesheet" href="sh/shCore.css"/>
	<link type="text/css" rel="stylesheet" href="sh/shThemeDefault.css"/>

	<script type="text/javascript" src="js/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript" src="jquery.searchabledropdown-1.0.8.min.js"></script>
	<script type="text/javascript">
	
	
	$(document).ready(function() 
	{
		$("select").searchable();
		
	});
	
	
	function on_load() 
	{
		validate_street();
		validate_postcode();
	}
	
	function validate_all()
	{
	    var a = document.getElementById("sPassword").value;
	    var b = document.getElementById("sPassword2").value;
	    if (a!=b) 
	    {
// 	    	alert("Passwords do no match");
	    	return false;
	    }
	}
	
	function validate_street() 
	{
	    if (document.getElementById("cmb_street").value == 0)
	    {
	    	document.getElementById("sStreet").disabled =false;
	    }
	    else
		    document.getElementById("sStreet").disabled =true;
	}
	
	function validate_street_other(val) 
	{
	    if (val == '')
	    	document.getElementById("cmb_street").disabled=false;
	    else
	    	document.getElementById("cmb_street").disabled=true;
	}
	
	
	
	function validate_postcode() 
	{
	    if (document.getElementById("cmb_postcode").value == 0)
	    {
	    	document.getElementById("sPostcode").disabled =false;
	    }
	    else
		    document.getElementById("sPostcode").disabled =true;
	}
	
	function validate_postcode_other(val) 
	{
	    if (val == '')
	    	document.getElementById("cmb_postcode").disabled=false;
	    else
	    	document.getElementById("cmb_postcode").disabled=true;
	}
	
	
	</script>
	
	<style>
	 label.error { width: 250px; display: inline; color: red;}
	</style>
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body  onload="on_load()">
<?php
 require("header.php");
?>

<div id="slide-login">		
 
<div style="padding: 20px 20px; background-color: #aaaaaa;">
<h2 class="h2-line"><?php echo $language_array["Contact Details"]; ?></h2> 
        	
<?php
if (isset($msg)) // this is special section for outputing message
{
?>
<p style="font-weight: bold; color: black; background-color: pink"><?=$msg?>
<br>

</p>
<?php
}
?>

<form action="customercontact.php?prm=<?php echo $_REQUEST['prm']; ?>" method="POST" enctype="multipart/form-data"  name="form1" id="form1" >

<table style="align: center; width:100%;" class="texttable">
<tr>
<td style="width:20%"><label  class='label-login' for="sPhone"><?php echo $language_array["Phone"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="tel" name="sPhone" id="sPhone" size="25" value="<?=$sPhone?>"></td>
</tr>
<tr>
<td style="width:20%"><label  class='label-login' for="sName"><?php echo $language_array["First Name"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sName" id="sName" size="25" value="<?=$sName?>"></td>
</tr>

<tr>
<td style="width:20%"><label  class='label-login' for="sLastName"><?php echo $language_array["Last Name"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sLastName" id="sLastName" size="25" value="<?=$sLastName?>"></td>
</tr>
<tr>
<td style="width:20%"><label  class='label-login' for="sHouseNumber"><?php echo $language_array["House No"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sHouseNumber" id="sHouseNumber" size="10" value="<?=$sHouseNumber?>"></td>
</tr>

<tr>
<td style="width:20%"><label  class='label-login' for="sStreet"><?php echo $language_array["Street"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:40%">
<select name="StreetID"  class='input-login'  id="cmb_street" onchange="validate_street()"  style="width:100%"  >
    <option value=-1  <?php if ($StreetID == -1) echo "selected"; ?> ><?php echo $language_array["Select Street"]; ?></option>
    <option value=0   <?php if ($StreetID == 0 ) echo "selected"; ?> ><?php echo $language_array["Not in the list"]; ?></option>
<?php
$result = mysqli_query($mysqli, "SELECT id, descr FROM tstreet ORDER BY descr ");
if ($result)
if (mysqli_num_rows($result) > 0)
{
	while(list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($StreetID == $id )
		{
			echo " <option value={$id} selected >{$descr}</option>";
		}
		else 
		{
			echo " <option value={$id}>{$descr}</option>";
		}
		
	} //end of while
};

?>
</select>
</td>
<td style="width:20%" >
<input  class='input-login' type="text" id="sStreet" name="sStreet" 
           onchange="validate_street_other(this.value)"  
           style="width:100%;text-align: left;" 
           value="<?php echo $sStreet; ?>">
</td>
<td style="width:50%" >
</td>
</tr>



<tr>
<td style="width:20%"><label  class='label-login' for="AreaID"><?php echo $language_array["Area"]; ?></label><label  class='label-important'> *</label></td>
<td style="width:0%"  colspan="3" >
<select name="AreaID"  class='input-login'  id="cmb_Area"  colspan="3" style="width:40%"  >
    <option value=0  <?php if ($AreaID == 0 ) echo "selected"; ?> ><?php echo $language_array["Select Area"]; ?></option>
<?php
$result = mysqli_query($mysqli, "SELECT id, descr FROM tarea ORDER BY descr ");
if ($result)
if (mysqli_num_rows($result) > 0)
{
	while(list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($AreaID == $id )
		{
			echo " <option value={$id} selected >{$descr}</option>";
		}
		else 
		{
			echo " <option value={$id}>{$descr}</option>";
		}
		
	} //end of while
};
?>
</select>
</td>
</tr>



<tr>
<td style="width:20%"><label class='label-login' for="PostcodeID"><?php echo $language_array["Postcode"]; ?></label></td>
<td style="width:0%"  colspan="3"  >
<select name="PostCodeID"  class='input-login'  id="cmb_postcode" onchange="validate_postcode()"  style="width:40%"  >
    <option value=-1 <?php if ($PostCodeID == -1) echo "selected"; ?> ><?php echo $language_array["Select Postcode"]; ?></option>
    
<?php
//<option value=0  <?php if ($PostCodeID ==  0) echo "selected"; ? > ><?php echo $language_array["Not in the list"]; ? ></option>
$result = mysqli_query($mysqli, "SELECT id, descr FROM tpostcode ORDER BY descr ");
if ($result)
if (mysqli_num_rows($result) > 0)
{
	while(list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($PostCodeID == $id)
		{
			echo " <option value={$id} selected >{$descr}</option>";
		}
		else 
		{
			echo " <option value={$id}>{$descr}</option>";
		}
		
	} //end of while
};
?>
</select>
</td>
</tr>


<tr>
<td style="width:20%"><label  class='label-login' for="sAddress2"><?php echo $language_array["Address 2"]; ?></label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sAddress2" id="sAddress2" size="40" value="<?=$sAddress2?>"></td>
</tr>
<tr>
<td style="width:20%"><label  class='label-login' for="sBell"><?php echo $language_array["Door Bell"]; ?></label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sBell" id="sBell" size="25" value="<?=$sBell?>"></td>
</tr>
<tr>
<td style="width:20%"><label  class='label-login' for="sFloor"><?php echo $language_array["Floor"]; ?></label></td>
<td style="width:0%" colspan="3">
<select name="sFloor"   class='input-login' id="sFloor"  colspan="3" style="width:40%"  >
    <option value=""><?php echo $language_array["Select Floor"]; ?></option>
    <option value="Ground" <?php if ($sFloor == "Ground") echo "selected"; ?> ><?php echo $language_array["Ground"]; ?></option>
    <option value="1st" <?php if ($sFloor == "1st") echo "selected"; ?> ><?php echo $language_array["1st"]; ?></option>
    <option value="2nd" <?php if ($sFloor == "2nd") echo "selected"; ?> ><?php echo $language_array["2nd"]; ?></option>
    <option value="3rd" <?php if ($sFloor == "3rd") echo "selected"; ?> ><?php echo $language_array["3rd"]; ?></option>
    <option value="4th" <?php if ($sFloor == "4th") echo "selected"; ?> ><?php echo $language_array["4th"]; ?></option>
    <option value="5th" <?php if ($sFloor == "5th") echo "selected"; ?> ><?php echo $language_array["5th"]; ?></option>
    <option value="6th" <?php if ($sFloor == "6th") echo "selected"; ?> ><?php echo $language_array["6th"]; ?></option>
    <option value="7th" <?php if ($sFloor == "7th") echo "selected"; ?> ><?php echo $language_array["7th"]; ?></option>
    <option value="8th" <?php if ($sFloor == "8th") echo "selected"; ?> ><?php echo $language_array["8th"]; ?></option>
    <option value="9th" <?php if ($sFloor == "9th") echo "selected"; ?> ><?php echo $language_array["9th"]; ?></option>
    <option value="10th" <?php if ($sFloor == "10th") echo "selected"; ?> ><?php echo $language_array["10th"]; ?></option>

</select>

</td>
</tr>
<tr>
<td style="width:20%"><label  class='label-login' for="sComments"><?php echo $language_array["Comments"]; ?></label></td>
<td style="width:0%" colspan="3"><input  class='input-login' type="text" name="sComments" id="sComments" size="50" value="<?=$sComments?>"></td>
</tr>
</table>

<br>
<br><br><input  class="buttonlogin" type="submit" name="submit" value="<?php echo $language_array["Save Changes"]; ?>">
</form>  
<br>
 
</div>
</div>

<?php
 require("footer.php");// same header
 ?>
 
</body>
</html>