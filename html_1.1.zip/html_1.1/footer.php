<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

?>

<!--=================================================footer===========================================================-->
 
<div class="container_footeritem">
 <div class="footeritem_headline">
 <table class="footer_table">
 <?php 
 	include_once('a1234/class.the.php');
 
 	if ( isset($_SESSION["footer_item_array"]) )
 	{
		$new_dir = "images/";
 		$irow = 1;
 		$footer_item_array = unserialize( $_SESSION["footer_item_array"] );
 		for ($irow = 1; $irow < 9; $irow++) 
   		{
   			echo "<tr class='footer_table' style=\"width: 100%\">";
  			for ($icolumn = 1; $icolumn < 4; $icolumn++) 
  			{
  				echo "<td class='footer_table' style=\"width: 33%\">";
  				if ( array_key_exists("{$irow}{$icolumn}", $footer_item_array) )
  				{
  					$curr_footer_item = unserialize($footer_item_array["{$irow}{$icolumn}"]);
  					if ($curr_footer_item->itype == 1)
  					{
  						echo "<a href='info.php?prm={$irow}{$icolumn}'>{$curr_footer_item->sbody}</a> ";
  					}
  				  	elseif ($curr_footer_item->itype == 3)
  					{
  				  		if ( $curr_footer_item->iheight > 0 )
  				  		{
  				  			echo "<img src='{$new_dir}footer_{$icolumn}_{$irow}.jpg' alt='' title=''style='height:{$curr_footer_item->iheight}px;'>";
  				  		}
  				  		else 
  				  		{
  				  			echo "<img src='{$new_dir}footer_{$icolumn}_{$irow}.jpg' alt='' title=''>";
  				  		}
  					}
  					else 
  					{
  						echo "{$curr_footer_item->sbody} ";
  					}
  				}
 					
 				
  				echo "</td>";
  			}
  			echo "</tr>";
   		}
 	}
 
 
 
 ?>
  
</table>
 </div>	    
</div>	   


<div class="container_footer">
 <div class="footer_headline">
 
 
 <br> <br>
    2016  KitchenMax Delivery Online - Website desgine by <a href="http://smobilesoft.com" target="_blank" class="link">SMobileSoft</a></p> 
 </div>	    
</div>	   