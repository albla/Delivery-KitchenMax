<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

include_once('a1234/language.the.php');

?>
<style>


.header_span
{
    top:4px;
    position: relative;
    font-size: 20px;
/*     font-weight: bold; */
    text-shadow: 1px 1px rgba(100,0,0,.7);
    font: 'Lucida sans', Arial, Helvetica;
    text-decoration: none;
}


 /* Dropdown Button */
.dropbtn {
    background-color: rgba( 0, 0, 0, 0.01); 
    color: white;
    padding: 6px;
    border: none;
    cursor: pointer;
    float: right;
    position: relative;
    top:-8px;
    margin: 0px 20px;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
     background-color: rgba( 0, 0, 0, 0.05); 
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 60px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

/* Links inside the dropdown */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}
</style>

 <div class="header_image"  >

 <header >
  <?php 

  $language_html = "";
  if (isset($_SESSION["WebLanguage2"]) && strlen(trim($_SESSION["WebLanguage2"])) > 0 )
  {
  	$language_html = $language_html . "<div class='dropdown'>";
  	$language_html = $language_html . "<button onclick='myFunction()' class='dropbtn'><img src='images/flag_{$_SESSION['SelectedLanguage']}.png' alt='' title=''style='height:32px;'></button>";
  		
  	$language_html = $language_html . "<div id='myDropdown' class='dropdown-content'>";
  	$icounter = 1;
  	while (isset($_SESSION["WebLanguage{$icounter}"]) && strlen($_SESSION["WebLanguage{$icounter}"]) > 0 )
  	{
  		$str_weblang = $_SESSION["WebLanguage{$icounter}"];
  		$language_html = $language_html . "<a href='a1234/select_language.the.php?prm={$icounter}'><img src='images/flag_$str_weblang.png' alt='' title=''style='height:32px;'></a>";
  		$icounter++;
  	}
  	$language_html = $language_html . "</div>";
  	$language_html = $language_html . "</div>";
  }

    
  
  
  
  if(isset ($_SESSION['customer_wid']) && $_SESSION['customer_wid']>0)
  {
  ?>
     <div style="float:right;position: relative;vertical-align: middle; padding:10px;z-index: 10;">
     <?php 
		if (strlen($language_html) > 0)
		{
		 	echo $language_html;
		}
    	echo "<label class='label-username'> <a href='customer.php'> <span class='header_span'>" . $_SESSION['customer_fullname']. "</span></a> </label>";
     
         
     ?>
      
     
	 <a class="loglink" href="a1234/logout.the.php"><img align='center' style='height: 28px;' src='images/logout_<?php echo $_SESSION["SelectedLanguage"];?>.png' ></a>
     <?php 
		if (isset($_SESSION['the_cart']) )
		{
			echo "<span class='header_span'> -</span>  <a class='loglink' href='shopping_cart.php' ><img align='center' style='height: 28px;' src='images/cart_{$_SESSION["SelectedLanguage"]}.png' > ";
			echo "</a>";
			echo "<span class='header_span'>({$_SESSION['the_cart_count']})</span>";
		}
     ?>

  </div>
 <?php 
  }
  else 
  {
 ?>

     <div style="float:right;position: relative;vertical-align: middle; padding:10px;z-index: 10;">
     <?php 
		  if (strlen($language_html) > 0)
		  {
		  	echo $language_html;
		  }
     ?>
     <a class="loglink" href="login.php"><img align='center' style='height: 28px;' src='images/login_<?php echo $_SESSION["SelectedLanguage"];?>.png' ></a> <span class='header_span'> -</span> 
     <a class="loglink" href="register.php"><img align='center' style='height: 28px;' src='images/register_<?php echo $_SESSION["SelectedLanguage"];?>.png' ></a>
     <?php 
		if (isset($_SESSION['the_cart']) )
		{
			
			echo "<span class='header_span'> -</span>  <a class='loglink' href='shopping_cart.php' ><img align='center' style='height: 28px;' src='images/cart_{$_SESSION["SelectedLanguage"]}.png' >";
			echo "</a>";
			echo " <span class='header_span'>({$_SESSION['the_cart_count']})</span>";
		}
     
     ?>
     
     <br>&nbsp;&nbsp;&nbsp;&nbsp;
     
	 </div>
 <?php 
  }
 ?>
 <div style="min-width:700px;">
    <a href="index.php" style="display: block; margin-left: auto; width: 100%; margin-right: auto;clear: right;">
       <img align="center" style="vertical-align: top; max-width: 100%; max-height: 100%;display: block;margin-left: auto;margin-right: auto;" 
           src="images/header_bg.jpg" alt="">
    </a>
 </div>

</div>
   
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>    
</header>  
  