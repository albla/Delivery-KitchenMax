<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @version   1.1
 * @link      http://smobilesoft.com
 *
 */


session_start();

$_SESSION['checkout_mode'] = 0;

?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Kitchen Max</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
<style>

</style>
 <script src='js/prefixfree.min.js'></script>
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">

</head>

<body>

<div class="slide" >		


 <?php
 include_once("header.php");
 ?>


<?php

	include_once('a1234/dbheader.the.php');
	include_once('a1234/tools.the.php');
	
	$ballow_transactions = true;
	
	LoadSessionVars();
	
	if ( isset($_SESSION['WebPageOpenTime']) )
	{
		if (isset($_SESSION['WebTimeZone']))
		{
			if (strlen($_SESSION['WebTimeZone'])>0)
			{
				date_default_timezone_set( $_SESSION['WebTimeZone'] );
			}
		}
		if (time() < strtotime($_SESSION['WebPageOpenTime']->format('Y-m-d H:i:s')) ||
			time() > strtotime($_SESSION['WebPageCloseTime']->format('Y-m-d H:i:s'))  )
		{
			$ballow_transactions = false;
		}
	}
	

	if ( isset($_SESSION['WebPageOnOff']) )
	{
		if ($_SESSION['WebPageOnOff'] == "0")
		{
			$ballow_transactions = false;
		}
			
	}
	
	if(isset($_SESSION['WebSiteDiscount']))
	{
		if (!isset($_SESSION['WebSiteDiscount_float']))
		{
			$_SESSION['WebSiteDiscount_float'] = floatval($_SESSION['WebSiteDiscount']) / 100.0;
		}
		if ($_SESSION['WebSiteDiscount_float'] > 0 && isset($_SESSION['WebPageDiscountMessage']))
		{
			echo "<div class='website-discount'>";
			echo "<p class='marquee'>";
			echo "<span class='line__wrap'>";
			echo "<span class='line'>{$_SESSION['WebPageDiscountMessage']}</span>";
			echo "</span>";
			echo "</p>";
			echo "</div>";
		}
	}


?>




  <div class="tabs" >
  
  <nav role='navigation' class="transformer-tabs">
     <ul>
    <?php
 include_once("navigationbar.php");
 ?>
    </ul>
  </nav>
  <div class="page-wrap">
  

<?php
	
	function echo_price($r_min_prc, $r_max_prc, $r_metricdescr, $r_itype, $css_class_name)
	{
		if ($r_min_prc != $r_max_prc)
		{
			echo "    <span class='$css_class_name'>" . my_format_currency($r_min_prc) . " - " . my_format_currency($r_max_prc) . "</span>";
		}
		else
		{
			if ( $r_itype == 2 )
			{
				$qty = 1;
				$new_price = $r_min_prc;
		
				if ($r_min_prc < 0.03)
				{
					$qty = 1000;
					$new_price = $r_min_prc * 1000;
				}
				if ($qty == 1)
				{
					echo "    <span class='$css_class_name'>" . my_format_currency($new_price) . "++</span>";
				}
				else
				{
					echo "    <span class='$css_class_name'>{$qty}{$r_metricdescr} = " . my_format_currency($new_price) . "</span>";
				}
			}
			else
			{
				echo "    <span class='$css_class_name'>" . my_format_currency($r_min_prc) . "</span>";
			}
		}
		
	}



	$the_param_id = 0;
	if (isset($_REQUEST['param']))
	{
		$the_param_id = $_REQUEST['param'];
	}
	 
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
		
	if ($mysqli->connect_error)
	{
		die("Can't connect to database");
	}
	
	if (!mysqli_select_db($mysqli, $database))
	{
		die("Can't select database");
	}
		 
	$mysqli->set_charset("utf8");
	$new_dir = "images/";

	
	// no category selected (Home Page) 
	if ($the_param_id == 0)
	{
		echo " <div id='myModal' style='position: relative;' > ";
		
		$result = mysqli_query($mysqli, 
				" SELECT tfood.id, tfood.descr, tfood.sFoodPictureid, tfood.itype, " .
				"        Q1.min_prc, Q1.max_prc, Q1.cnt_prc, Q2.cnt_foodline, Q3.cnt_topping, " .
				"        tfood.CanChangeMaterials, tmetric.Descr as metricdescr, tfood.isavailable,   " .
				"        tfoodgroup.Descr as foodgroup_descr   " .
				" FROM tfood  " .
				" left join tmetric on tfood.metricid = tmetric.id " .
				" left join tfoodgroup on tfood.foodgroupid = tfoodgroup.id " .
				" left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, count(*) as cnt_prc    " .
				"             FROM  tfoodvariation  GROUP BY foodid ) Q1 on Q1.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_foodline    " .
				"             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_topping    " .
				"             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " .
				" where tfood.ifrontpageno > 0 AND tfood.isavailable = 1 ORDER BY tfood.ifrontpageno ");
 					
		if ($result)
		{
			if (mysqli_num_rows($result) > 0)
			{
				$main_script_body = "";
				$window_script_body = "";
		
				$bfirsttime = true;
				while(list($r_foodid, $r_descr, $r_sFoodPictureid, $r_itype, $r_min_prc, $r_max_prc,
						$r_cnt_prc, $r_cnt_foodline, $r_cnt_topping, $r_CanChangeMaterials,
						$r_metricdescr, $r_isavailable, $r_foodgroup_descr ) = mysqli_fetch_row($result))
				{
					$material_descr = "";
					$result1 = mysqli_query($mysqli, "SELECT tfoodline.id, tmaterial.Descr " .
									"FROM tfoodline    " .
									"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
									"where tfoodline.FoodID = $r_foodid  ORDER BY tmaterial.Descr");
					if ($result1)
					{
						if (mysqli_num_rows($result1) > 0)
						{
							while(list($r1_foodlineid, $r1_descr) = mysqli_fetch_row($result1))
							{
								$material_descr = $material_descr . ", " . $r1_descr;
							}
							if (strlen($material_descr) > 0 )
							{
								$material_descr = substr($material_descr, 2);
							}
						}
				
 							
						echo "  <div class='front-pg-content'>";
						echo "   <p class='front-pg-header' >{$r_foodgroup_descr}</p>";
						echo "   <p class='front-pg-header2' >{$r_descr}</p>";
						if (strlen($r_sFoodPictureid) > 0 )
						{
							echo "   <div class='grow front-pg-img-div'> ";
							echo "    <img src='{$new_dir}{$r_sFoodPictureid}.jpg' alt='' title='' class='front-pg-img' >";
							echo "   </div> ";
						}
						else
						{
							echo "   <div class='grow front-pg-img-div'> ";
							echo "    <img src='{$new_dir}empty.png' alt='' title='' class='front-pg-img' >";
							echo "   </div> ";
						}
						if (strlen($material_descr) > 0 )
						{
							echo "    <div class='front-pg-material'> " . $material_descr;
							echo "    </div>";
						}
						if ($r_isavailable == 1 && $ballow_transactions)
						{
							echo "     <a href='a1234/add.the.php?prm=" . encode_str_gr(strval($r_foodid)) . "&prm2=" . encode_str_gr($r_descr) . "' class='add_btn_a_front_pg' >";
							echo "    <div id='1' class='front-pg-add-btn' >";
							echo "     {$language_array['BUY']}";
							echo "    </div>";
							echo "     </a>";
						}
						
						echo_price($r_min_prc, $r_max_prc, $r_metricdescr, $r_itype, 'front-pg-price');
								
						
						echo "  </div> ";
									
					}
								
				}
			}
		}
				
	}
	else // category selected
	{
		echo " <div id='myModal' style='width: 100%;' > ";
		
		$result = mysqli_query($mysqli, " SELECT tfood.id, tfood.descr, tfood.sFoodPictureid, tfood.itype, " .
				"        Q1.min_prc, Q1.max_prc, Q1.cnt_prc, Q2.cnt_foodline, Q3.cnt_topping, " .
				"        tfood.CanChangeMaterials, tmetric.Descr as metricdescr, tfood.isavailable   " .
				" FROM tfood  " .
				" left join tmetric on tfood.metricid = tmetric.id " .
				" left join ( SELECT foodid, min(dprice) as min_prc, max(dprice) as max_prc, count(*) as cnt_prc    " .
				"             FROM  tfoodvariation  GROUP BY foodid ) Q1 on Q1.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_foodline    " .
				"             FROM  tfoodline  GROUP BY foodid ) Q2 on Q2.foodid = tfood.id  " .
				" left join ( SELECT foodid, count(*) as cnt_topping    " .
				"             FROM  ttopping  GROUP BY foodid ) Q3 on Q3.foodid = tfood.id  " .
				" where FoodGroupID = $the_param_id  ORDER BY iorder, Descr");
		
		if ($result)
		{
			if (mysqli_num_rows($result) > 0)
			{
				$main_script_body = "";
				$window_script_body = "";
					
				$bfirsttime = true;
				while(list($r_foodid, $r_descr, $r_sFoodPictureid, $r_itype, $r_min_prc, $r_max_prc,
						$r_cnt_prc, $r_cnt_foodline, $r_cnt_topping, $r_CanChangeMaterials,
						$r_metricdescr, $r_isavailable ) = mysqli_fetch_row($result))
				{
					$material_descr = "";
					$result1 = mysqli_query($mysqli, "SELECT tfoodline.id, tmaterial.Descr " .
							"FROM tfoodline    " .
							"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
							"where tfoodline.FoodID = $r_foodid  ORDER BY tmaterial.Descr");
					if ($result1)
					{
						if (mysqli_num_rows($result1) > 0)
						{
							while(list($r1_foodlineid, $r1_descr) = mysqli_fetch_row($result1))
							{
								$material_descr = $material_descr . ", " . $r1_descr;
							}
							if (strlen($material_descr) > 0 )
							{
								$material_descr = substr($material_descr, 2);
							}
						}
							
					}
						
					echo "<div class='product_line'>";
					echo "  <div class='iproduct_container' id='myBtn{$r_foodid}'>";
			 		
					if (strlen($r_sFoodPictureid) > 0 )
						echo "    <img src='{$new_dir}{$r_sFoodPictureid}.jpg' alt='' title=''style=\"width:100px;height:90px;\">";
						else
							echo "    <img src='{$new_dir}empty.png' alt='' title=''style=\"width:100px;height:90px;\">";
							echo "  </div> ";
		
								
							// Build modal popup window
							echo " <div id='myModal{$r_foodid}' class='modal'> ";
							if (strlen($material_descr) > 0 )
							{
								echo "  <div class='modal-content modal-content-with-material'>";
							}
							else
							{
								echo "  <div class='modal-content modal-content-without-material'>";
							}
							echo "   <span class='close' id='close{$r_foodid}' >×</span>";
							if (strlen($r_sFoodPictureid) > 0 )
							{
								echo "    <img src='{$new_dir}{$r_sFoodPictureid}.jpg' class='modal-img' alt='' title=''>";
							}
							else
							{
								echo "    <img src='{$new_dir}empty.png' alt='' class='modal-img' title=''>";
							}
							if (strlen($material_descr) > 0 )
							{
								echo "    <br><br>";
								echo "    <div class='pdetails-box'> " . $material_descr;
								echo "    </div>";
								echo_price($r_min_prc, $r_max_prc, $r_metricdescr, $r_itype, 'front-pg-price');
								if ($r_isavailable == 1 && $ballow_transactions)
								{
									echo "     <a href='a1234/add.the.php?prm=" . encode_str_gr(strval($r_foodid)) . "&prm2=" . encode_str_gr($r_descr) . "' class='add_btn_a' >";
									echo "    <div id='1' class='add-btn' style='float: right;position: absolute; bottom: 10px;right: 10px;' >";
									echo "     " . $language_array["BUY"] ;
									echo "    </div>";
									echo "     </a>";
								}
							}
							else
							{
								echo_price($r_min_prc, $r_max_prc, $r_metricdescr, $r_itype, 'front-pg-price');
								if ($r_isavailable == 1 && $ballow_transactions)
								{
									echo "     <a href='a1234/add.the.php?prm=" . encode_str_gr(strval($r_foodid)) . "&prm2=" . encode_str_gr($r_descr) . "' style='text-align:center; line-height: 2.4em;font-size: 26px;font-weight: bold;'>";
									echo "    <div id='1' class='add-btn' style='float: right;position: absolute; bottom: 10px;right: 10px;'  >";
									echo "     " . $language_array["BUY"];
									echo "    </div>";
									echo "     </a>";
								}
							}
								
							echo "  </div> ";
							echo "  </div> \n";
		
							// Build modal popup window
							$main_script_body = $main_script_body . " var modal{$r_foodid} = document.getElementById('myModal{$r_foodid}');  \n";
							$main_script_body = $main_script_body . " var btn{$r_foodid} = document.getElementById(\"myBtn{$r_foodid}\");  \n";
							$main_script_body = $main_script_body . " var span{$r_foodid} = document.getElementById(\"close{$r_foodid}\");  \n";
							$main_script_body = $main_script_body . " btn{$r_foodid}.onclick = function() {  \n";
							$main_script_body = $main_script_body . " 	modal{$r_foodid}.style.display = \"block\";   \n";
							$main_script_body = $main_script_body . " }  \n";
							$main_script_body = $main_script_body . " span{$r_foodid}.onclick = function() {  \n";
							$main_script_body = $main_script_body . " 	modal{$r_foodid}.style.display = \"none\";  \n";
							$main_script_body = $main_script_body . " }  \n";
							$window_script_body = $window_script_body . " 	if (event.target == modal{$r_foodid}) {  \n";
							$window_script_body = $window_script_body . " 		modal{$r_foodid}.style.display = \"none\";  \n";
							$window_script_body = $window_script_body . " 	}  \n";
		
							echo "  <div class='producti'>";
							echo "    <h6 title='{$r_descr}'>{$r_descr}</h6>";
								
							$result1 = mysqli_query($mysqli, "SELECT tfoodline.id, tmaterial.Descr " .
									"FROM tfoodline    " .
									"  left join tmaterial on tmaterial.id = tfoodline.materialid  " .
									"where tfoodline.FoodID = $r_foodid  ORDER BY tmaterial.Descr");
		
							if (strlen($material_descr) > 0 )
							{
								echo "    <div class='pdetails'> " . $material_descr;
								echo "    </div>";
							}
		
							echo "  </div>";
							echo "  <div class='pricei'>";
							echo_price($r_min_prc, $r_max_prc, $r_metricdescr, $r_itype, 'price');
		
							if ($r_isavailable == 1 && $ballow_transactions)
							{
								echo "     <a href='a1234/add.the.php?prm=" . encode_str_gr(strval($r_foodid)) . "&prm2=" . encode_str_gr($r_descr) . "' style='text-align:center; line-height: 2.4em;font-size: 26px;font-weight: bold;'>";
								echo "    <div id='1' class='add-btn' >";
								echo "     " . $language_array["BUY"];
								echo "    </div>";
								echo "     </a>";
							}
							echo "  </div>";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "";
							echo "</div>";
								
								
				} //end of while
					
			} // more than one products found
			
		} // result is true
		
	}
	echo "  </div> \n";
	
 
 ?>
     




    </div>

   
</div>
     
 

</div>


<?php
 require("footer.php");
?>	     

<script src='js/jquery-2.1.3.min.js'></script>
   <script>
   <?php
           echo $main_script_body;
         ?>
         window.onclick = function(event) 
         {
         	<?php
         	 echo $window_script_body;
         	?>
         	  if (!event.target.matches('.dropbtn')) {

         	      var dropdowns = document.getElementsByClassName("dropdown-content");
         	      var i;
         	      for (i = 0; i < dropdowns.length; i++) {
         	        var openDropdown = dropdowns[i];
         	        if (openDropdown.classList.contains('show')) {
         	          openDropdown.classList.remove('show');
         	        }
         	      }
         	    }

         }
         
   var Tabs = {

           init: function() 
           {
             this.bindUIfunctions();
           },

           bindUIfunctions: function() 
           {

             // Delegation
             $(document)
               .on("click", ".transformer-tabs a[href^='index']:not('.active')",      
                       function(event) 
                       {
                   			window.location.href=this.href;
               			})  
               	.on("click", ".transformer-tabs a.active", 
                       	function(event) 
                       	{
			                 event.preventDefault();
               			});
  			
               $(".transformer-tabs").on("click", "ul", 
                       function(event) 
                       {
		                   $this=$(this);
		                   $activeTab=$this.find("a.active");
		                   Tabs.toggleMobileMenu(event, $activeTab);
		                   if ($this.hasClass("open")) 
			               {
		                     $this.find('li').eq(0).addClass("shorter");
		                     $activeTab.parent().removeClass("shorter");
		                   } 
		                   else if ($this.hasClass("closed")) 
			               {
		                      $this.find('li').eq(0).removeClass("shorter");
		                     $activeTab.parent().addClass("shorter");
		                   }
                 			event.preventDefault();
               			});
           },
           toggleMobileMenu: function(event, el) 
           {
             $(el).closest("ul").toggleClass("open").toggleClass("closed");
  			             
           }

         }

         Tabs.init();


   </script>
        

</body>
</html>
