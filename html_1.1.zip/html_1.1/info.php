<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

if (!isset($_REQUEST['prm']) )
{
	header('Location:../index.php');
	die();
}
session_start();




?>

<!--==============================html=========================================================================================-->
<html>
<head>
<title>Info</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
     <link rel="stylesheet" type="text/css" media="screen" href="css/style_cart.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>
<?php
 include_once("header.php");
 ?>

      
<div class="slide" style="min-height:600px">		
 
<!--==============================content================================-->
 <div style="padding: 20px 20px; background-color: #aaaaaa;">
        	
<!--==============================log in=====================================================================-->

<?php
	include_once('a1234/dbheader.the.php');
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	
	if ($mysqli->connect_error)
	{
		header('Location:index.php');
		die("Can't connect to database");
	}
		 
	if (!mysqli_select_db($mysqli, $database))
	{
		header('Location:index.php');
		die("Can't select database");
	}
	
	$mysqli->set_charset("utf8");
	$new_dir = "images/";
	$irow = substr($_REQUEST['prm'], 0, 1);
	$icol = substr($_REQUEST['prm'], 1, 1);
	
	$result = mysqli_query($mysqli,
			" SELECT tfooteritem.sdata  " .
			" FROM tfooteritem  WHERE tfooteritem.icolumn = {$icol} AND tfooteritem.irow = {$irow} ");
			
	if ($result)
	{
		if (mysqli_num_rows($result) > 0)
		{
			$footer_item_array = array();
			if (list($sdata ) = mysqli_fetch_row($result))
			{
				echo $sdata;
			}
		}
	}
	




?>

</div>
 <form  method='post' action='index.php'>
 <input class='buttonkeepshopping' type='submit' name='submit_shop' Value='<?php echo $language_array["Keep on shopping"]; ?>'/>
 </form>

</div>
<?php
 require("footer.php");
 ?>
 </body>
</html>