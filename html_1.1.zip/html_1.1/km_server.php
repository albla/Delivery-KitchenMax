<?php

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


require_once ('lib/nusoap.php'); 

//using soap_server to create server object 
$server = new soap_server; 
$namespace ="http://localhost/km_server/wsdl";
$server->configureWSDL("km_server", $namespace);
$server->wsdl->schemaTargetNamespace = $namespace;
$server->soap_defencoding = 'UTF-8';
$server->decode_utf8 = false;
$server->encode_utf8 = true;

//register a function that works on server 
$server->register('get_message'); 

$server->register('set_street', 
		          array('str1' => 'xsd:string','str2' => 'xsd:string','dec1' => 'xsd:decimal','int1' => 'xsd:integer','str9' => 'xsd:string'),
                  array('return' => 'xsd:string'));

$server->register('set_postcode',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_area',
		array('str1' => 'xsd:string','str2' => 'xsd:string','dec1' => 'xsd:decimal','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_variation',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodgroup',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','int2' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_metric',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_food',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','str4' => 'xsd:string', 
			  'int1' => 'xsd:integer','int2' => 'xsd:integer', 'dec1' => 'xsd:decimal','dec2' => 'xsd:decimal','dec3' => 'xsd:decimal', 
			  'str5' => 'xsd:string','int3' => 'xsd:integer','int4' => 'xsd:integer','int5' => 'xsd:integer','int6' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodpicture',
		array('str1' => 'xsd:string','str2' => 'xsd:string','pic1' => 'xsd:string','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodline',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','str4' => 'xsd:string', 'dec1' => 'xsd:decimal','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodvariation',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','str4' => 'xsd:string','str5' => 'xsd:string',
				'dec1' => 'xsd:decimal','dec2' => 'xsd:decimal','dec3' => 'xsd:decimal','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodtopping',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','str4' => 'xsd:string',
				'dec1' => 'xsd:decimal','dec2' => 'xsd:decimal','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodtoppingvariation',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','str4' => 'xsd:string','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodbundle',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','int2' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_foodbundledetail',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str3' => 'xsd:string','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_material',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_food_availability',
		array('str1' => 'xsd:string','str2' => 'xsd:string','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_all_food_availability',
		array('str1' => 'xsd:string','str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('order_log',
		array('str9' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('order_last_log',
		array('str1' => 'xsd:string','str2' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('flag_order_log',
		array('str1' => 'xsd:string','str2' => 'xsd:string', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('update_c_log',
		array('str1' => 'xsd:string','str2' => 'xsd:string', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('update_cc_log',
		array('str1' => 'xsd:string','str2' => 'xsd:string', 'str3' => 'xsd:string', 'str4' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('clean_log',
		array('str1' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_param',
		array('str1' => 'xsd:string','str2' => 'xsd:string', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_all_food_available',
		array('str1' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_picture',
		array('str1' => 'xsd:string','str2' => 'xsd:string','int1' => 'xsd:integer', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_infomail',
		array('str1' => 'xsd:string', 'str2' => 'xsd:string', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_footeritem',
		array(  'str1' => 'xsd:string', 'int1' => 'xsd:integer','int2' => 'xsd:integer', 
		        'int3' => 'xsd:integer','int4' => 'xsd:integer','pic1' => 'xsd:string', 
				'str3' => 'xsd:string','int5' => 'xsd:integer','str4' => 'xsd:string'),
		array('return' => 'xsd:string'));

$server->register('set_database',
		array(  'str1' => 'xsd:string', 'str2' => 'xsd:string', 'str3' => 'xsd:string'),
		array('return' => 'xsd:string'));


function decode_str_other_simp($str_coded, $skey)
{
	include('ws_security.php');
	
	$i_str_index = 0;
	$i_key_index = 0;
	$i_curr_key_index = 0;
	$s_current_char = "";
	$main_str_len = strlen($str_coded);
	$pass_table = array();
	$str_decoded = str_repeat(" ", $main_str_len);
	
	$pass_table[] = "0123456789";
	for ( $icounter = 1; $icounter <10 ; $icounter ++)
	{
		$pass_table[] = $security_str_array[$icounter];
	}
	$zero_string = $pass_table[0];
	
	
	try
	{
		$start_index = strpos($pass_table[0], $skey[0]);
		if ($start_index === false )
		{
			$start_index = 6;
		}

		if ($start_index >= $main_str_len)
		{
			$start_index = $start_index % $main_str_len;
		}
		
		for ($i = $start_index; $i < $main_str_len; $i++)
		{
			$s_current_char = $str_coded[$i_str_index];
			$i_curr_key_index = $i_key_index % 12;
			$pos = strpos( $pass_table[intval($skey[$i_curr_key_index])] , $s_current_char );
			if ($pos === false )
			{
				$str_decoded[$i] = $s_current_char;
			}
			else
			{
				$str_decoded[$i] = $zero_string[ $pos ];
			}
			$i_str_index++;
			$i_key_index++;
		}
		for ($i = 0; $i < $start_index; $i++)
		{
			$s_current_char = $str_coded[$i_str_index];
			$i_curr_key_index = $i_key_index % 12;
			$pos = strpos( $pass_table[intval($skey[$i_curr_key_index])] , $s_current_char );
			if ($pos === false )
			{
				$str_decoded[$i] = $s_current_char;
			}
			else
			{
				$str_decoded[$i] = $zero_string[ $pos  ];
			}
			$i_str_index++;
			$i_key_index++;
		}
	}
	catch (Exception $e)
	{
	}

	return $str_decoded;

}


//Core function
function backup_tables($host, $user, $pass, $dbname, $tables = '*') 
{
	$link = mysqli_connect($host,$user,$pass, $dbname);

	// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		exit;
	}

	mysqli_query($link, "SET NAMES 'utf8'");

	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysqli_query($link, 'SHOW TABLES');
		while($row = mysqli_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}

	$return = '';
	//cycle through
	foreach($tables as $table)
	{
		$result = mysqli_query($link, 'SELECT * FROM '.$table);
		$num_fields = mysqli_num_fields($result);
		$num_rows = mysqli_num_rows($result);

		$return.= 'DROP TABLE IF EXISTS '.$table.';';
		$row2 = mysqli_fetch_row(mysqli_query($link, 'SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		$counter = 1;

		//Over tables
		for ($i = 0; $i < $num_fields; $i++)
		{   //Over rows
			while($row = mysqli_fetch_row($result))
			{
				if($counter == 1){
					$return.= 'INSERT INTO '.$table.' VALUES(';
				} else{
					$return.= '(';
				}

				//Over fields
				for($j=0; $j<$num_fields; $j++)
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = str_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}

				if($num_rows == $counter){
					$return.= ");\n";
				} else{
					$return.= "),\n";
				}
				++$counter;
			}
		}
		$return.="\n\n\n";
	}

	//save file
	$fileName = 'db_bak/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql';
	$handle = fopen($fileName,'w+');
	fwrite($handle,$return);
	if(fclose($handle))
	{
		return 1;
	}
	return 0;
}


function verify_string($str1)
{
	if (strlen($str1) == 20 )
	{
		$s_key = substr($str1, 0, 10) . "12";
		$s_val = substr($str1, 10, 10);
		$s_result = substr($str1, 4, 2) . substr($str1, 8, 2) . substr($str1, 2, 2) . substr($str1, 6, 2) . substr($str1, 0, 2);
	
		if (decode_str_other_simp( $s_val, $s_key) == $s_result)
		{
			return true;
		}
	}
	return false;
}

// create the function 
function get_message($your_name) 
{ 
	if(!$your_name)
	{ 
		return new soap_fault('Client','','Put Your Name!'); 
	} 
	$result = "Welcome to ".$your_name .". Thanks for Your First Web Service Using PHP with SOAP"; 
	return $result; 
} 

function set_street($pID, $name, $fee, $del, $str9)
{

	include('a1234/dbheader.the.php');
	include('ws_security.php');

	$dec_fee = 0.0;
	$i_del = 0;
	
	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
    if(!$name)
    {
    	return 'Street name required!';
    }

    if(!$pID)
    {
		return 'Street ID required!';
    }
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$dec_fee = $fee;
	$i_del = $del;
		
	
	if ($mysqli->connect_error)
    {
		return 'Cant connect to database';
    }
		
	if (!mysqli_select_db($mysqli, $database))
    {
		return 'Cant select database';
    }
		
	$mysqli->set_charset("utf8");
		
	$result = mysqli_query($mysqli, "SELECT id, descr FROM tstreet where ID = " . $pID . " ");
	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
 		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tstreet WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else 
		{
			$result = mysqli_query($mysqli, "Update tstreet set descr = '{$name}', fee = {$dec_fee}  WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tstreet (id, descr, fee) Values ({$pID}, '{$name}', {$dec_fee}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tstreet where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tstreet where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}
	
	
	return "0";
}



function set_postcode($pID, $name, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$name)
	{
		return 'Street name required!';
	}

	if(!$pID)
	{
		return 'Street ID required!';
	}
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	
	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}
		
	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
	
	$result = mysqli_query($mysqli, "SELECT id, descr FROM tpostcode where ID = " . $pID . " ");
	
	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tpostcode WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else 
		{
			$result = mysqli_query($mysqli, "Update tpostcode set descr = '{$name}'  WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tpostcode (id, descr) Values ({$pID}, '{$name}') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tpostcode where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tpostcode where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}
	
	return "0";
}

function set_area($pID, $name, $fee, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$name)
	{
		return 'Street name required!';
	}

	if(!$pID)
	{
		return 'ID required!';
	}
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	
	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}
		
	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
	
	$result = mysqli_query($mysqli, "SELECT id, descr FROM tarea where ID = " . $pID . " ");
    $dec_fee = $fee;
    $i_del = $del;
    
    
	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tarea WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else 
		{
			$result = mysqli_query($mysqli, "Update tarea set descr = '{$name}', fee = {$dec_fee}  WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tarea (id, descr, fee) Values ({$pID}, '{$name}', {$dec_fee}) ");
		if (!$result)
			return mysqli_error($mysqli);

	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tarea where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tarea where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}
	
	return "0";
}

function set_variation($pID, $name, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;


	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	
	if(!$name)
	{
		return 'name required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	
	$i_del = $del;
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	
	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}
		
	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
		
	$result = mysqli_query($mysqli, "SELECT id, descr FROM tvariation where ID = " . $pID . " ");
	
	
	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tvariation WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tvariation set descr = '{$name}'  WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tvariation (id, descr) Values ({$pID}, '{$name}') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}
	
	return "0";
}
	


function set_foodgroup($pID, $name, $iord, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;
	$i_ord = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$name)
	{
		return 'Street name required!';
	}

	if(!$pID)
	{
		return 'ID required!';
	}
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	$i_ord = $iord;
	
	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, descr FROM tfoodgroup where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfoodgroup WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tfoodgroup set descr = '{$name}', iorder= {$i_ord}   WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tfoodgroup (id, descr, iorder) Values ({$pID}, '{$name}', {$i_ord} ) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tfoodgroup where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tfoodgroup where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}




function set_metric($pID, $name, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;
	$i_ord = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$name)
	{
		return 'Street name required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	$i_ord = $iord;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, descr FROM tmetric where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tmetric WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tmetric set descr = '{$name}'  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tmetric (id, descr) Values ({$pID}, '{$name}') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tmetric where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tmetric where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}



function set_food($pID, $pFoodGroupID, $pDescr, $psNo, $piorder, $pitype, $pdQuantity, $pdFreeEvery, $pdFreeQty, $pmetricid, $pisavailable, $del, $pCanChangeMaterials, $pifrontpageno, $str9 )
{
	include('a1234/dbheader.the.php');
	
	$new_dir = "images/";
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pDescr)
	{
		return 'Street name required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}
	if(!$pFoodGroupID)
	{
		return 'FoodGroupID required!';
	}
	

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, descr, sFoodPictureid FROM tfood where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr, $sFoodPictureid) = mysqli_fetch_row($result))
	{
		// return '11';
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfood WHERE id = {$pID}");
			if (!$result)
			{
				return mysqli_error($mysqli);
			}
			else 
			{
				if ( strlen($sFoodPictureid) > 0 )
				{
					unlink($new_dir. $sFoodPictureid . '.jpg');
				}
			}
		}
		else
		{
			$cleanquery = "Delete FROM tfoodline WHERE foodid = {$pID};" . 
			              "Delete FROM tfoodvariation WHERE foodid = {$pID};" .
			              "Delete FROM ttoppingvariation WHERE toppingid in (select id FROM ttopping WHERE foodid = {$pID});".
			              "Delete FROM ttopping WHERE foodid = {$pID};" .
			              "Delete FROM tfoodbundledetail WHERE foodbundleid in (select id FROM tfoodbundle WHERE foodid = {$pID}) ;" . 
			              "Delete FROM tfoodbundle WHERE foodid = {$pID};";
			if (mysqli_multi_query($mysqli, $cleanquery))
			{
				do
				{
					/* store first result set */
					if ($result2 = mysqli_store_result($mysqli))
					{
						//do nothing since there's nothing to handle
						mysqli_free_result($result2);
					}
					/* print divider */
					if (mysqli_more_results($mysqli))
					{
						//I just kept this since it seems useful
						//try removing and see for yourself
					}
				} while (mysqli_next_result($mysqli));
				
			}
			
			$result = mysqli_query($mysqli, " Update tfood set " . 
					                              " descr = '{$pDescr}', FoodGroupID = {$pFoodGroupID}, " . 
					                              " sNo = '{$psNo}', iorder = {$piorder}, " . 
					                              " itype = {$pitype}, dQuantity = {$pdQuantity}, " . 
					                              " dFreeEvery = {$pdFreeEvery}, dFreeQty = {$pdFreeQty}, " . 
					                              " metricid = {$pmetricid}, isavailable = {$pisavailable}, " . 
					                              " CanChangeMaterials = {$pCanChangeMaterials}, ifrontpageno = {$pifrontpageno} " . 
					                         "  WHERE id = {$pID}");
			if (!$result)
 				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, " Insert into tfood (id, FoodGroupID, Descr, sNo, iorder, itype, dQuantity, dFreeEvery, dFreeQty, metricid, isavailable, CanChangeMaterials, ifrontpageno) " . 
				                        " Values ({$pID}, {$pFoodGroupID}, '{$pDescr}', '{$psNo}', {$piorder}, {$pitype}, " . 
		                                "         {$pdQuantity}, {$pdFreeEvery}, {$pdFreeQty}, {$pmetricid}, {$pisavailable}, " .
		                                "         {$pCanChangeMaterials}, {$pifrontpageno} ) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tfood where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tfood where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}


function set_foodpicture($pID, $pfoodpictureID, $pic, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;
	$i_ord = 0;
	$new_dir = "images/";
	$pic_ID = $pfoodpictureID;
	$query="";
	
	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	
	if(!$pfoodpictureID && !is_string($pfoodpictureID))
	{
		return 'id pic required!';
	}
	if(is_string($pfoodpictureID) && strlen($pfoodpictureID) == 0)
	{
		$pic_ID = "0";
	}
	
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	$i_ord = $iord;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, sFoodPictureid FROM tfood where ID = " . $pID . " ");
	
	
	if ($result && mysqli_num_rows($result) > 0 && list($id, $sFoodPictureid) = mysqli_fetch_row($result))
	{
		if ( strlen($sFoodPictureid) > 0 && $sFoodPictureid != $pic_ID && file_exists($new_dir. $sFoodPictureid . '.jpg'))
		{
			unlink($new_dir. $sFoodPictureid . '.jpg');
		}

		if(strlen($pic) >10 && $pic_ID != "0")
		{
			$imageData = base64_decode($pic);
			$photo = imagecreatefromstring($imageData);
			imagejpeg($photo,$new_dir. $pfoodpictureID . '.jpg',100);
		}
		
		if ( strlen($pic_ID) > 0 )
		{
			$query = "Update tfood set sFoodPictureid = '{$pic_ID}'  WHERE id = {$pID}";
			if ($pic_ID == "0")
			{
				$query = "Update tfood set sFoodPictureid = ''  WHERE id = {$pID}";
			}
			
			$result = mysqli_query($mysqli, $query);
			if (!$result)
			{
				return mysqli_error($mysqli);
			}
		}
	}

	if ( strlen($pfoodpictureID) > 0 && 
		 file_exists($new_dir. $sFoodPictureid . '.jpg') )
	{
		return "Error, file does not exist";
	}

	return $query;
}


function set_foodline($pID, $pfoodid, $pmaterialid, $pmetricid, $pdqty, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pfoodid)
	{
		return 'food id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodline where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfoodline WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tfoodline set foodid = {$pfoodid}, materialid = {$pmaterialid}, metricid = {$pmetricid}, dqty = {$pdqty}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tfoodline (id, foodid, materialid, metricid, dqty ) Values ({$pID}, {$pfoodid}, {$pmaterialid}, {$pmetricid}, {$pdqty}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodline where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodline where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}


function set_foodvariation($pID, $pDescr, $pfoodid, $pvariationid, $psno, $pdprice, $pipiece, $pdqty, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pfoodid)
	{
		return 'food id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}
	$s_pvariationid = "";
	if (strlen($pvariationid) > 0 )
	{
		$s_pvariationid = $pvariationid;
	}
	else 
	{
		$s_pvariationid = "NULL";
	}
		

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, Descr FROM tfoodvariation where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfoodvariation WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tfoodvariation set foodid = {$pfoodid}, variationid = {$s_pvariationid}, Descr = '{$pDescr}', sno = '{$psno}', dprice = {$pdprice} , ipiece = {$pipiece} , dqty = {$pdqty}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tfoodvariation (id, Descr, foodid, variationid, sno, dprice, ipiece, dqty ) " . 
				                        " Values ({$pID}, '{$pDescr}', {$pfoodid}, {$s_pvariationid}, '{$psno}', {$pdprice}, {$pipiece}, {$pdqty}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, Descr FROM tfoodvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
			return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, Descr FROM tfoodvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}



function set_foodtopping($pID, $pfoodid, $pmaterialid, $pmetricid, $pdqty, $pdprice, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pfoodid)
	{
		return 'food id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, foodid FROM ttopping where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM ttoppingvariation WHERE toppingid = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
			$result = mysqli_query($mysqli, "Delete FROM ttopping WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update ttopping set foodid = {$pfoodid}, materialid = {$pmaterialid} , metricid = {$pmetricid}, dprice = {$pdprice} , dqty = {$pdqty}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into ttopping (id, foodid, materialid, metricid, dprice, dqty ) " .
				" Values ({$pID}, {$pfoodid}, {$pmaterialid}, {$pmetricid}, {$pdprice}, {$pdqty}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM ttopping where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
			return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM ttopping where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}




function set_foodtoppingvariation($pID, $ptoppingid, $pvariationid, $pdprice, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
 	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
 	if(!$ptoppingid)
	{
		return 'food id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}


	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, toppingid FROM ttoppingvariation where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM ttoppingvariation WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update ttoppingvariation set toppingid = {$ptoppingid}, variationid = {$pvariationid}, dprice = {$pdprice}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into ttoppingvariation (id, toppingid, variationid, dprice ) " .
				" Values ({$pID}, {$ptoppingid}, {$pvariationid}, {$pdprice}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, toppingid FROM ttoppingvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, toppingid FROM ttoppingvariation where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}



function set_foodbundle($pID, $pfoodid, $pbfreetoppings, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pfoodid)
	{
		return 'food id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodbundle where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfoodbundledetail WHERE foodbundleid = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
			$result = mysqli_query($mysqli, "Delete FROM tfoodbundle WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tfoodbundle set foodid = {$pfoodid}, bfreetoppings = {$pbfreetoppings}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tfoodbundle (id, foodid, bfreetoppings ) " .
				" Values ({$pID}, {$pfoodid}, {$pbfreetoppings}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodbundle where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, foodid FROM tfoodbundle where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}



function set_foodbundledetail($pID, $pfoodbundleid, $pfoodvariationid, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pfoodbundleid)
	{
		return 'food bundle id required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, foodbundleid FROM tfoodbundledetail where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfoodbundledetail WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tfoodbundledetail set foodbundleid = {$pfoodbundleid}, foodvariationid = {$pfoodvariationid}  WHERE id = {$pID}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tfoodbundledetail (id, foodbundleid, foodvariationid ) " .
				" Values ({$pID}, {$pfoodbundleid}, {$pfoodvariationid}) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, foodbundleid FROM tfoodbundledetail where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
		return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, foodbundleid FROM tfoodbundledetail where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}



function set_material($pID, $name, $del, $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;
	$i_ord = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$name)
	{
		return 'material name required!';
	}
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	$i_ord = $iord;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, descr FROM tmaterial where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
	{
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tmaterial WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
		else
		{
			$result = mysqli_query($mysqli, "Update tmaterial set descr = '{$name}'  WHERE id = {$id}");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, "Insert into tmaterial (id, descr) Values ({$pID}, '{$name}') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tmaterial where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
			return "Error, row still exists";
			return "1";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT id, descr FROM tmaterial where ID = " . $pID . " ");
		if ($result && mysqli_num_rows($result) > 0 && list($id, $descr) = mysqli_fetch_row($result))
		{
			return strval($id);
		}
		return "Error";
	}

	return "0";
}




function set_food_availability($pID, $pisavailable , $str9)
{
	include('a1234/dbheader.the.php');
	
	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	if(!$pID)
	{
		return 'ID required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT id, descr, sFoodPictureid FROM tfood where ID = " . $pID . " ");


	if ($result && mysqli_num_rows($result) > 0 && list($id, $descr, $sFoodPictureid) = mysqli_fetch_row($result))
	{
		$result = mysqli_query($mysqli, " Update tfood set isavailable = {$pisavailable} " .
										" WHERE id = {$pID}");
		if (!$result)
		{
			return mysqli_error($mysqli);
				
		}
		else 
		{
			$result = mysqli_query($mysqli, "SELECT id, isavailable FROM tfood where ID = " . $pID . " ");
			if ($result && mysqli_num_rows($result) > 0 && list($id, $isavailable) = mysqli_fetch_row($result))
			{
				return strval($isavailable);
			}
		}
	}

	return "Error";
}



function set_all_food_availability($pisavailable , $str9)
{
	include('a1234/dbheader.the.php');

	$dec_fee = 0.0;
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, " Update tfood set isavailable = {$pisavailable} ");
	if (!$result)
	{
		return mysqli_error($mysqli);
	}
	else
	{
		return strval("1");
	}
}




function order_log($str9)
{
	
	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	include('a1234/dbheader.the.php');
	
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;
	
	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}
	
	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
	
	$result = mysqli_query($mysqli, "SELECT wid, sbody FROM torderlog where istatus < 2  ORDER BY wid LIMIT 1 ");
	
	
	if ($result)
	{
		if (mysqli_num_rows($result) > 0 && list($wid, $sbody) = mysqli_fetch_row($result))
		{
			$snumber = "{$wid}";
			if(mb_strlen($snumber)< 20)
			{
				$snumber = $snumber . str_repeat(" ", 20 - mb_strlen($snumber));
			}
			$sreturn = $snumber . $sbody; 
			return  $sreturn;
		}
			
	}
	else 
	{
		return "ERROR";
	}
	
	return "0";
}


function order_last_log($bigger_wid, $str9)
{

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	include('a1234/dbheader.the.php');


	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT wid, sbody FROM torderlog WHERE wid < {$bigger_wid} ORDER BY wid DESC LIMIT 1 ");

	if ($result)
	{
		if (mysqli_num_rows($result) > 0 && list($wid, $sbody) = mysqli_fetch_row($result))
		{
			$snumber = "{$wid}";
			if(mb_strlen($snumber)< 20)
			{
				$snumber = $snumber . str_repeat(" ", 20 - mb_strlen($snumber));
			}
			$sreturn = $snumber . $sbody;
			return  $sreturn;
		}
			
	}
	else
	{
		return "ERROR";
	}

	return "0";
}



function flag_order_log($wid, $iflag, $str9)
{

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	if(!$wid)
	{
		return 'ID required!';
	}
	if(!$iflag)
	{
		return 'flag required!';
	}
	include('a1234/dbheader.the.php');


	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, " Update torderlog set istatus = {$iflag} WHERE  wid = {$wid} ");
	if (!$result)
	{
		return mysqli_error($mysqli);
	}
	else
	{
		return "1";
	}
}



function update_c_log($wid, $id, $str9)
{

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	if(!$wid)
	{
		return 'ID required!';
	}
	if(!$id)
	{
		return 'ID2 required!';
	}
	include('a1234/dbheader.the.php');


	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, " Update tcustomer set id = {$id} WHERE  wid = {$wid} ");
	if (!$result)
	{
		return mysqli_error($mysqli);
	}
	else
	{
		return "1";
	}
}


function update_cc_log($wid, $id, $streetid, $str9)
{

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}
	if(!$wid)
	{
		return 'ID required!';
	}
	if(!$id)
	{
		return 'ID2 required!';
	}
	include('a1234/dbheader.the.php');


	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, " Update tcustomercontact set id = {$id}, streetid = {$streetid} WHERE  wid = {$wid} ");
	if (!$result)
	{
		return mysqli_error($mysqli);
	}
	else
	{
		return "1";
	}
}



function clean_log($str9)
{
	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	include('a1234/dbheader.the.php');

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT wid, sbody FROM torderlog where istatus < 2  ORDER BY wid LIMIT 1 ");
	
	if ($result)
	{
		if (mysqli_num_rows($result) > 0)
		{
			return  "Not empty";
		}
	}
	
	$result = mysqli_multi_query($mysqli, 
			" TRUNCATE TABLE torderlog ; " . 
			" TRUNCATE TABLE torderline ; " . 
			" TRUNCATE TABLE torder ; " );
	if (!$result)
	{
		return mysqli_error($mysqli);
	}
	else
	{
		return "1";
	}
}



function set_param($name, $value, $str9)
{
	include('a1234/dbheader.the.php');

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	if(!$name)
	{
		return 'Street name required!';
	}
	
	if(!$value && !is_string($value) )
	{
		return 'Value required!';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}
		
	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
					
	$result = mysqli_query($mysqli, "SELECT wid, sparamname FROM tparam where sparamname = '" . $name . "' ");

	if ($result && mysqli_num_rows($result) > 0)
	{
		if (list($wid, $sparamname) = mysqli_fetch_row($result))
		{
			$result = mysqli_query($mysqli, "Update tparam set sparamvalue = '{$value}'  WHERE sparamname = '" . $name . "' ");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	else
	{
		$result = mysqli_query($mysqli, "Insert into tparam (sparamname, sparamvalue) Values ('{$name}', '{$value}') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	$result = mysqli_query($mysqli, "SELECT wid, sparamvalue FROM tparam where sparamname = '" . $name . "' ");
	if ($result && mysqli_num_rows($result) > 0 && list($wid, $sparamvalue) = mysqli_fetch_row($result))
	{
		return strval($sparamvalue);
	}

	return "0";
}


function set_all_food_available($str9)
{
	include('a1234/dbheader.the.php');

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
		
	$result = mysqli_query($mysqli, "Update tfood set isavailable = 1  WHERE isavailable = 0 ");
	if (!$result)
		return mysqli_error($mysqli);

	return "1";
}


function upload_file($encoded,$name) {
	$location = $name;                               // Mention where to upload the file
	$current = file_get_contents($location);                     // Get the file content. This will create an empty file if the file does not exist
	$current = base64_decode($encoded);                          // Now decode the content which was sent by the client
	file_put_contents($location, $current);                      // Write the decoded content in the file mentioned at particular location
}

function set_picture($str1, $pic, $itype, $str9)
{
	$new_dir = "images/";

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	if ( strlen($str1) > 0 )
	{
		if ( file_exists($new_dir. $str1))
		{
			unlink($new_dir. $str1);
		}
		$imageData = base64_decode($pic);
		$photo = imagecreatefromstring($imageData);
		if ($itype == 1)
		{
			imagejpeg($photo, $new_dir . $str1, 100);
		}
		else 
		{
			upload_file($pic, $new_dir . $str1);
		}
		
	}
	
	if ( file_exists($new_dir. $str1) )
	{
		return "1";
	}

	return "0";
}



function set_infomail($str1, $str2, $str9)
{
	include('a1234/dbheader.the.php');

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	if(!$str1 && !is_string($str1) )
	{
		return 'Value required!';
	}

	if(!$str2 && !is_string($str2) )
	{
		return 'Value2 required!';
	}
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}
		
	$result = mysqli_query($mysqli, "SELECT wid, sEmail FROM tcustomer where isynch_status = 127 and ID = 0 ");

	if ($result && mysqli_num_rows($result) > 0)
	{
		if (list($wid, $sEmail) = mysqli_fetch_row($result))
		{
			$result = mysqli_query($mysqli, "Update tcustomer set sPassword = '{$str1}', sEmail = '{$str2}'  WHERE isynch_status = 127 and ID = 0 ");
			if (!$result)
				return mysqli_error($mysqli);
		}
	}
	else
	{
		$result = mysqli_query($mysqli, "Insert into tcustomer (ID, sEmail, sPassword, isynch_status) Values (0, '{$str2}', '{$str1}', 127) ");
		if (!$result)
		{
			return mysqli_error($mysqli);
		}
		else
		{
			$new_clientid = mysqli_insert_id($mysqli);
			if ( $new_clientid > 0 )
			{
				$result1 = mysqli_query($mysqli, "Insert into tcustomercontact ".
						                         "   (wCustomerID, sName, sLastName, sPhone, sBell, sHouseNumber, StreetID, sStreet, " . 
						                         "    sAddress2, sFloor, sComments, AreaID, PostCodeID, sPostCode, IsDefault) " . 
						                         "  Values " . 
						                         "   ({$new_clientid}, 'Test', 'Test', 'Test', 'Test', '0', '', '', " . 
						                         "    '', '', '', 0, 0, '', 1 ) ", MYSQLI_USE_RESULT);
				if (!$result1)
				{
					return mysqli_error($mysqli);
				}
			}
		}						
		
	}
	$result = mysqli_query($mysqli, "SELECT ID, sEmail FROM tcustomer where isynch_status = 127 and ID = 0 ");
	if ($result && mysqli_num_rows($result) > 0 && list($id, $sEmail) = mysqli_fetch_row($result))
	{
		return strval($sEmail);
	}

	return "0";
}




function set_footeritem($pTitle, $pitype, $picolumn, $pirow, $piheight, $pic, $psdata, $del, $str9 )
{
	include('a1234/dbheader.the.php');

	$new_dir = "images/";
	$i_del = 0;

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	if(!$pTitle)
	{
		return 'Title required!';
	}
	if($pitype === false)
	{
		return 'type required!';
	}
	if(!$picolumn || $picolumn < 1)
	{
		return 'column required!';
	}
	if(!$pirow || $pirow < 1)
	{
		return 'row required!';
	}
	

	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");
	$i_del = $del;

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	if ( file_exists($new_dir. "footer_{$picolumn}_{$pirow}.jpg") )
	{
		unlink($new_dir. "footer_{$picolumn}_{$pirow}.jpg");
	}
	
	$result = mysqli_query($mysqli, "SELECT wid, stitle FROM tfooteritem where icolumn = " . $picolumn . " AND irow = " . $pirow);

	if ($result && mysqli_num_rows($result) > 0 && list($the_wid, $stitle) = mysqli_fetch_row($result))
	{
		// return '11';
		if ($i_del == 1)
		{
			$result = mysqli_query($mysqli, "Delete FROM tfooteritem WHERE wid = {$the_wid}");
			if (!$result)
			{
				return mysqli_error($mysqli);
			}
		}
		else
		{
			$result = mysqli_query($mysqli, 
					" Update tfooteritem set " .
					" stitle = '{$pTitle}', itype = {$pitype}, " .
					" icolumn = {$picolumn}, irow = {$pirow}, " .
					" iheight = {$piheight}, sdata = '{$psdata}' " .
					"  WHERE wid = {$the_wid} ");
			if (!$result)
			{
				return mysqli_error($mysqli);
			}
			else 
			{
				if ( $pitype == 3)
				{
					if(strlen($pic) >10)
					{
						$imageData = base64_decode($pic);
						$photo = imagecreatefromstring($imageData);
						imagejpeg($photo, $new_dir. "footer_{$picolumn}_{$pirow}.jpg", 100);
					}
						
				}
			}
		}
	}
	elseif($i_del == 0)
	{
		$result = mysqli_query($mysqli, 
				" Insert into tfooteritem (stitle, itype, icolumn, irow, iheight, sdata) " .
				" Values ('{$pTitle}', {$pitype}, {$picolumn}, {$pirow}, {$piheight}, '{$psdata}' ) ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	if ($i_del == 1)
	{
		$result = mysqli_query($mysqli, "SELECT wid, stitle FROM tfooteritem where  icolumn = " . $picolumn . " AND irow = " . $pirow);
		if ($result && mysqli_num_rows($result) > 0 && list($the_wid, $stitle) = mysqli_fetch_row($result))
			return "Error, row still exists";
	}
	else
	{
		$result = mysqli_query($mysqli, "SELECT wid, stitle FROM tfooteritem where  icolumn = " . $picolumn . " AND irow = " . $pirow);
		if ($result && mysqli_num_rows($result) > 0 && list($the_wid, $stitle) = mysqli_fetch_row($result))
		{
			return strval($the_wid);
		}
		return "Error";
	}

	return "0";
}



function set_database($str1, $str2, $str9 )
{
	include('a1234/dbheader.the.php');

	if (!verify_string($str9))
	{
		return 'DBERROR';
	}

	if(!$str1 && !is_string($str1) )
	{
		return 'Value required!';
	}
	
	if(!$str2 && !is_string($str2) )
	{
		return 'Value2 required!';
	}
	
	$tables = '*';
	if (backup_tables($db_host, $db_user, $db_pwd, $database, $tables) != 1)
	{
		return "Backup fail";
	}

	
	
	$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);
	$mysqli->set_charset("utf8");

	if ($mysqli->connect_error)
	{
		return 'Cant connect to database';
	}

	if (!mysqli_select_db($mysqli, $database))
	{
		return 'Cant select database';
	}

	$result = mysqli_query($mysqli, "SELECT wid, sparamname FROM tparam where sparamname = 'dbversion' ");
	
	if (!($result && mysqli_num_rows($result) > 0))
	{
		$result = mysqli_query($mysqli, "Insert into tparam (sparamname, sparamvalue) Values ('dbversion', '0') ");
		if (!$result)
			return mysqli_error($mysqli);
	}
	
	$result = mysqli_query($mysqli, "SELECT wid, sparamvalue FROM tparam where sparamname = 'dbversion' ");
	if ($result && mysqli_num_rows($result) > 0 && list($wid, $sparamvalue) = mysqli_fetch_row($result))
	{
		$idbver = intval($sparamvalue);
		$inewver = intval($str1);
		if ($idbver + 1 == $inewver)
		{
			if (mysqli_multi_query($mysqli, $str2))
			{
				do
				{
					/* store first result set */
					if ($result = mysqli_store_result($mysqli))
					{
						//do nothing since there's nothing to handle
						mysqli_free_result($result);
					}
					/* print divider */
					if (mysqli_more_results($mysqli))
					{
						//I just kept this since it seems useful
						//try removing and see for yourself
					}
				} while (mysqli_next_result($mysqli));
				$result = mysqli_query($mysqli, "Update tparam set sparamvalue = '{$inewver}'  WHERE sparamname = 'dbversion' ");
				if (!$result)
				{
					return mysqli_error($mysqli);
				}
				else 
				{
					return $inewver;
				}
			}
		}
		else 
		{
			return "Fail, update is not sequence.(from->{$sparamvalue} to->{$str1})";
		}
	}
	
	return "0";
}



// create HTTP listener 
// $HTTP_RAW_POST_DATA = isset($GLOBALS['HTTP_RAW_POST_DATA'])? $GLOBALS['HTTP_RAW_POST_DATA'] : '';
// $server->service($HTTP_RAW_POST_DATA); 
$server->service(file_get_contents("php://input"));
exit(); 
?>  

