<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


session_start();
include_once('a1234/dbheader.the.php');

if(isset ($_SESSION['customer_wid']) && $_SESSION['customer_wid']>0)
{
	echo "<script type='text/javascript'>window.location.href='../index.php'</script>";
	exit;
}

$PHP_SELF = 'login.php';
$msg = '';

$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);

if ($mysqli->connect_error)
	die("Can't connect to database");

if (!mysqli_select_db($mysqli, $database))
	die("Can't select database");

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if(isset($_POST['login']) && isset($_POST['sPassword']) && isset($_POST['sEmail']))
	{    
        
      	$mysqli->set_charset("utf8");
		
      	$sPassword = $_POST['sPassword'];
		$sEmail = $_POST['sEmail'];
		
		$result = mysqli_query($mysqli, 
				" SELECT IFNULL(tcustomer.id,-1) as id, tcustomer.wid, IFNULL(tcustomercontact.sName, 'No Active Contact') as sName, " .
				"        IFNULL(tcustomercontact.sLastName, '') as sLastName, tcustomer.sEmail, tcustomer.isynch_status " .  
				" FROM tcustomer " . 
		        "      left join tcustomercontact on tcustomercontact.wcustomerid = tcustomer.wid and tcustomercontact.IsDefault = 1 " .
		        " WHERE sPassword='$sPassword' and sEmail='$sEmail' " );
		
        if ($result)
        {
			if (mysqli_num_rows($result) == 1)
			{    
				if (list($the_id, $the_wid, $the_fname, $the_lname, $the_Email, $isynch_status) = mysqli_fetch_row($result))
				{
					$_SESSION['customer_wid'] = $the_wid;
					$_SESSION['customer_name'] = $the_fname;
					$_SESSION['customer_lastname'] = $the_lname;
					$_SESSION['customer_fullname'] = $the_fname . " " . $the_lname;
					$_SESSION['customer_email'] = $the_Email;
					$_SESSION['test_user'] = 0;
					if ( $the_id == 0 && $isynch_status = 127 )
					{
						$_SESSION['test_user'] = 1;
					}
					
					if (!isset($_SESSION['checkout_mode']) || $_SESSION['checkout_mode'] == 0)
					{
						echo "<script type='text/javascript'>window.location.href='index.php'</script>";
					}
					else 
					{
						echo "<script type='text/javascript'>window.location.href='a1234/address.the.php'</script>";
						$_SESSION['checkout_mode'] = 0;
					}
		   			exit;
				}
			}
			else 
			{
				$msg = 'Error login';
			}
		}
		else
		{
			$msg = 'Error login';
		}
				
	}
	else 
	{
		if (!isset($_SESSION['checkout_mode']) || $_SESSION['checkout_mode'] == 0)
			$msg = 'Error reload';
	}
}
?>

<!--==============================html=========================================================================================-->
<html>
<head>
<title>Login</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/style_login.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
</head>
<body>
<?php
 include_once("header.php");
 ?>
 <?php
//  include_once("navigationbar.php");
  ?>

      
<div id="slide-login" style="min-height:600px">		
 
<!--==============================content================================-->
 <div style="padding: 20px 20px; background-color: #aaaaaa;">
        	<h2 class="h2-line"><?php echo $language_array["Account Exists"];?></h2> 
        	
<!--==============================log in=====================================================================-->
<form action="<?=$PHP_SELF?>" method="POST" float="right">

<label class='label-login' for="Email">Email</label><br>
<input  class='input-login' type="email" name="sEmail" id="sEmail" size="40" value="<?php if(isset($sEmail)) echo $sEmail; ?>" ><br>

<label class='label-login' for="password"><?php echo $language_array["Password"];?></label><br>
<input  class='input-login' type="password" name="sPassword" id="sPassword"><br><br>

<input class="buttonlogin" type="submit" name="login" size="20" value="<?php echo $language_array["Login"];?>">

</form>
<?php
if (isset($msg)) // this is special section for outputing message
{
?>
<p style="font-weight: bold;"><?=$msg?>
<br>
<br>
<br>
 
</p>
<a class="loglink" href="register.php"><img align='center' style='height: 28px;' src='images/register_<?php echo $_SESSION["SelectedLanguage"];?>.png' ></a>
<?php
}
?>

</div>

</div>
<?php
 require("footer.php");
 ?>
 </body>
</html>