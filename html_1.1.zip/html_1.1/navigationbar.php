<?php 

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


$the_param_id = 0;
if (isset($_REQUEST['param']))
{
	$the_param_id = $_REQUEST['param'];
}

include('a1234/dbheader.the.php');

$mysqli = mysqli_connect($db_host, $db_user, $db_pwd);

if ($mysqli->connect_error)
{
	die("Can't connect to database");
}

if (!mysqli_select_db($mysqli, $database))
{
	die("Can't select database");
}

$mysqli->set_charset("utf8");
	
$result = mysqli_query($mysqli, "SELECT id, descr FROM tfoodgroup ORDER BY iorder, Descr ");
if ($result)
{
	$extra_str = "";
	if (mysqli_num_rows($result) > 0)
	{
		$bfirsttime = false;
		$id = 0;
		$extra_str = "";
		if ($id == $the_param_id)
		{
			$extra_str = "class=\"active\"";
		}
		
		if (file_exists("images/foodcategory{$id}.png") )
		{
			echo "<li><a href=\"index.php?param=$id\" {$extra_str}><img src=\"images/foodcategory{$id}.png\"  height=40px />  <span class='site'>{$language_array["Home"]}</span> </a></li>  ";
		}
		else 
		{
			echo "<li><a href=\"index.php?param=$id\"{$extra_str}><span class='site'>{$language_array["Home"]}</span> </a></li>  ";
		}
		while(list($id, $descr) = mysqli_fetch_row($result))
		{
			$extra_str = "";
			if ($id == $the_param_id)
			{
				$extra_str = "class=\"active\"";
			}
			$extra_img_str = "";
			
			if (file_exists("images/foodcategory{$id}.png") )
			{
				$extra_img_str = "<img src=\"images/foodcategory{$id}.png\"  height=40px />";
			}
				
					
			if ( ($bfirsttime && $the_param_id == 0 )||
				  $id == $the_param_id )
			{
				echo "<li ><a href=\"index.php?param=$id\" {$extra_str}>{$extra_img_str}  <span class='site'>{$descr}</span> </a></li>  ";
				$bfirsttime = false;
			}
			else 
			{
				echo "<li><a href=\"index.php?param=$id\" {$extra_str}>{$extra_img_str}  <span class='site'>{$descr}</span> </a></li>  ";
			}
				
		} //end of while
	}
}


?>
