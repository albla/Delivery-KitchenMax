<?php

/**
 *
 * @author    Alexander Blazek  
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */

session_start();
if (!isset($_SESSION['the_cart']) )
{
	header('Location:index.php');
	die();
}
if (isset($_REQUEST['refreshorderid']))
{
	$prefix = date('yMdHis');
	$urlparts = parse_url($_SESSION['Website_link']);
	if (isset($urlparts['host'])) 
	{
		$prefix = preg_replace("/[^a-zA-Z0-9]+/", "", $urlparts['host']);
	}
	$_SESSION['the_cart_order_uniq_id'] = $prefix . uniqid();
	if (strlen($_SESSION['the_cart_order_uniq_id'])> 50)
	{
		$_SESSION['the_cart_order_uniq_id'] = substr($_SESSION['the_cart_order_uniq_id'], 0,50);
	}
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/reset.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/style_cart.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/slider.css">
<?php 
if ( file_exists("css/custom.css") )
{
	echo "<link rel='stylesheet' type='text/css' media='screen' href='css/custom.css'>";
}
?>    
    <script src="js/jquery-1.7.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/tms-0.4.1.js"></script>
 	
</head>
<body>
  <!--==============================header=================================-->
    
 <?php
 include_once("header.php");// same header
 ?>

 
      
<div id="slide-cart" style="min-height:700px">		
 
<div class="productContainer-cart">
 
 <table>
 <?php 
	include_once('a1234/class.the.php');
 	include_once('a1234/tools.the.php');

 	function return_topping_array_html($topping_array) 
 	{
		include('a1234/language.the.php');
		
 		$total = 0.0;
		foreach ($topping_array as $ser_tmp_topp)
		{
			$curr_tmp_topp = unserialize($ser_tmp_topp);
			if ( $curr_tmp_topp->dprice > 0 )
			{
				echo "<br> - " . $language_array["Add"] . " ({$curr_tmp_topp->material_descr} +" . my_format_currency($curr_tmp_topp->dprice) . ") ";
			}
			else 
			{
				echo "<br> - " . $language_array["Add"] . " ({$curr_tmp_topp->material_descr}) ";
			}
			$total += $curr_tmp_topp->dprice;
		}
		return $total;
 	}
 	
 	function return_foodline_array_html($foodline_array)
 	{
		include('a1234/language.the.php');
 		
		$total = 0.0;
 		foreach ($foodline_array as $ser_foodline_item)
 		{
 			$foodline_item = unserialize($ser_foodline_item);
 				
 			if ( $foodline_item->binclude == 0 )
 			{
 				echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr})";
 			}
 			elseif ($foodline_item->materialid != $foodline_item->orig_materialid)
 			{
 				if ($foodline_item->dprice > 0)
 				{
 					echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr}) > " . $language_array["With"] . " ({$foodline_item->material_descr} +" . my_format_currency($foodline_item->dprice) . ") ";
 				}
 				else 
 				{
 					echo "<br> - " . $language_array["Without"] . " ({$foodline_item->orig_materialid_descr}) > " . $language_array["With"] . " ({$foodline_item->material_descr})";
 				}
 				$total += $foodline_item->dprice;
 			}
 		}
		return $total;
 	}
 	
 	
 	$new_dir = "images/";
	$the_cart_array = unserialize($_SESSION['the_cart']);
	$final_total = 0.0;
	echo "<tr class='tr_header'>";
	echo "<th style='padding:5px 5px;width:15%'>" . $language_array["Product"] . "</th>";
	echo "<th style='padding:5px 5px;width:50%'>" . $language_array["Description"] . "</th>";
	echo "<th style='padding:5px 5px;width:20%'>" . $language_array["Quantity2"] . "</th>";
	echo "<th style='padding:5px 5px;width:10%'>" . $language_array["Price"] . "</th>";
	echo "<th style='padding:5px 5px;width:5%'></th>";
	echo "</tr>";

	if ( is_array($the_cart_array) )
	{
		foreach ($the_cart_array as $ser_cart_item)
		{
			$cart_item = unserialize($ser_cart_item);
			
			if ( $cart_item->isdeleted == 0 )
			{
				$obj = unserialize($cart_item->current_food);
				
				$sFoodPictureid = $obj->foodpictureid;
				$fooddescr = $obj->sdescr;
				$svarationdescr = $obj->varationdescr;
				$current_total = $obj->dprice;
	
				echo "<tr>";
			
				echo "<td class='all_td' style='text-align:center;vertical-align: middle;'>";
				echo "    <img src='{$new_dir}{$sFoodPictureid}.jpg' alt='' title=''style=\"width:80px;height:70px;\">";
				echo "</td>";
				 
				echo "<td class='all_td'>";
				echo "<label style='font: bold 20px arial, sans-serif;'>{$obj->sdescr_parent}<br></label>";
				if ($obj->itype == 1)
				{
					echo "<label style='font: bold 18px arial, sans-serif;'>{$fooddescr} (" . my_format_currency($obj->dprice) . ")<br></label>";
					echo "<label style='font: 18px arial, sans-serif;'>";
					foreach( $obj->food_list as $ser_curr_food )
					{
						$curr_food = unserialize( $ser_curr_food );
						$schild_varationdescr = $curr_food->varationdescr;
						$child_fooddescr = $curr_food->sdescr;
						echo "{$curr_food->sdescr_parent} / {$child_fooddescr}";
						
						if ( strlen($schild_varationdescr) > 0 )
						{
							echo " ({$schild_varationdescr})";
						}
						if ( is_array($curr_food->foodline ) )
						{
							$current_total += return_foodline_array_html($curr_food->foodline);
						}
						if ( is_array($curr_food->topping ) )
						{
							$current_total += return_topping_array_html($curr_food->topping);
						}
						
						echo "<br>";
					}
					if ( strlen( $cart_item->comment) > 0 )
					{
						echo "\"{$cart_item->comment}\"";
					}
					echo "</label>";
						
				}
				else 
				{
					echo "<label style='font: 18px arial, sans-serif;'>";
					echo "{$fooddescr}";
					if ( strlen($svarationdescr) > 0 )
					{
						echo " ({$svarationdescr})";
					}
					echo "</label>";
						
					echo "<label style='font: 16px arial, sans-serif;'>";
					if ( is_array($obj->foodline ) )
					{
						$current_total += return_foodline_array_html($obj->foodline);
					}
					if ( is_array($obj->topping ) )
					{
						$current_total += return_topping_array_html($obj->topping);
					}
					if ( strlen( $cart_item->comment) > 0 )
					{
						echo "<br>\"{$cart_item->comment}\"";
					}
					echo "</label>";
				}
				echo "</td>";
			
				echo "<td style='text-align:center;vertical-align: middle;'>";
				
				// multiquantity
				if ( $obj->itype == 2 )
				{
					echo " <label style='font: bold 18px arial, sans-serif;background-color: #eee; padding: 0px 20px 5px 20px'>{$obj->quantity}{$obj->descr_metric} </label>";
				}
				else 
				{
					echo "  <a href='a1234/quantity_cart_item.the.php?prm={$cart_item->id}&prm2=-1'><img src='{$new_dir}minus.png' alt='' title=''style=\"width:32px;height:32px;\"></a>";
					echo " <label style='font: bold 16px arial, sans-serif;background-color: #eee; padding: 0px 10px 5px 10px'>{$obj->quantity} </label>";
					echo "  <a href='a1234/quantity_cart_item.the.php?prm={$cart_item->id}&prm2=1'><img src='{$new_dir}plus.png' alt='' title=''style=\"width:32px;height:32px;\"> </a>";
				}
				echo "</td>";
				
				$current_total = $current_total * $obj->quantity;
				
				echo "<td style='font: 18px arial, sans-serif;text-align:center;vertical-align: bottom;'>";
				echo my_format_currency($current_total);
				echo "</td>";
			
				echo "<td style='text-align:center;vertical-align: middle;'>";
  				echo "  <a href='a1234/delete_cart_item.the.php?prm={$cart_item->id}'>  <img src='{$new_dir}trash.png' alt='' title=''style=\"width:32px;height:32px;\"> </a>";
				echo "</td>";
			
				echo "</tr>";
			
				$final_total += round($current_total,2);
				
			}
		}
	}
	
	echo "<tr style='font: bold 20px/40px arial, sans-serif;'>";
	echo "<td colspan='3' style='text-align:right'> " . $language_array["Total"] . ":</td>";
	echo "<td style='text-align:center;  background: -webkit-linear-gradient(#a0a0a0, #707090);  background:    -moz-linear-gradient(#a0a0a0, #707090);  background:         linear-gradient(#a0a0a0, #707090);'>";
	echo my_format_currency($final_total);
   	echo "</td>";
	echo "<td></td>";
	echo "</tr>";
	
	if (isset($_SESSION['WebSiteDiscount_float']))
	{
		if ($_SESSION['WebSiteDiscount_float'] > 0 )
		{
			$printable_discount = $_SESSION['WebSiteDiscount_float'] * 100;
			echo "<tr style='font: bold 20px/40px arial, sans-serif;'>";
			echo "<td colspan='3' style='text-align:right'> " . $language_array["Total"] . " " . $language_array["With"] . " {$printable_discount}% " . $language_array["discount"] . ":</td>";
			echo "<td style='text-align:center;  background: -webkit-linear-gradient(#a0a0a0, #707090);  background:    -moz-linear-gradient(#a0a0a0, #707090);  background:         linear-gradient(#a0a0a0, #707090);'>";
			echo my_format_currency($final_total * (1.0 - $_SESSION['WebSiteDiscount_float']) );
			echo "</td>";
			echo "<td></td>";
			echo "</tr>";
		}
	}
 
 ?>
 
</table>
 
</div> 
 <div style="padding: 10px 10px; float:left; position: relative;">
 
 <form  method='post' action='a1234/empty.the.php'>
 <input class='buttonemptycart' type='submit' name='submit' Value='<?php echo $language_array["Empty the basket"]; ?>'/>
 </form>
 </div>
 
 <div style="padding: 10px 10px; float:left; position: relative;">
 
 <form  method='post' action='index.php'>
 <input class='buttonkeepshopping' type='submit' name='submit_shop' Value='<?php echo $language_array["Keep on shopping"]; ?>'/>
 </form>
 </div>
 
 
 <div style="padding: 10px 10px 150px; float:right; position: relative;">
 <?php 
 
	 if (isset ($_SESSION['customer_wid']) && $_SESSION['customer_wid']>0)
	 {
	 	echo "<form  method='post' action='a1234/address.the.php'>";
	 }
	 else
	 {
	 	$_SESSION['checkout_mode'] = 1;
	 	echo "<form  method='post' action='login.php'>";
	 }
	 
 ?>
 
 
 
 <input class='buttoncheckout' type='submit' name='submit' Value='<?php echo $language_array["Finalize Order"]; ?>'/>
 </form>
 </div>
</div> 

<?php
 require("footer.php");// same header
 ?>	           
</body>
</html>
 
 
 