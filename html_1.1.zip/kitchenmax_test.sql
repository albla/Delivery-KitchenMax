-- phpMyAdmin SQL Dump
-- version 4.5.1deb3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 17, 2016 at 05:37 PM
-- Server version: 5.6.30-1
-- PHP Version: 5.6.17-3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kitchenmax_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tarea`
--

CREATE TABLE `tarea` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(100) NOT NULL,
  `Fee` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tcustomer`
--

CREATE TABLE `tcustomer` (
  `wID` bigint(20) NOT NULL,
  `ID` decimal(10,0) DEFAULT NULL,
  `sEmail` varchar(100) NOT NULL,
  `sPassword` varchar(50) NOT NULL,
  `isynch_status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tcustomercontact`
--

CREATE TABLE `tcustomercontact` (
  `wID` bigint(20) NOT NULL,
  `ID` decimal(10,0) DEFAULT NULL,
  `wCustomerID` bigint(20) NOT NULL,
  `CustomerID` decimal(10,0) NOT NULL,
  `sName` varchar(100) NOT NULL,
  `sLastName` varchar(100) NOT NULL,
  `sPhone` varchar(100) NOT NULL,
  `sBell` varchar(100) NOT NULL,
  `sHouseNumber` varchar(20) NOT NULL,
  `StreetID` decimal(10,0) NOT NULL,
  `sStreet` varchar(100) NOT NULL,
  `sAddress2` varchar(100) NOT NULL,
  `sFloor` varchar(10) NOT NULL,
  `sComments` varchar(200) NOT NULL,
  `AreaID` decimal(10,0) NOT NULL,
  `sArea` varchar(100) NOT NULL,
  `PostCodeID` decimal(10,0) NOT NULL,
  `sPostCode` varchar(10) NOT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  `isynch_status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfood`
--

CREATE TABLE `tfood` (
  `ID` decimal(10,0) NOT NULL,
  `FoodGroupID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL,
  `sNo` varchar(10) NOT NULL DEFAULT '',
  `iorder` int(11) NOT NULL DEFAULT '0',
  `itype` int(11) NOT NULL DEFAULT '0',
  `dQuantity` decimal(25,10) NOT NULL DEFAULT '1.0000000000',
  `dFreeEvery` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `dFreeQty` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `metricid` decimal(10,0) NOT NULL,
  `isavailable` bit(1) NOT NULL DEFAULT b'1',
  `sFoodPictureid` varchar(20) NOT NULL,
  `CanChangeMaterials` int(11) NOT NULL DEFAULT '1',
  `ifrontpageno` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfoodbundle`
--

CREATE TABLE `tfoodbundle` (
  `ID` decimal(10,0) NOT NULL,
  `foodid` decimal(10,0) NOT NULL,
  `bfreetoppings` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfoodbundledetail`
--

CREATE TABLE `tfoodbundledetail` (
  `ID` decimal(10,0) NOT NULL,
  `foodbundleid` decimal(10,0) NOT NULL,
  `foodvariationid` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfoodgroup`
--

CREATE TABLE `tfoodgroup` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL,
  `iorder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfoodline`
--

CREATE TABLE `tfoodline` (
  `ID` decimal(10,0) NOT NULL,
  `foodid` decimal(10,0) NOT NULL,
  `materialid` decimal(10,0) NOT NULL,
  `metricid` decimal(10,0) NOT NULL,
  `dqty` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tfoodvariation`
--

CREATE TABLE `tfoodvariation` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL,
  `foodid` decimal(10,0) NOT NULL,
  `variationid` decimal(10,0) DEFAULT NULL,
  `dprice` decimal(25,10) NOT NULL,
  `ipiece` decimal(25,10) NOT NULL,
  `dqty` decimal(25,10) NOT NULL,
  `sno` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tmaterial`
--

CREATE TABLE `tmaterial` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tmetric`
--

CREATE TABLE `tmetric` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `torder`
--

CREATE TABLE `torder` (
  `wid` bigint(20) NOT NULL,
  `wCustomerContactID` bigint(20) NOT NULL,
  `dTotalExVAT` decimal(25,10) NOT NULL,
  `dVAT` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `dTotalIncVAT` decimal(25,10) NOT NULL,
  `dFinalTotal` decimal(25,10) NOT NULL,
  `dDiscount` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `torderline`
--

CREATE TABLE `torderline` (
  `wid` bigint(20) NOT NULL,
  `worderid` bigint(20) NOT NULL,
  `foodid` decimal(10,0) NOT NULL,
  `dPiece` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `dprice` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `dvat` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `dtotal` decimal(25,10) NOT NULL DEFAULT '0.0000000000',
  `iorder` int(11) NOT NULL DEFAULT '0',
  `bundleno` int(11) NOT NULL DEFAULT '0',
  `bundleid` decimal(10,0) NOT NULL,
  `isfreetoppings` tinyint(1) NOT NULL DEFAULT '0',
  `ipartno` int(11) NOT NULL DEFAULT '0',
  `isfixedprice` tinyint(1) NOT NULL DEFAULT '0',
  `Ismultiqty` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `torderlog`
--

CREATE TABLE `torderlog` (
  `wid` bigint(20) NOT NULL,
  `sbody` text NOT NULL,
  `istatus` int(11) NOT NULL DEFAULT '0',
  `dtstamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tparam`
--

CREATE TABLE `tparam` (
  `wid` bigint(20) NOT NULL,
  `sparamname` varchar(50) NOT NULL,
  `sparamvalue` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tpostcode`
--

CREATE TABLE `tpostcode` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(100) NOT NULL,
  `Fee` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tstreet`
--

CREATE TABLE `tstreet` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(100) NOT NULL,
  `Fee` decimal(25,10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ttopping`
--

CREATE TABLE `ttopping` (
  `ID` decimal(10,0) NOT NULL,
  `foodid` decimal(10,0) NOT NULL,
  `materialid` decimal(10,0) NOT NULL,
  `metricid` decimal(10,0) NOT NULL,
  `dqty` decimal(25,10) NOT NULL DEFAULT '1.0000000000',
  `dprice` decimal(25,10) NOT NULL DEFAULT '0.0000000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ttoppingvariation`
--

CREATE TABLE `ttoppingvariation` (
  `ID` decimal(10,0) NOT NULL,
  `toppingid` decimal(10,0) NOT NULL,
  `variationid` decimal(10,0) NOT NULL,
  `dprice` decimal(25,10) NOT NULL DEFAULT '0.0000000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tvariation`
--

CREATE TABLE `tvariation` (
  `ID` decimal(10,0) NOT NULL,
  `Descr` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tarea`
--
ALTER TABLE `tarea`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tcustomer`
--
ALTER TABLE `tcustomer`
  ADD PRIMARY KEY (`wID`);

--
-- Indexes for table `tcustomercontact`
--
ALTER TABLE `tcustomercontact`
  ADD PRIMARY KEY (`wID`);

--
-- Indexes for table `tfood`
--
ALTER TABLE `tfood`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tfoodbundle`
--
ALTER TABLE `tfoodbundle`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tfoodbundledetail`
--
ALTER TABLE `tfoodbundledetail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tfoodgroup`
--
ALTER TABLE `tfoodgroup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tfoodline`
--
ALTER TABLE `tfoodline`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tfoodvariation`
--
ALTER TABLE `tfoodvariation`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tmaterial`
--
ALTER TABLE `tmaterial`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tmetric`
--
ALTER TABLE `tmetric`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `torder`
--
ALTER TABLE `torder`
  ADD PRIMARY KEY (`wid`);

--
-- Indexes for table `torderline`
--
ALTER TABLE `torderline`
  ADD PRIMARY KEY (`wid`);

--
-- Indexes for table `torderlog`
--
ALTER TABLE `torderlog`
  ADD PRIMARY KEY (`wid`);

--
-- Indexes for table `tparam`
--
ALTER TABLE `tparam`
  ADD PRIMARY KEY (`wid`);

--
-- Indexes for table `tpostcode`
--
ALTER TABLE `tpostcode`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tstreet`
--
ALTER TABLE `tstreet`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ttopping`
--
ALTER TABLE `ttopping`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ttoppingvariation`
--
ALTER TABLE `ttoppingvariation`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tvariation`
--
ALTER TABLE `tvariation`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tcustomer`
--
ALTER TABLE `tcustomer`
  MODIFY `wID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tcustomercontact`
--
ALTER TABLE `tcustomercontact`
  MODIFY `wID` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `torder`
--
ALTER TABLE `torder`
  MODIFY `wid` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `torderline`
--
ALTER TABLE `torderline`
  MODIFY `wid` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `torderlog`
--
ALTER TABLE `torderlog`
  MODIFY `wid` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tparam`
--
ALTER TABLE `tparam`
  MODIFY `wid` bigint(20) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
