<?php 

/**
 *
 * @author    Alexander Blazek
 * @copyright 2016 smobilesoft.com
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://smobilesoft.com
 *
 */


echo "<script type='text/javascript'> ";
echo "function acceptance_cc()";
echo "{";
echo "	var accept_btn = document.getElementById('accbtn_cc').checked;";
echo "	var form_post = document.getElementById('submit_creditcard');";
echo "	if (accept_btn)";
echo "	{";
echo "		form_post.submit();";
echo "	}";
echo "	else";
echo "	{";
echo "		alert(\"{$language_array['Please accept the Terms of use (I agree with the terms and conditions)']}\");";
echo "	}";
echo "}";
echo "   </script>";     

echo "<div class='acc-btn'><h1> {$language_array['Payment with credit card']} </h1></div> ";
echo "<div class='acc-content'>";
echo "  <div class='acc-content-inner'>";

$website = $_SESSION['Website_link'];
$credit_card_str_coded = encode_str_gr('credit_card');

$form_data = "";
$form_data_array = array();
$mid = "MID";
$orderid = $_SESSION['the_cart_order_uniq_id'];
$orderDesc = "Goods Description";
$orderAmount = "{$final_total}";
$currency = "EUR";
$payerEmail = $_SESSION['customer_email'];
$confirmUrl = "{$website}a1234/new_order.the.php?credit_card={$credit_card_str_coded}";

// refreshorderid=0 this will recreate the order ID
$cancelUrl = "{$website}shopping_cart.php?refreshorderid=0";
// if you want to keep the order ID use the following line
//$cancelUrl = "{$website}shopping_cart.php";


$form_secret = "Cardlink1";

$form_data_array[1] = $mid;
$form_data_array[2] = $orderid;
$form_data_array[3] = $orderDesc;
$form_data_array[4] = $orderAmount;
$form_data_array[5] = $currency;
$form_data_array[6] = $payerEmail;
$form_data_array[7] = $confirmUrl;
$form_data_array[8] = $cancelUrl;
$form_data_array[9] = $form_secret;
$form_data = implode("", $form_data_array);
$digest = base64_encode(sha1($form_data,true));


echo "    <form name='redirectpost' method='post' action='https://alpha.test.modirum.com/vpos/shophandlermpi' accept-charset='UTF-8' >";
echo "      <input type='hidden' name='mid' value='{$mid}'/>";
echo "      <input type='hidden' name='orderid' value='{$orderid}'/>";
echo "      <input type='hidden' name='orderDesc' value='{$orderDesc}'/>";
echo "      <input type='hidden' name='orderAmount' value='{$orderAmount}'/>";
echo "      <input type='hidden' name='currency' value='{$currency}'/>";
echo "      <input type='hidden' name='payerEmail' value='{$payerEmail}'/>";
echo "      <input type='hidden' name='confirmUrl' value='{$confirmUrl}'/>";
echo "      <input type='hidden' name='cancelUrl' value='{$cancelUrl}'/>";
echo "      <input type='hidden' name='digest' value='{$digest}'/>";
echo "     <label class='text_message'>" . $language_array["Total"] . ": {$s_final_total}</label>";
echo "    <br><br>";
echo "      <img src='../plugin/logo1.png' alt='' title=''>";
echo "    <br><br><br><br><br><br><br>";
echo "    <div style='position: absolute;bottom: 80px;left: 20px;width: -moz-available;'>";
echo "    <input type='checkbox' id='accbtn_cc' name='accbtn_cc' > ";
echo "    <label class='text_message' style='top: 10px;left: 80px;position: absolute;' for='accbtn_cc' >{$language_array["I agree with the terms and conditions"]} &nbsp;</label>  ";
echo "    </div>";
echo "    <br>";
echo "    <br>";
echo "        <input class='buttonsubmit' type='submit' id='submit_creditcard' name='submit_creditcard' Value='{$language_array["Finalize Order"]}'  onclick='javascript:acceptance_cc()' />";
echo "    <br>";
echo "    <br>";
echo "    <br>";
echo "    <br>";

echo "  </form>";
echo "  </div>";
echo "</div> ";




?>
			
